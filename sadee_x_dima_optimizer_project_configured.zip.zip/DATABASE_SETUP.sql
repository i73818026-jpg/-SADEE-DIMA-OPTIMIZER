-- 1. Create License Keys Table
CREATE TABLE public.license_keys (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    key_code TEXT UNIQUE NOT NULL,
    duration_days INT NOT NULL, -- 1, 3, 5, 7, 14, 30, -1 (Lifetime)
    device_id TEXT DEFAULT NULL,
    status TEXT DEFAULT 'UNUSED', -- UNUSED, ACTIVE, PAUSED, EXPIRED
    activated_at TIMESTAMPTZ DEFAULT NULL,
    expires_at TIMESTAMPTZ DEFAULT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Create App Updates Table
CREATE TABLE public.app_updates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    version_code INT NOT NULL,
    version_name TEXT NOT NULL,
    download_url TEXT NOT NULL,
    force_update BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS) - Optional/Recommended
ALTER TABLE public.license_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_updates ENABLE ROW LEVEL SECURITY;

-- Allow public access for anon key
CREATE POLICY "Public License Keys Policy" ON public.license_keys FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Public App Updates Policy" ON public.app_updates FOR ALL USING (true) WITH CHECK (true);
