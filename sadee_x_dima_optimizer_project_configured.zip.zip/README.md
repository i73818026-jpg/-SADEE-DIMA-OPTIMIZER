# sadee_x_dima_optimizer

A complete Flutter application for **Sadee X Dima Optimizer** & **Admin Control Panel**.

## Features Included:
- **Device Specification Scanner**: Reads Brand, Model, Android Version, RAM Usage.
- **RAM & System Optimizer**: High-performance cleaning simulation.
- **License Key System**: 1, 3, 5, 7, 14, 30 Days & Lifetime options with 1-device hardware binding.
- **Countdown Timer**: Realtime remaining access countdown displayed in top header.
- **Admin Control Panel**: Key generation, Key Pause/Unpause/Expire actions, Remote Update trigger.
- **GitHub Actions Auto Build**: Automatically compiles both User App and Admin App APKs upon `git push`.

## How to Deploy from Mobile / Phone:

1. Extract this ZIP file.
2. Edit `lib/config.dart` and paste your **Supabase Project URL** and **Anon Key**.
3. Create a GitHub Repository on [github.com](https://github.com).
4. Upload all the files inside this folder to your GitHub repo.
5. Go to the **Actions** tab on GitHub - the APK build workflow will automatically start.
6. Once completed, download both APKs directly from **Artifacts**!
