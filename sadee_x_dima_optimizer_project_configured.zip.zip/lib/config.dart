// Supabase configuration
class AppConfig {
  static const String supabaseUrl =
      'https://cpmzjplfqggmgeotmtcd.supabase.co';

  static const String supabaseAnonKey =
      'sb_publishable_z0kmWe85ybkmBg7bzEtyKA_kMH6WGXW';
}
