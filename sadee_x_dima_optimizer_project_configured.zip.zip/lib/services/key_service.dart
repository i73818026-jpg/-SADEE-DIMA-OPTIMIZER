import 'dart:math';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:device_info_plus/device_info_plus.dart';

class KeyService {
  final supabase = Supabase.instance.client;

  Future<String> getDeviceId() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
    return androidInfo.id;
  }

  // Validate Key for User App
  Future<Map<String, dynamic>> validateAndActivateKey(String keyInput) async {
    try {
      String deviceId = await getDeviceId();

      final response = await supabase
          .from('license_keys')
          .select()
          .eq('key_code', keyInput.trim())
          .maybeSingle();

      if (response == null) {
        return {'success': false, 'message': 'ක්‍රියාකාරී නොවන හෝ වැරදි Key එකකි!'};
      }

      String status = response['status'];
      String? boundDevice = response['device_id'];

      if (status == 'PAUSED') {
        return {'success': false, 'message': 'මෙම Key එක Admin විසින් Pause කර ඇත.'};
      }

      if (status == 'EXPIRED') {
        return {'success': false, 'message': 'මෙම Key එකෙහි කාලය අවසන් (Expired) වී ඇත.'};
      }

      // New activation
      if (status == 'UNUSED') {
        int days = response['duration_days'];
        DateTime now = DateTime.now();
        DateTime? expiresAt = days == -1 ? null : now.add(Duration(days: days));

        await supabase.from('license_keys').update({
          'device_id': deviceId,
          'status': 'ACTIVE',
          'activated_at': now.toIso8601String(),
          'expires_at': expiresAt?.toIso8601String(),
        }).eq('key_code', keyInput.trim());

        return {
          'success': true,
          'message': 'Key එක සාර්ථකව Active විය!',
          'expiresAt': expiresAt,
          'isLifetime': days == -1
        };
      }

      // Already Active Key Validation
      if (status == 'ACTIVE') {
        if (boundDevice != deviceId) {
          return {'success': false, 'message': 'මෙම Key එක වෙනත් Phone එකක භාවිතයේ පවතී!'};
        }

        if (response['expires_at'] != null) {
          DateTime expiry = DateTime.parse(response['expires_at']);
          if (DateTime.now().isAfter(expiry)) {
            await supabase
                .from('license_keys')
                .update({'status': 'EXPIRED'}).eq('key_code', keyInput.trim());
            return {'success': false, 'message': 'Key එකෙහි කාලය අවසන් වී ඇත!'};
          }
          return {
            'success': true,
            'message': 'Valid Key',
            'expiresAt': expiry,
            'isLifetime': false
          };
        }
        return {'success': true, 'message': 'Valid Lifetime Key', 'isLifetime': true};
      }

      return {'success': false, 'message': 'නොදන්නා දෝෂයක්!'};
    } catch (e) {
      return {'success': false, 'message': 'දෝෂයකි: $e'};
    }
  }

  // --- Admin Panel Actions ---

  String generateRandomKey() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    Random rnd = Random();
    String code = String.fromCharCodes(Iterable.generate(12, (_) => chars.codeUnitAt(rnd.nextInt(chars.length))));
    return "SXD-${code.substring(0, 4)}-${code.substring(4, 8)}-${code.substring(8, 12)}";
  }

  Future<String> createLicenseKey(int durationDays) async {
    String key = generateRandomKey();
    await supabase.from('license_keys').insert({
      'key_code': key,
      'duration_days': durationDays,
      'status': 'UNUSED'
    });
    return key;
  }

  Future<List<Map<String, dynamic>>> fetchAllKeys() async {
    final res = await supabase.from('license_keys').select().order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(res);
  }

  Future<void> updateKeyStatus(String keyCode, String status) async {
    await supabase.from('license_keys').update({'status': status}).eq('key_code', keyCode);
  }

  Future<void> deleteKey(String keyCode) async {
    await supabase.from('license_keys').delete().eq('key_code', keyCode);
  }
}
