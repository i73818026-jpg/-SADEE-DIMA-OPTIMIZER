import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import '../services/key_service.dart';
import '../services/optimizer_service.dart';

class UserHomeScreen extends StatefulWidget {
  const UserHomeScreen({super.key});

  @override
  State<UserHomeScreen> createState() => _UserHomeScreenState();
}

class _UserHomeScreenState extends State<UserHomeScreen> {
  final KeyService _keyService = KeyService();
  final OptimizerService _optimizerService = OptimizerService();

  bool _isKeyVerified = false;
  String _keyInput = "";
  DateTime? _expiresAt;
  bool _isLifetime = false;
  Timer? _countdownTimer;
  Duration _remainingTime = Duration.zero;

  bool _isScanning = false;
  bool _isOptimized = false;
  Map<String, String> _deviceData = {};

  @override
  void initState() {
    super.initState();
    _loadDeviceInfo();
  }

  void _loadDeviceInfo() async {
    var info = await _optimizerService.getDeviceInfo();
    setState(() {
      _deviceData = info;
    });
  }

  void _verifyKey() async {
    if (_keyInput.isEmpty) return;
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    var res = await _keyService.validateAndActivateKey(_keyInput);
    Navigator.pop(context);

    if (res['success'] == true) {
      setState(() {
        _isKeyVerified = true;
        _expiresAt = res['expiresAt'];
        _isLifetime = res['isLifetime'] ?? false;
      });
      if (!_isLifetime && _expiresAt != null) {
        _startTimer();
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['message']), backgroundColor: Colors.green),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['message']), backgroundColor: Colors.red),
      );
    }
  }

  void _startTimer() {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_expiresAt == null) return;
      final now = DateTime.now();
      if (_expiresAt!.isAfter(now)) {
        setState(() {
          _remainingTime = _expiresAt!.difference(now);
        });
      } else {
        _countdownTimer?.cancel();
        setState(() {
          _isKeyVerified = false;
        });
      }
    });
  }

  void _runOptimizer() async {
    setState(() {
      _isScanning = true;
      _isOptimized = false;
    });

    await _optimizerService.performOptimization();
    _loadDeviceInfo();

    setState(() {
      _isScanning = false;
      _isOptimized = true;
    });
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0C20),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1D1B3A),
        title: const Text(
          '𝕤𝕒𝕕𝕖𝕖 𝕏 𝕕𝕚𝕞𝕒 𝕠𝕡𝕥𝕚𝕞𝕚𝕫𝕖𝕣',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.cyanAccent),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Timer / Key Bar
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Colors.purple, Colors.deepPurple]),
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(color: Colors.purple.withOpacity(0.4), blurRadius: 10)
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(
                        _isKeyVerified ? Icons.verified : Icons.lock,
                        color: _isKeyVerified ? Colors.greenAccent : Colors.amberAccent,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _isKeyVerified
                            ? (_isLifetime ? "LIFETIME VIP" : "VIP ACTIVE")
                            : "NO KEY ACTIVATED",
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  Text(
                    _isKeyVerified
                        ? (_isLifetime
                            ? "∞ Forever"
                            : "${_remainingTime.inDays}d ${_remainingTime.inHours % 24}h ${_remainingTime.inMinutes % 60}m ${_remainingTime.inSeconds % 60}s")
                        : "LOCKED",
                    style: const TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Key Input Section if not verified
            if (!_isKeyVerified)
              Card(
                color: const Color(0xFF1D1B3A),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      const Text(
                        "Enter License Key to Unlock Gaming Boost & Optimizer",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        onChanged: (val) => _keyInput = val,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: "SXD-XXXX-XXXX-XXXX",
                          hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                          filled: true,
                          fillColor: Colors.black26,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.cyanAccent,
                          foregroundColor: Colors.black,
                          minimumSize: const Size(double.infinity, 45),
                        ),
                        onPressed: _verifyKey,
                        child: const Text("ACTIVATE KEY", style: TextStyle(fontWeight: FontWeight.bold)),
                      )
                    ],
                  ),
                ),
              ),

            const SizedBox(height: 20),

            // Phone Specifications
            Card(
              color: const Color(0xFF1D1B3A),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.phone_android, color: Colors.cyanAccent),
                        SizedBox(width: 8),
                        Text("Device Status & Details",
                            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const Divider(color: Colors.white24, height: 20),
                    _infoRow("Device Brand", _deviceData['brand'] ?? 'Loading...'),
                    _infoRow("Device Model", _deviceData['model'] ?? 'Loading...'),
                    _infoRow("Android Version", "Android ${_deviceData['androidVersion'] ?? ''}"),
                    _infoRow("RAM Usage", "${_deviceData['usedRam'] ?? '0'} / ${_deviceData['totalRam'] ?? '0'} (${_deviceData['ramPercentage'] ?? '0'})"),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 25),

            // Scanning / Booster Action Section
            _isScanning
                ? Column(
                    children: [
                      SpinKitThreeBounce(color: Colors.cyanAccent, size: 70),
                      const SizedBox(height: 15),
                      const Text("Scanning Apps & Freeing Memory...",
                          style: TextStyle(color: Colors.cyanAccent, fontSize: 14, fontWeight: FontWeight.bold)),
                    ],
                  )
                : ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isKeyVerified ? Colors.redAccent : Colors.grey,
                      minimumSize: const Size(double.infinity, 55),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    icon: const Icon(Icons.rocket_launch, color: Colors.white, size: 28),
                    label: const Text("ULTRA BOOST & CLEAN RAM",
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                    onPressed: _isKeyVerified ? _runOptimizer : null,
                  ),

            if (_isOptimized)
              Container(
                margin: const EdgeInsets.only(top: 20),
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.2),
                  border: Border.all(color: Colors.green),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.check_circle, color: Colors.greenAccent),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        "Optimization Complete! System Cache Cleaned & RAM Boosted.",
                        style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.bold),
                      ),
                    )
                  ],
                ),
              )
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.white60)),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
