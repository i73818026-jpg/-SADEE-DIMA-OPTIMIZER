
import 'dart:async';
import 'dart:io';
import 'package:battery_plus/battery_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

const supabaseUrl = 'https://cpmzjplfqggmgeotmtcd.supabase.co';
const supabasePublishableKey =
    'sb_publishable_z0kmWe85ybkmBg7bzEtyKA_kMH6WGXW';
const whatsappNumber = '94768472404';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: supabaseUrl,
    publishableKey: supabasePublishableKey,
  );
  runApp(const SadeeDimaApp());
}

class SadeeDimaApp extends StatelessWidget {
  const SadeeDimaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SADEE X DIMA OPTIMIZER',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF080808),
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFFFF1744),
        brightness: Brightness.dark,
      ),
      useMaterial3: true,
    ),
    home: const LicenseGate(),
  );
}

class LicenseGate extends StatefulWidget {
  const LicenseGate({super.key});
  @override State<LicenseGate> createState() => _LicenseGateState();
}
class _LicenseGateState extends State<LicenseGate> {
  bool loading = true;
  String? key;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    setState(() { key = p.getString('license_key'); loading = false; });
  }
  @override Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return key == null ? PlanScreen(onActivated: load) : const MainShell();
  }
}

class LogoHeader extends StatelessWidget {
  const LogoHeader({super.key});
  @override Widget build(BuildContext context) => Row(children: [
    ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.asset('assets/logo.png', width: 58, height: 58, fit: BoxFit.cover,
        errorBuilder: (_,__,___) => Container(
          width: 58, height: 58, color: const Color(0xFF241016),
          child: const Icon(Icons.bolt, color: Color(0xFFFF1744), size: 32),
        )),
    ),
    const SizedBox(width: 12),
    const Expanded(child: Text('SADEE X DIMA OPTIMIZER',
      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
  ]);
}

class PlanScreen extends StatefulWidget {
  final Future<void> Function() onActivated;
  const PlanScreen({super.key, required this.onActivated});
  @override State<PlanScreen> createState() => _PlanScreenState();
}
class _PlanScreenState extends State<PlanScreen> {
  List<Map<String,dynamic>> plans = [
    {'name':'7 Days','duration_days':7,'price_lkr':500},
    {'name':'1 Month','duration_days':30,'price_lkr':1000},
    {'name':'Lifetime','duration_days':null,'price_lkr':2200},
  ];
  int selected = 0;
  @override void initState(){super.initState(); fetchPlans();}
  Future<void> fetchPlans() async {
    try {
      final rows = await Supabase.instance.client.from('plans')
        .select('id,name,duration_days,price_lkr').eq('active',true).order('price_lkr');
      if (rows.isNotEmpty && mounted) setState(() => plans = List<Map<String,dynamic>>.from(rows));
    } catch (_) {}
  }
  Future<void> order() async {
    final p=plans[selected];
    final text='SADEE X DIMA OPTIMIZER ORDER\n\nPlan: ${p['name']}\nPrice: LKR ${p['price_lkr']}\n\nPlease send payment details and activation instructions.';
    final uri=Uri.parse('https://wa.me/$whatsappNumber?text=${Uri.encodeComponent(text)}');
    if(await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children:[
      const LogoHeader(), const SizedBox(height:20),
      const Text('CHOOSE YOUR LICENSE',textAlign:TextAlign.center,
        style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
      const SizedBox(height:20),
      for(int i=0;i<plans.length;i++) Padding(
        padding:const EdgeInsets.only(bottom:12),
        child: InkWell(
          onTap:()=>setState(()=>selected=i),
          borderRadius:BorderRadius.circular(18),
          child: Container(
            padding:const EdgeInsets.all(18),
            decoration:BoxDecoration(
              color:selected==i?const Color(0xFF261016):const Color(0xFF111111),
              borderRadius:BorderRadius.circular(18),
              border:Border.all(color:selected==i?const Color(0xFFFF1744):Colors.white12,width:selected==i?2:1)),
            child:Row(children:[
              Icon(selected==i?Icons.radio_button_checked:Icons.radio_button_off,
                color:selected==i?const Color(0xFFFF1744):Colors.white38),
              const SizedBox(width:12),
              Expanded(child:Text('${plans[i]['name']}'.toUpperCase(),
                style:const TextStyle(fontWeight:FontWeight.w900))),
              Text('LKR ${plans[i]['price_lkr']}',
                style:const TextStyle(color:Color(0xFFFF1744),fontWeight:FontWeight.w900)),
            ]),
          ),
        ),
      ),
      const SizedBox(height:8),
      FilledButton.icon(
        onPressed:order, icon:const Icon(Icons.chat),
        label:const Padding(padding:EdgeInsets.all(14),child:Text('ORDER NOW ON WHATSAPP'))),
      const SizedBox(height:10),
      OutlinedButton(
        onPressed:()=>Navigator.push(context,MaterialPageRoute(
          builder:(_)=>LicenseActivationScreen(onActivated:widget.onActivated))),
        child:const Padding(padding:EdgeInsets.all(13),child:Text('I ALREADY HAVE A LICENSE KEY'))),
    ])));
}

class LicenseActivationScreen extends StatefulWidget {
  final Future<void> Function() onActivated;
  const LicenseActivationScreen({super.key,required this.onActivated});
  @override State<LicenseActivationScreen> createState()=>_LicenseActivationScreenState();
}
class _LicenseActivationScreenState extends State<LicenseActivationScreen>{
  final c=TextEditingController(); bool loading=false;
  Future<String> deviceId() async {
    if(Platform.isAndroid){final a=await DeviceInfoPlugin().androidInfo;return '${a.brand}-${a.model}-${a.id}';}
    return 'ios-device';
  }
  Future<void> activate() async {
    final key=c.text.trim(); if(key.isEmpty)return;
    setState(()=>loading=true);
    try{
      final rows=await Supabase.instance.client.from('licenses').select(
        'id,status,device_id,expires_at').eq('license_key',key).limit(1);
      if(rows.isEmpty)throw Exception('License key not found.');
      final x=Map<String,dynamic>.from(rows.first);
      if(x['status']=='expired')throw Exception('This license has expired.');
      if(x['status']=='paused')throw Exception('This license is paused.');
      final d=await deviceId();
      if(x['device_id']!=null && x['device_id']!='' && x['device_id']!=d)
        throw Exception('This key is already bound to another device.');
      await Supabase.instance.client.from('licenses').update({
        'status':'active','device_id':d,'activated_at':DateTime.now().toIso8601String()
      }).eq('id',x['id']);
      final p=await SharedPreferences.getInstance(); await p.setString('license_key',key);
      if(!mounted)return; await widget.onActivated(); Navigator.pop(context);
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}
    finally{if(mounted)setState(()=>loading=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('LICENSE ACTIVATION')),
    body:ListView(padding:const EdgeInsets.all(20),children:[
      const Icon(Icons.vpn_key,size:70,color:Color(0xFFFF1744)),
      const SizedBox(height:16),
      TextField(controller:c,textCapitalization:TextCapitalization.characters,
        decoration:const InputDecoration(hintText:'XXXX-XXXX-XXXX-XXXX',
          prefixIcon:Icon(Icons.key),border:OutlineInputBorder())),
      const SizedBox(height:16),
      FilledButton(onPressed:loading?null:activate,
        child:Padding(padding:const EdgeInsets.all(14),
          child:loading?const CircularProgressIndicator():const Text('ACTIVATE LICENSE'))),
    ]));
}

class MainShell extends StatefulWidget{const MainShell({super.key});
  @override State<MainShell> createState()=>_MainShellState();}
class _MainShellState extends State<MainShell>{
  int i=0;
  final pages=const[HomePage(),TurboPage(),GamingPage(),CleanPage(),MessagesPage(),MorePage()];
  @override Widget build(BuildContext c)=>Scaffold(
    body:pages[i],
    bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(v)=>setState(()=>i=v),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.bolt_outlined),selectedIcon:Icon(Icons.bolt),label:'Turbo'),
        NavigationDestination(icon:Icon(Icons.sports_esports_outlined),selectedIcon:Icon(Icons.sports_esports),label:'Gaming'),
        NavigationDestination(icon:Icon(Icons.cleaning_services_outlined),selectedIcon:Icon(Icons.cleaning_services),label:'Clean'),
        NavigationDestination(icon:Icon(Icons.notifications_none),selectedIcon:Icon(Icons.notifications),label:'Messages'),
        NavigationDestination(icon:Icon(Icons.more_horiz),selectedIcon:Icon(Icons.more_horiz),label:'More'),
      ]));
}

class HomePage extends StatefulWidget{const HomePage({super.key});
  @override State<HomePage> createState()=>_HomePageState();}
class _HomePageState extends State<HomePage>{
  int battery=0; String device='Android device'; Timer? timer;
  @override void initState(){super.initState();refresh();timer=Timer.periodic(const Duration(seconds:8),(_)=>refresh());}
  Future<void> refresh()async{try{
    final b=await Battery().batteryLevel; final a=await DeviceInfoPlugin().androidInfo;
    if(mounted)setState(()=>{battery=b,device='${a.manufacturer} ${a.model}'});
  }catch(_){}} 
  @override void dispose(){timer?.cancel();super.dispose();}
  @override Widget build(BuildContext c){
    final score=(70+battery~/10).clamp(0,99);
    return SafeArea(child:RefreshIndicator(onRefresh:refresh,child:ListView(
      padding:const EdgeInsets.all(16),children:[
        const LogoHeader(),const SizedBox(height:16),
        const Text('LIVE DASHBOARD',style:TextStyle(color:Color(0xFFFF1744),fontWeight:FontWeight.w900,letterSpacing:1.5)),
        const Text('REAL PERFORMANCE HEALTH',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
        const SizedBox(height:16),HealthCard(score:score),const SizedBox(height:12),
        Row(children:[Expanded(child:StatCard(icon:Icons.memory,title:'RAM',value:'LIVE')),
          const SizedBox(width:10),Expanded(child:StatCard(icon:Icons.battery_full,title:'BATTERY',value:'$battery%'))]),
        const SizedBox(height:10),
        Row(children:[Expanded(child:StatCard(icon:Icons.phone_android,title:'DEVICE',value:device)),
          const SizedBox(width:10),const Expanded(child:StatCard(icon:Icons.thermostat,title:'THERMAL',value:'MONITOR'))]),
        const SizedBox(height:14),
        ActionCard(icon:Icons.auto_fix_high,title:'ONE-TAP OPTIMIZE',
          subtitle:'Run safe performance checks and cleanup.',onTap:()=>toast(c,'Optimization scan completed.')),
      ])));
  }
}

class HealthCard extends StatelessWidget{final int score;const HealthCard({super.key,required this.score});
  @override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.all(20),
    decoration:BoxDecoration(color:const Color(0xFF160D10),borderRadius:BorderRadius.circular(20),
      border:Border.all(color:const Color(0x55FF1744))),
    child:Row(children:[SizedBox(width:90,height:90,child:Stack(alignment:Alignment.center,children:[
      CircularProgressIndicator(value:score/100,strokeWidth:8,color:const Color(0xFFFF1744),backgroundColor:Colors.white10),
      Text('$score%',style:const TextStyle(fontWeight:FontWeight.w900))])),
      const SizedBox(width:16),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('PERFORMANCE HEALTH',style:TextStyle(fontWeight:FontWeight.w900)),
        SizedBox(height:6),Text('Live device health overview',style:TextStyle(color:Colors.white54)),
        SizedBox(height:6),Text('STATUS: MONITORING',style:TextStyle(color:Color(0xFFFF1744),fontWeight:FontWeight.w800))]))]));
}

class StatCard extends StatelessWidget{final IconData icon;final String title,value;
  const StatCard({super.key,required this.icon,required this.title,required this.value});
  @override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.all(14),
    decoration:BoxDecoration(color:const Color(0xFF111111),borderRadius:BorderRadius.circular(16),
      border:Border.all(color:Colors.white10)),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Icon(icon,color:const Color(0xFFFF1744)),const SizedBox(height:8),
      Text(title,style:const TextStyle(color:Colors.white54,fontSize:11,fontWeight:FontWeight.w800)),
      Text(value,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w900))]));
}

class ActionCard extends StatelessWidget{final IconData icon;final String title,subtitle;final VoidCallback? onTap;
  const ActionCard({super.key,required this.icon,required this.title,required this.subtitle,this.onTap});
  @override Widget build(BuildContext c)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(17),
    child:Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:const Color(0xFF111111),
      borderRadius:BorderRadius.circular(17),border:Border.all(color:Colors.white10)),
      child:Row(children:[Container(width:48,height:48,decoration:BoxDecoration(color:const Color(0x1AFF1744),borderRadius:BorderRadius.circular(14)),
        child:Icon(icon,color:const Color(0xFFFF1744))),const SizedBox(width:12),
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(title,style:const TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:4),
          Text(subtitle,style:const TextStyle(color:Colors.white54,fontSize:12))])),
        if(onTap!=null)const Icon(Icons.chevron_right,color:Colors.white38)])));
}

class FeaturePage extends StatelessWidget{
  final String title,subtitle;final List<String> features;
  const FeaturePage({super.key,required this.title,required this.subtitle,required this.features});
  @override Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
    const LogoHeader(),const SizedBox(height:16),Text(title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900)),
    Text(subtitle,style:const TextStyle(color:Colors.white54)),const SizedBox(height:14),
    for(final f in features)Padding(padding:const EdgeInsets.only(bottom:10),
      child:ActionCard(icon:Icons.bolt,title:f,subtitle:'Safe Android-supported diagnostic/action.',
        onTap:()=>toast(c,'$f opened.'))),
  ]));
}
class TurboPage extends StatelessWidget{const TurboPage({super.key});
  @override Widget build(BuildContext c)=>const FeaturePage(title:'TURBO MODE',subtitle:'Safe performance tools',
    features:['One-Tap Optimize','Refresh Optimizer','Memory Cleanup','Battery Optimizer','Thermal Monitor','Network Test']);}
class GamingPage extends StatelessWidget{const GamingPage({super.key});
  @override Widget build(BuildContext c)=>FeaturePage(title:'GAMING CENTER',subtitle:'Gaming tools and launch actions',
    features:['Optimize @ Launch Free Fire','Optimize @ Launch Free Fire MAX','Game Mode','Gaming RAM Monitor','Network / Ping Monitor','Game Temperature Alert','Gaming Battery Monitor','Game Session Monitor','FPS Monitor (supported devices)']);}
class CleanPage extends StatelessWidget{const CleanPage({super.key});
  @override Widget build(BuildContext c)=>const FeaturePage(title:'CLEAN CENTER',subtitle:'Storage analysis and safe cleanup',
    features:['Clear Cache','Storage Cleanup','Junk Scanner','Large Files Scanner','Duplicate Files Scanner','App Usage / App Info']);}
class MessagesPage extends StatelessWidget{const MessagesPage({super.key});
  @override Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
    const Text('MESSAGES',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),const SizedBox(height:14),
    ActionCard(icon:Icons.campaign,title:'ANNOUNCEMENTS',subtitle:'Admin announcements will appear here.',
      onTap:()=>toast(c,'No new announcements.'))]));}
class MorePage extends StatelessWidget{const MorePage({super.key});
  @override Widget build(BuildContext c)=>const FeaturePage(title:'MORE',subtitle:'Tools and device information',
    features:['Live Dashboard','Device Information','Performance Health Score','Battery Health Information','Optimization History']);}

void toast(BuildContext c,String s)=>ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text(s)));
