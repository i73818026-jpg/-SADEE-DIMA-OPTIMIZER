package com.sadee.dima.optimizer
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
