# SADEE X DIMA OPTIMIZER

Flutter starter project for the SADEE X DIMA OPTIMIZER app.

Included:
- 7 Days / 1 Month / Lifetime license selection
- WhatsApp ordering to +94 76 847 2404
- License-key screen
- Supabase connection
- Live dashboard
- Turbo / Gaming / Clean / Messages / More
- Free Fire / Free Fire MAX optimizer UI
- Device and battery information
- Dark red/black gaming UI

Run:
flutter pub get
flutter run

Important:
The original logo image is not available as a current file attachment in this turn, so assets/logo.png is a placeholder. Replace it with the exact logo image.
