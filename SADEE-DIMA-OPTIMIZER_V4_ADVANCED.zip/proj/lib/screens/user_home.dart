import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import '../services/key_service.dart';
import '../services/optimizer_service.dart';

class UserHomeScreen extends StatefulWidget {
  const UserHomeScreen({super.key});
  @override
  State<UserHomeScreen> createState() => _UserHomeScreenState();
}

class _UserHomeScreenState extends State<UserHomeScreen> {
  static const _bg = Color(0xFF090719);
  static const _panel = Color(0xFF191735);
  static const _cyan = Color(0xFF00F0FF);
  static const _green = Color(0xFF4DFFB0);
  static const _purple = Color(0xFF9C4DFF);
  static const _red = Color(0xFFFF4F5E);
  static const _channel = MethodChannel('sadee_x_dima/system');

  final KeyService _keyService = KeyService();
  final OptimizerService _optimizerService = OptimizerService();
  final TextEditingController _keyController = TextEditingController();

  int _tab = 0;
  bool _verified = false;
  bool _lifetime = false;
  bool _scanning = false;
  bool _optimized = false;
  bool _launching = false;
  DateTime? _expiresAt;
  Duration _remaining = Duration.zero;
  Timer? _timer;
  Map<String, String> _device = {};
  int _cacheBytes = 0;
  String _scanStatus = 'Ready for smart scan';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final info = await _optimizerService.getDeviceInfo();
    final cache = await _optimizerService.getAppCacheBytes();
    if (!mounted) return;
    setState(() { _device = info; _cacheBytes = cache; });
  }

  Future<void> _activate() async {
    final key = _keyController.text.trim();
    if (key.isEmpty) return;
    setState(() => _scanning = true);
    final res = await _keyService.validateAndActivateKey(key);
    if (!mounted) return;
    setState(() => _scanning = false);
    if (res['success'] == true) {
      setState(() { _verified = true; _lifetime = res['isLifetime'] ?? false; _expiresAt = res['expiresAt']; });
      if (!_lifetime) _startTimer();
      _toast('VIP activated successfully', _green);
    } else {
      _toast(res['message'].toString(), _red);
    }
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_expiresAt == null) return;
      final left = _expiresAt!.difference(DateTime.now());
      if (!mounted) return;
      if (left.isNegative) { setState(() => _verified = false); _timer?.cancel(); }
      else setState(() => _remaining = left);
    });
  }

  Future<void> _smartScan() async {
    if (!_verified) { _toast('Activate a license first', Colors.orange); return; }
    setState(() { _scanning = true; _scanStatus = 'Scanning app cache...'; _optimized = false; });
    await Future.delayed(const Duration(milliseconds: 700));
    final bytes = await _optimizerService.getAppCacheBytes();
    if (!mounted) return;
    setState(() { _cacheBytes = bytes; _scanStatus = 'Scan complete'; _scanning = false; });
    _toast('Found ${_optimizerService.formatBytes(bytes)} of app cache', _cyan);
  }

  Future<void> _cleanCache() async {
    if (!_verified) { _toast('Activate a license first', Colors.orange); return; }
    setState(() { _scanning = true; _scanStatus = 'Cleaning app cache...'; });
    final cleared = await _optimizerService.clearAppCache();
    await _load();
    if (!mounted) return;
    setState(() { _scanning = false; _optimized = true; _scanStatus = 'Clean complete'; });
    _toast('Cleaned ${_optimizerService.formatBytes(cleared)}', _green);
  }

  Future<void> _optimize() async {
    if (!_verified) { _toast('Activate a license first', Colors.orange); return; }
    setState(() { _scanning = true; _scanStatus = 'Running safe device optimization...'; _optimized = false; });
    await Future.delayed(const Duration(seconds: 2));
    await _load();
    if (!mounted) return;
    setState(() { _scanning = false; _optimized = true; _scanStatus = 'Optimization finished'; });
    _toast('Optimization finished', _green);
  }

  Future<void> _launchGame({required bool max}) async {
    if (!_verified) { _toast('Activate a license first', Colors.orange); return; }
    setState(() => _launching = true);
    await Future.delayed(const Duration(milliseconds: 800));
    final pkg = max ? 'com.dts.freefiremax' : 'com.dts.freefireth';
    final launched = await _channel.invokeMethod<bool>('launchPackage', {'package': pkg}) ?? false;
    if (!mounted) return;
    setState(() => _launching = false);
    if (!launched) _toast(max ? 'Free Fire MAX is not installed' : 'Free Fire is not installed', _red);
  }

  void _toast(String text, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), backgroundColor: color, behavior: SnackBarBehavior.floating));
  }

  String _timeLeft() => _lifetime ? '∞ LIFETIME' : '${_remaining.inDays}d ${_remaining.inHours % 24}h ${_remaining.inMinutes % 60}m';

  @override
  void dispose() { _timer?.cancel(); _keyController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: const Color(0xFF1D1A3D),
        elevation: 0,
        centerTitle: true,
        title: const Text('sadee X dima optimizer', style: TextStyle(color: _cyan, fontWeight: FontWeight.w900, letterSpacing: 1.3)),
      ),
      body: SafeArea(child: IndexedStack(index: _tab, children: [_home(), _turbo(), _gaming(), _cleaner(), _more()])),
      bottomNavigationBar: NavigationBar(
        backgroundColor: _panel,
        indicatorColor: _cyan.withValues(alpha: .16),
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: _cyan), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.bolt_outlined), selectedIcon: Icon(Icons.bolt, color: _cyan), label: 'Turbo'),
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports, color: _cyan), label: 'Gaming'),
          NavigationDestination(icon: Icon(Icons.cleaning_services_outlined), selectedIcon: Icon(Icons.cleaning_services, color: _cyan), label: 'Clean'),
          NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz, color: _cyan), label: 'More'),
        ],
      ),
    );
  }

  Widget _home() => _page([
    _vipCard(),
    const SizedBox(height: 14),
    _healthCard(),
    const SizedBox(height: 14),
    _deviceCard(),
    const SizedBox(height: 14),
    _actionButton('SMART OPTIMIZE', Icons.auto_awesome, _optimize, _purple),
    const SizedBox(height: 12),
    _actionButton('SCAN & CLEAN CACHE', Icons.cleaning_services, _smartScan, _red),
    if (_optimized) _successCard(),
  ]);

  Widget _turbo() => _page([
    _sectionTitle('TURBO CENTER', 'Safe performance actions for your device', Icons.bolt),
    _modeCard('PERFORMANCE MODE', 'Close this app’s temporary cache and refresh device stats.', Icons.speed, _purple, _optimize),
    _modeCard('BALANCED MODE', 'Keep the device responsive without aggressive actions.', Icons.balance, _cyan, _smartScan),
    _modeCard('COOL DOWN', 'Refresh monitoring and clear this app temporary files.', Icons.ac_unit, _green, _cleanCache),
  ]);

  Widget _gaming() => _page([
    _sectionTitle('GAMING CENTER', 'Optimize safely, then launch the game', Icons.sports_esports),
    _gameCard('FREE FIRE', 'com.dts.freefireth', false),
    const SizedBox(height: 12),
    _gameCard('FREE FIRE MAX', 'com.dts.freefiremax', true),
    const SizedBox(height: 12),
    _infoBox('AUTO LAUNCH', 'The button first runs the app flow, then launches the installed game package.'),
  ]);

  Widget _cleaner() => _page([
    _sectionTitle('SMART CLEANER', 'Real scan for this optimizer app cache', Icons.cleaning_services),
    _scanCard(),
    const SizedBox(height: 12),
    _cleanOption('APP CACHE', 'Temporary files created by SADEE X DIMA', Icons.delete_sweep, _cacheBytes, _cleanCache),
    _cleanOption('DEEP SCAN', 'Re-scan temporary cache before cleaning', Icons.radar, _cacheBytes, _smartScan),
    _infoBox('ANDROID LIMIT', 'Other apps’ private caches cannot be silently deleted by a normal Android app. This cleaner only removes data this app is allowed to access.'),
  ]);

  Widget _more() => _page([
    _sectionTitle('DEVICE CENTER', 'Information and license status', Icons.phone_android),
    _deviceCard(),
    const SizedBox(height: 12),
    _infoBox('LICENSE', _verified ? (_lifetime ? 'Lifetime VIP active' : 'VIP active • ${_timeLeft()} remaining') : 'No active license'),
    const SizedBox(height: 12),
    _actionButton('REFRESH DEVICE DATA', Icons.refresh, _load, _cyan),
  ]);

  Widget _page(List<Widget> children) => RefreshIndicator(color: _cyan, onRefresh: _load, child: ListView(padding: const EdgeInsets.fromLTRB(16, 14, 16, 28), children: children));

  Widget _vipCard() => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF9B1FCC), Color(0xFF6337C7)]), borderRadius: BorderRadius.circular(22), boxShadow: const [BoxShadow(color: Color(0x449B1FCC), blurRadius: 18)]), child: Row(children: [Icon(_verified ? Icons.verified : Icons.lock, color: _green, size: 34), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_verified ? 'VIP ACTIVE' : 'VIP LOCKED', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)), Text(_verified ? _timeLeft() : 'Activate your license', style: const TextStyle(color: _cyan, fontWeight: FontWeight.w800))]), if (!_verified) IconButton(onPressed: _licenseDialog, icon: const Icon(Icons.key, color: Colors.white))]));

  Widget _healthCard() { final ram = int.tryParse((_device['ramPercentage'] ?? '0').replaceAll('%','')) ?? 0; final score = (100 - ram).clamp(5, 99); return _card(Column(children: [Row(children: [const Icon(Icons.favorite, color: _green), const SizedBox(width: 10), const Text('SYSTEM HEALTH', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), const Spacer(), Text('$score%', style: const TextStyle(color: _green, fontSize: 24, fontWeight: FontWeight.w900))]), const SizedBox(height: 12), LinearProgressIndicator(value: score / 100, minHeight: 9, borderRadius: BorderRadius.circular(8), backgroundColor: Colors.white10, color: _green)])); }

  Widget _deviceCard() => _card(Column(children: [Row(children: [const Icon(Icons.phone_android, color: _cyan), const SizedBox(width: 10), const Text('DEVICE STATUS & DETAILS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))]), const Divider(color: Colors.white24, height: 22), _row('Brand', _device['brand'] ?? 'Loading...'), _row('Model', _device['model'] ?? 'Loading...'), _row('Android', 'Android ${_device['androidVersion'] ?? '...'}'), _row('RAM', '${_device['usedRam'] ?? '...'} / ${_device['totalRam'] ?? '...'} (${_device['ramPercentage'] ?? '...'})')]));

  Widget _sectionTitle(String title, String sub, IconData icon) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Row(children: [Icon(icon, color: _cyan, size: 30), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)), Text(sub, style: const TextStyle(color: Colors.white54, fontSize: 12))]))]));

  Widget _modeCard(String title, String sub, IconData icon, Color color, VoidCallback action) => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: color), const SizedBox(width: 10), Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))]), const SizedBox(height: 8), Text(sub, style: const TextStyle(color: Colors.white60, height: 1.35)), const SizedBox(height: 12), OutlinedButton(onPressed: _verified ? action : null, child: const Text('RUN MODE'))]));

  Widget _gameCard(String title, String pkg, bool max) => _card(Column(children: [Row(children: [const Icon(Icons.sports_esports, color: _green), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900))), Text(max ? 'MAX' : 'NORMAL', style: const TextStyle(color: _cyan, fontWeight: FontWeight.bold))]), const SizedBox(height: 8), Text(pkg, style: const TextStyle(color: Colors.white38, fontSize: 11)), const SizedBox(height: 12), SizedBox(width: double.infinity, height: 50, child: ElevatedButton.icon(onPressed: _launching ? null : () => _launchGame(max: max), icon: _launching ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.rocket_launch), label: const Text('OPTIMIZE & LAUNCH')))]));

  Widget _scanCard() => _card(Column(children: [Row(children: [const Icon(Icons.radar, color: _cyan), const SizedBox(width: 10), const Text('SMART SCAN', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), const Spacer(), Text(_optimizerService.formatBytes(_cacheBytes), style: const TextStyle(color: _green, fontWeight: FontWeight.bold))]), const SizedBox(height: 10), if (_scanning) const SpinKitThreeBounce(color: _cyan, size: 28) else Text(_scanStatus, style: const TextStyle(color: Colors.white60)), const SizedBox(height: 10), Row(children: [Expanded(child: OutlinedButton(onPressed: _scanning ? null : _smartScan, child: const Text('SCAN NOW'))), const SizedBox(width: 8), Expanded(child: ElevatedButton(onPressed: _scanning ? null : _cleanCache, child: const Text('CLEAN')))])]));

  Widget _cleanOption(String title, String sub, IconData icon, int bytes, VoidCallback action) => _card(Row(children: [Icon(icon, color: _cyan), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), Text(sub, style: const TextStyle(color: Colors.white54, fontSize: 12))])), Text(_optimizerService.formatBytes(bytes), style: const TextStyle(color: _green, fontWeight: FontWeight.bold)), const SizedBox(width: 8), IconButton(onPressed: _verified ? action : null, icon: const Icon(Icons.chevron_right, color: Colors.white70))]));

  Widget _actionButton(String text, IconData icon, VoidCallback action, Color color) => SizedBox(width: double.infinity, height: 56, child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: color, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), onPressed: _scanning ? null : action, icon: Icon(icon, color: Colors.white), label: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))));

  Widget _successCard() => Container(margin: const EdgeInsets.only(top: 14), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: _green.withValues(alpha: .10), border: Border.all(color: _green), borderRadius: BorderRadius.circular(14)), child: const Row(children: [Icon(Icons.check_circle, color: _green), SizedBox(width: 10), Expanded(child: Text('Optimization completed. Temporary cache actions and device monitoring were refreshed.', style: TextStyle(color: _green, fontWeight: FontWeight.bold)))]));

  Widget _infoBox(String title, String text) => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: _cyan, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(text, style: const TextStyle(color: Colors.white60, height: 1.35))]));

  Widget _card(Widget child) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white10)), child: child);
  Widget _row(String a, String b) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [Text(a, style: const TextStyle(color: Colors.white54)), const Spacer(), Flexible(child: Text(b, textAlign: TextAlign.right, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)))]));

  Future<void> _licenseDialog() async { await showDialog(context: context, builder: (_) => AlertDialog(backgroundColor: _panel, title: const Text('Activate VIP', style: TextStyle(color: Colors.white)), content: TextField(controller: _keyController, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(hintText: 'SXD-XXXX-XXXX-XXXX', hintStyle: TextStyle(color: Colors.white38))), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCEL')), FilledButton(onPressed: () { Navigator.pop(context); _activate(); }, child: const Text('ACTIVATE'))])); }
}
