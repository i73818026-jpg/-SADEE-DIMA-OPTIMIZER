# SADEE X DIMA OPTIMIZER V10 PRO CYBER

Real Android telemetry + real accessible-storage cleanup + Free Fire/Free Fire MAX launcher + license countdown.

## Included
- Smart Clean
- Downloads Analyzer
- Old/Large/Duplicate/Empty Folder cleaners
- APK and ZIP/RAR cleaner
- Screenshots / Screen Recordings / Image / Video / Audio cleaner
- WhatsApp media analyzer
- Trash analyzer
- Real app-owned cache cleanup and Android memory trim hint
- Battery, thermal, storage, network and CPU monitors
- Device health scan
- Gaming pre-clean
- Free Fire / Free Fire MAX detection and launch
- Gaming session timer and telemetry
- Before/after cleanup report and local operation history
- Live license countdown
- Cyber/HUD visual style

## Android reality
The app never claims to inject into a game, bypass anti-cheat, change CPU voltage/frequency, or silently delete another app's private data. Shared-storage cleanup uses Android's permitted access and user-selected files.

## Supabase
Run DATABASE_SETUP.sql in the Supabase SQL editor before using license/admin features.
