-- 1. Create License Keys Table
CREATE TABLE IF NOT EXISTS public.license_keys (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    key_code TEXT UNIQUE NOT NULL,
    duration_days INT NOT NULL, -- 1, 3, 5, 7, 14, 30, -1 (Lifetime)
    device_id TEXT DEFAULT NULL,
    status TEXT DEFAULT 'UNUSED', -- UNUSED, ACTIVE, PAUSED, EXPIRED
    activated_at TIMESTAMPTZ DEFAULT NULL,
    expires_at TIMESTAMPTZ DEFAULT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Create App Updates Table
CREATE TABLE IF NOT EXISTS public.app_updates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    version_code INT NOT NULL,
    version_name TEXT NOT NULL,
    download_url TEXT NOT NULL,
    force_update BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS) - Optional/Recommended
ALTER TABLE public.license_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_updates ENABLE ROW LEVEL SECURITY;

-- Allow public access for anon key
DROP POLICY IF EXISTS "Public License Keys Policy" ON public.license_keys;
CREATE POLICY "Public License Keys Policy" ON public.license_keys FOR ALL USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Public App Updates Policy" ON public.app_updates;
CREATE POLICY "Public App Updates Policy" ON public.app_updates FOR ALL USING (true) WITH CHECK (true);

-- Optional admin analytics tables for PRO CYBER V10
CREATE TABLE IF NOT EXISTS public.app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.orders (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    order_ref TEXT UNIQUE,
    customer_name TEXT,
    customer_phone TEXT,
    plan_days INT NOT NULL,
    amount_lkr NUMERIC(12,2) NOT NULL,
    status TEXT DEFAULT 'PENDING',
    license_key TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.announcements (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT DEFAULT 'INFO',
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.activity_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    action TEXT NOT NULL,
    target TEXT,
    details TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.app_settings(key,value) VALUES
('price_7_days','500'),
('price_30_days','1000'),
('price_lifetime','2200'),
('whatsapp_support','94768472404')
ON CONFLICT (key) DO NOTHING;

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

-- NOTE: For production, replace broad policies with authenticated admin/user policies.
DROP POLICY IF EXISTS "Public App Settings Policy" ON public.app_settings;
CREATE POLICY "Public App Settings Policy" ON public.app_settings FOR ALL USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Public Orders Policy" ON public.orders;
CREATE POLICY "Public Orders Policy" ON public.orders FOR ALL USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "Public Announcements Policy" ON public.announcements;
CREATE POLICY "Public Announcements Policy" ON public.announcements FOR SELECT USING (enabled = true);
DROP POLICY IF EXISTS "Public Activity Logs Policy" ON public.activity_logs;
CREATE POLICY "Public Activity Logs Policy" ON public.activity_logs FOR ALL USING (true) WITH CHECK (true);
