# SADEE X DIMA OPTIMIZER — V7 REAL CYBER

English UI with a dark cyber/gaming visual style.

## Included real features
- Smart Clean (safe shared-storage junk/temp/trash/empty-folder cleanup + app cache cleanup)
- Downloads Analyzer
- Old Files Cleaner / Finder
- Large Files Finder
- Duplicate Finder (SHA-256)
- Empty Folder Cleaner
- APK Cleaner
- ZIP/RAR/Archive Cleaner
- Screenshots Cleaner
- Screen Recording Cleaner
- Image / Video / Audio Cleaner
- WhatsApp Media Analyzer
- Trash Analyzer
- Real app-owned memory trim + cache cleanup
- Battery / thermal / storage / network / CPU monitors
- Device Health Scan
- Gaming Pre-Clean (temporary/junk files only)
- Free Fire / Free Fire MAX detection and launcher
- Gaming session timer and live battery/temperature/thermal monitoring
- Before/After cleanup report and local operation history
- License status shown at the top of Home with remaining time (for example `22h 14m`)

## Safety / Android limits
The app only reports or performs actions available to a normal Android application. It does not inject game code, bypass anti-cheat, modify another app's private data, or claim fake FPS/RAM gains.

Shared-storage scanning/deletion requires Android's supported all-files access flow where applicable.
