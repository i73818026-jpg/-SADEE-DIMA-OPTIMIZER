# SADEE X DIMA OPTIMIZER — V6 FINAL

This package combines the V6 optimizer/cleaner/gaming source with the existing
working license/admin/Supabase project structure.

Included:
- License gate before user app
- 7 DAYS / 1 MONTH / LIFETIME purchase UI
- WhatsApp order flow to +94 76 847 2404
- Supabase license validation and device binding
- RAM/system metrics
- CPU/device/system metrics exposed by Android APIs
- battery/temperature/thermal information where the device API exposes it
- storage information
- performance health UI
- performance/balanced/cool-down actions
- cache/temporary/download/large/old/duplicate/empty-folder scanning
- selectable cleaner results
- progress/cancel handling
- operation history
- Free Fire / Free Fire MAX launch center
- gaming session timer and available battery/temperature/refresh-rate data
- device center
- User and Admin product flavors
- GitHub Actions APK build

Android limitation:
The app does not claim root-level system modification, silent clearing of
other apps' private data, or guaranteed FPS manipulation. Features use
permissions/public Android APIs where available.

## V6 REAL CLEANER + CYBER GAMING EXPANSION
- Real shared-storage scanning with user selection before deletion.
- Large file thresholds: 100 MB / 500 MB / 1 GB.
- Old file thresholds: 30 / 90 / 180 days.
- Duplicate detection by SHA-256 for same-size candidates.
- Downloads, APK, ZIP/RAR/archive, screenshots, screen recordings, images, videos, audio and media categories.
- WhatsApp media categories when accessible through shared storage permissions.
- Trash/recycle-folder analyzer, .nomedia, logs, dumps/crash files and temporary/partial files.
- SMART CLEAN scans categories and presents actual candidates; it never pretends that inaccessible Android private data was cleaned.
- RAM cleanup only clears app-owned cache and requests garbage collection; Android controls system-wide memory reclaim.
- Gaming tools remain safe: Free Fire/Free Fire MAX launch, pre-launch app-owned cleanup/memory hint, live battery/temperature/thermal monitoring and session timer.
- Cyber/gaming visual style is cosmetic; no game injection, anti-cheat bypass or fake FPS/boost claims.
