import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/key_service.dart';

class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({super.key});

  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {
  final KeyService _keyService = KeyService();
  final TextEditingController _searchController = TextEditingController();

  int _selectedDuration = 7;
  int _tab = 0;
  List<Map<String, dynamic>> _keysList = [];
  bool _isLoading = false;
  String _filter = 'ALL';

  static const _bg = Color(0xFF070A0F);
  static const _panel = Color(0xFF10151C);
  static const _panel2 = Color(0xFF151B23);
  static const _cyan = Color(0xFF00E5FF);
  static const _green = Color(0xFF00F5A0);
  static const _purple = Color(0xFF9C5CFF);
  static const _orange = Color(0xFFFFB84D);

  final List<int> _durations = [7, 30, -1];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() => setState(() {}));
    _refreshKeys();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _refreshKeys() async {
    if (!mounted) return;
    setState(() => _isLoading = true);
    try {
      final keys = await _keyService
          .fetchAllKeys()
          .timeout(const Duration(seconds: 12));
      if (!mounted) return;
      setState(() {
        _keysList = keys;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _snack('License data load failed', error: true);
    }
  }

  Future<void> _generateKey() async {
    try {
      final key = await _keyService.createLicenseKey(_selectedDuration);
      if (!mounted) return;
      await _refreshKeys();
      if (!mounted) return;
      await _showGeneratedKey(key);
    } catch (e) {
      if (mounted) _snack('Key generation failed', error: true);
    }
  }

  Future<void> _showGeneratedKey(String key) async {
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _panel2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Row(
          children: [
            Icon(Icons.verified_rounded, color: _green),
            SizedBox(width: 10),
            Text('KEY READY', style: TextStyle(color: Colors.white)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.black26,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _cyan.withOpacity(.35)),
              ),
              child: SelectableText(
                key,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: _cyan,
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              _selectedDuration == -1
                  ? 'LIFETIME LICENSE'
                  : '${_selectedDuration.toString()} DAYS LICENSE',
              style: const TextStyle(color: Colors.white60),
            ),
          ],
        ),
        actions: [
          TextButton.icon(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: key));
              if (mounted) {
                Navigator.pop(context);
                _snack('Key copied');
              }
            },
            icon: const Icon(Icons.copy_rounded, color: _orange),
            label: const Text('COPY KEY', style: TextStyle(color: _orange)),
          ),
        ],
      ),
    );
  }

  void _snack(String text, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor: error ? Colors.redAccent : _green,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  int _count(String status) =>
      _keysList.where((k) => (k['status'] ?? 'UNUSED') == status).length;

  int _countPlan(int days) =>
      _keysList.where((k) => (k['duration_days'] ?? 0) == days).length;

  List<Map<String, dynamic>> get _filteredKeys {
    final q = _searchController.text.trim().toLowerCase();
    return _keysList.where((k) {
      final status = (k['status'] ?? 'UNUSED').toString().toUpperCase();
      if (_filter != 'ALL' && status != _filter) return false;
      if (q.isEmpty) return true;
      final key = (k['key_code'] ?? '').toString().toLowerCase();
      final device = (k['device_id'] ?? '').toString().toLowerCase();
      return key.contains(q) || device.contains(q) || status.toLowerCase().contains(q);
    }).toList();
  }

  Future<void> _changeStatus(Map<String, dynamic> k, String action) async {
    final key = k['key_code'] as String;
    try {
      if (action == 'DELETE') {
        final ok = await _confirm(
          'Delete license?',
          'This will permanently remove $key.',
        );
        if (!ok) return;
        await _keyService.deleteKey(key);
      } else {
        final status = action == 'UNPAUSE'
            ? 'ACTIVE'
            : action == 'PAUSE'
                ? 'PAUSED'
                : 'EXPIRED';
        await _keyService.updateKeyStatus(key, status);
      }
      await _refreshKeys();
      if (mounted) _snack('License updated');
    } catch (e) {
      if (mounted) _snack('Action failed', error: true);
    }
  }

  Future<bool> _confirm(String title, String message) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _panel2,
        title: Text(title, style: const TextStyle(color: Colors.white)),
        content: Text(message, style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('CONFIRM'),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        titleSpacing: 18,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'SADEE X DIMA',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.1,
              ),
            ),
            Text(
              'ADMIN CONTROL CENTER',
              style: TextStyle(color: _cyan, fontSize: 10, letterSpacing: 2),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: _refreshKeys,
            icon: const Icon(Icons.refresh_rounded, color: _cyan),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: _isLoading && _keysList.isEmpty
            ? const Center(child: CircularProgressIndicator(color: _cyan))
            : IndexedStack(
                index: _tab,
                children: [
                  _dashboard(),
                  _licenseManager(),
                  _usersView(),
                  _settingsView(),
                ],
              ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: _panel,
        indicatorColor: _cyan.withOpacity(.15),
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard, color: _cyan),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.key_outlined),
            selectedIcon: Icon(Icons.key, color: _cyan),
            label: 'Licenses',
          ),
          NavigationDestination(
            icon: Icon(Icons.devices_other_outlined),
            selectedIcon: Icon(Icons.devices_other, color: _cyan),
            label: 'Users',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings, color: _cyan),
            label: 'Settings',
          ),
        ],
      ),
    );
  }

  Widget _dashboard() {
    final active = _count('ACTIVE');
    final unused = _count('UNUSED');
    final paused = _count('PAUSED');
    final expired = _count('EXPIRED');

    return RefreshIndicator(
      color: _cyan,
      onRefresh: _refreshKeys,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          _statusBanner(),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.55,
            children: [
              _statCard('ACTIVE', '$active', Icons.verified_rounded, _green),
              _statCard('UNUSED', '$unused', Icons.vpn_key_rounded, _cyan),
              _statCard('PAUSED', '$paused', Icons.pause_circle, _orange),
              _statCard('EXPIRED', '$expired', Icons.timer_off, Colors.redAccent),
            ],
          ),
          const SizedBox(height: 16),
          _sectionTitle('QUICK LICENSE GENERATOR', Icons.flash_on),
          const SizedBox(height: 10),
          _generator(),
          const SizedBox(height: 16),
          _sectionTitle('PLAN OVERVIEW', Icons.bar_chart_rounded),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _planCard('7 DAYS', 'LKR 500', _countPlan(7), _purple)),
              const SizedBox(width: 8),
              Expanded(child: _planCard('1 MONTH', 'LKR 1,000', _countPlan(30), _cyan)),
              const SizedBox(width: 8),
              Expanded(child: _planCard('LIFETIME', 'LKR 2,200', _countPlan(-1), _green)),
            ],
          ),
          const SizedBox(height: 16),
          _sectionTitle('RECENT LICENSES', Icons.history_rounded),
          const SizedBox(height: 8),
          ..._keysList.take(5).map(_compactLicense),
        ],
      ),
    );
  }

  Widget _statusBanner() {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF111E29), Color(0xFF0B1219)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _green.withOpacity(.25)),
      ),
      child: const Row(
        children: [
          Icon(Icons.shield_rounded, color: _green, size: 30),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('SYSTEM ONLINE',
                    style: TextStyle(color: _green, fontWeight: FontWeight.w900)),
                SizedBox(height: 3),
                Text('Supabase license service connected',
                    style: TextStyle(color: Colors.white60, fontSize: 12)),
              ],
            ),
          ),
          Icon(Icons.circle, color: _green, size: 11),
        ],
      ),
    );
  }

  Widget _statCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _panel,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: color.withOpacity(.16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(icon, color: color, size: 22),
          Text(value,
              style: const TextStyle(
                  color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900)),
          Text(title, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: _cyan, size: 18),
        const SizedBox(width: 8),
        Text(title,
            style: const TextStyle(
                color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: .6)),
      ],
    );
  }

  Widget _generator() {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: _panel,
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: _purple.withOpacity(.28)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: _durationChoice(7, '7 DAYS', 'LKR 500', _purple)),
              const SizedBox(width: 8),
              Expanded(child: _durationChoice(30, '1 MONTH', 'LKR 1,000', _cyan)),
              const SizedBox(width: 8),
              Expanded(child: _durationChoice(-1, 'LIFETIME', 'LKR 2,200', _green)),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: _selectedDuration == -1 ? _green : _cyan,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
              ),
              onPressed: _generateKey,
              icon: const Icon(Icons.key_rounded),
              label: const Text('GENERATE KEY', style: TextStyle(fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _durationChoice(int value, String title, String price, Color color) {
    final selected = _selectedDuration == value;
    return InkWell(
      borderRadius: BorderRadius.circular(13),
      onTap: () => setState(() => _selectedDuration = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 5),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(.16) : Colors.black12,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: selected ? color : Colors.white12, width: selected ? 1.5 : 1),
        ),
        child: Column(
          children: [
            Text(title, textAlign: TextAlign.center,
                style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text(price, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70, fontSize: 9)),
          ],
        ),
      ),
    );
  }

  Widget _planCard(String title, String price, int count, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _panel,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(price, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
          const SizedBox(height: 8),
          Text('$count keys', style: const TextStyle(color: Colors.white54, fontSize: 10)),
        ],
      ),
    );
  }

  Widget _compactLicense(Map<String, dynamic> k) {
    final status = (k['status'] ?? 'UNUSED').toString();
    final color = _statusColor(status);
    final key = (k['key_code'] ?? '').toString();
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(14)),
      child: Row(
        children: [
          Icon(Icons.key_rounded, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(key, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                Text(
                  '${k['duration_days'] == -1 ? 'Lifetime' : '${k['duration_days']} days'} • ${k['device_id'] ?? 'Not bound'}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white54, fontSize: 10),
                ),
              ],
            ),
          ),
          _statusChip(status, color),
        ],
      ),
    );
  }

  Widget _licenseManager() {
    final list = _filteredKeys;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          child: TextField(
            controller: _searchController,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Search key / device / status...',
              hintStyle: const TextStyle(color: Colors.white38),
              prefixIcon: const Icon(Icons.search, color: _cyan),
              suffixIcon: IconButton(
                onPressed: () => _searchController.clear(),
                icon: const Icon(Icons.clear, color: Colors.white38),
              ),
              filled: true,
              fillColor: _panel,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            scrollDirection: Axis.horizontal,
            children: ['ALL', 'UNUSED', 'ACTIVE', 'PAUSED', 'EXPIRED']
                .map((f) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(f),
                        selected: _filter == f,
                        onSelected: (_) => setState(() => _filter = f),
                        selectedColor: _cyan.withOpacity(.2),
                        labelStyle: TextStyle(
                          color: _filter == f ? _cyan : Colors.white60,
                          fontWeight: FontWeight.bold,
                        ),
                        backgroundColor: _panel,
                      ),
                    ))
                .toList(),
          ),
        ),
        const SizedBox(height: 5),
        Expanded(
          child: list.isEmpty
              ? const Center(child: Text('No licenses found', style: TextStyle(color: Colors.white54)))
              : RefreshIndicator(
                  color: _cyan,
                  onRefresh: _refreshKeys,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 25),
                    itemCount: list.length,
                    itemBuilder: (_, i) => _licenseTile(list[i]),
                  ),
                ),
        ),
      ],
    );
  }

  Widget _licenseTile(Map<String, dynamic> k) {
    final status = (k['status'] ?? 'UNUSED').toString();
    final color = _statusColor(status);
    final key = (k['key_code'] ?? '').toString();
    final duration = k['duration_days'] ?? 0;
    return Card(
      color: _panel,
      margin: const EdgeInsets.only(bottom: 9),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(.12),
          child: Icon(Icons.vpn_key_rounded, color: color),
        ),
        title: Text(key, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(
            '${duration == -1 ? 'Lifetime' : '$duration days'}  •  Device: ${k['device_id'] ?? 'Not bound'}',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white54, fontSize: 11),
          ),
        ),
        trailing: PopupMenuButton<String>(
          icon: Icon(Icons.more_vert, color: color),
          onSelected: (v) => _changeStatus(k, v),
          itemBuilder: (_) => [
            if (status != 'ACTIVE')
              const PopupMenuItem(value: 'UNPAUSE', child: Text('Set Active')),
            if (status == 'ACTIVE' || status == 'UNUSED')
              const PopupMenuItem(value: 'PAUSE', child: Text('Pause')),
            const PopupMenuItem(value: 'EXPIRE', child: Text('Expire')),
            const PopupMenuItem(value: 'DELETE', child: Text('Delete')),
          ],
        ),
      ),
    );
  }

  Widget _usersView() {
    final bound = _keysList.where((k) => k['device_id'] != null && '${k['device_id']}'.isNotEmpty).toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 25),
      children: [
        _sectionTitle('BOUND DEVICES', Icons.devices_rounded),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: _panel,
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: _cyan.withOpacity(.18)),
          ),
          child: Row(
            children: [
              const Icon(Icons.phone_android_rounded, color: _cyan, size: 30),
              const SizedBox(width: 12),
              Text('${bound.length}', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(width: 8),
              const Text('bound license/device records', style: TextStyle(color: Colors.white54)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (bound.isEmpty)
          const Padding(
            padding: EdgeInsets.all(30),
            child: Center(child: Text('No bound devices yet', style: TextStyle(color: Colors.white54))),
          ),
        ...bound.map((k) => _compactLicense(k)),
      ],
    );
  }

  Widget _settingsView() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('ADMIN SETTINGS', Icons.tune_rounded),
        const SizedBox(height: 12),
        _settingTile(Icons.cloud_done_rounded, 'Supabase Connection', 'Connected', _green),
        _settingTile(Icons.security_rounded, 'License Protection', 'Database controlled', _cyan),
        _settingTile(Icons.price_change_rounded, '7 Days', 'LKR 500', _purple),
        _settingTile(Icons.calendar_month_rounded, '1 Month', 'LKR 1,000', _cyan),
        _settingTile(Icons.all_inclusive_rounded, 'Lifetime', 'LKR 2,200', _green),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _panel,
            borderRadius: BorderRadius.circular(17),
          ),
          child: const Text(
            'SADEE X DIMA ADMIN\n\nUse the License Manager to generate, search, pause, expire and delete keys. Device binding information is shown from the license_keys table.',
            style: TextStyle(color: Colors.white60, height: 1.5),
          ),
        ),
      ],
    );
  }

  Widget _settingTile(IconData icon, String title, String value, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        subtitle: Text(value, style: const TextStyle(color: Colors.white54)),
        trailing: Icon(Icons.check_circle, color: color, size: 18),
      ),
    );
  }

  Widget _statusChip(String status, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(.25)),
      ),
      child: Text(status, style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.w900)),
    );
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'ACTIVE':
        return _green;
      case 'PAUSED':
        return _orange;
      case 'EXPIRED':
        return Colors.redAccent;
      default:
        return _cyan;
    }
  }
}
