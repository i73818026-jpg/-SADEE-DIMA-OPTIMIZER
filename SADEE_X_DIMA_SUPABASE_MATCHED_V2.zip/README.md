# SADEE X DIMA - SUPABASE MATCHED EDITION

This package is rebuilt to match the current Supabase table used by the project:

- Project: `cpmzjplfqggmgeotmtcd`
- Table: `SADEE DIMA LICENSE`
- Columns: `id`, `created_at`, `license_key`, `plan`, `expires_at`, `status`, `device_id`, `activated_at`
- Pricing: 7 DAYS LKR 500 / 1 MONTH LKR 1,000 / LIFETIME LKR 2,200
- WhatsApp: +94 76 847 2404

## Required Supabase setup

1. Create an admin user in Supabase Authentication > Users.
2. Run `SUPABASE_SETUP.sql` once.
3. Put the Supabase publishable/anon key in GitHub Actions secret `SUPABASE_ANON_KEY`.
4. Build both apps.

The Admin app now uses Supabase Auth email/password instead of a hardcoded admin password. The User app checks the real `SADEE DIMA LICENSE` table. Admin license creation generates a real key and writes it to that same table.

The UI is black/red/pink cyber-gaming style and intentionally keeps English text.
