import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

const supabaseUrl = 'https://cpmzjplfqggmgeotmtcd.supabase.co';
const supabaseKey = String.fromEnvironment('SUPABASE_ANON_KEY');
const tableName = 'SADEE DIMA LICENSE';

const bg = Color(0xFF070707);
const panel = Color(0xFF111113);
const red = Color(0xFFFF3158);
const pink = Color(0xFFFFB0B4);
const text = Color(0xFFF4EEF0);
const muted = Color(0xFFAAA2A6);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, publishableKey: supabaseKey);
  }
  runApp(const UserApp());
}

class UserApp extends StatelessWidget {
  const UserApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'SADEE X DIMA OPTIMIZER',
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(primary: pink, surface: panel),
          useMaterial3: true,
          inputDecorationTheme: InputDecorationTheme(
            filled: true, fillColor: const Color(0xFF0D0D0F),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFF51494C))),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: pink, width: 2)),
          ),
        ),
        home: const LoginPage(),
      );
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState() => _LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
  final keyController = TextEditingController();
  bool loading = false; String message = '';

  Future<void> login() async {
    final key = keyController.text.trim();
    if (key.isEmpty) { setState(() => message = 'LICENSE KEY REQUIRED'); return; }
    if (supabaseKey.isEmpty) { setState(() => message = 'SUPABASE NOT CONFIGURED'); return; }
    setState(() { loading = true; message = ''; });
    try {
      final row = await Supabase.instance.client.from(tableName).select().eq('license_key', key).maybeSingle();
      if (row == null) { setState(() => message = 'LICENSE KEY NOT FOUND'); return; }
      final status = (row['status'] ?? '').toString().toLowerCase();
      if (status != 'active') { setState(() => message = 'LICENSE ${status.toUpperCase()}'); return; }
      DateTime? expires;
      final raw = row['expires_at'];
      if (raw != null) expires = DateTime.tryParse(raw.toString());
      if (expires != null && expires.isBefore(DateTime.now().toUtc())) { setState(() => message = 'LICENSE EXPIRED'); return; }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DashboardPage(licenseKey: key, plan: row['plan']?.toString() ?? '', expiresAt: expires)));
    } catch (e) {
      setState(() => message = 'CONNECTION FAILED');
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> order(String plan, String price) async {
    final uri = Uri.parse('https://wa.me/94768472404?text=${Uri.encodeComponent('Hello, I want a SADEE X DIMA $plan license for LKR $price.') }');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(22), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 620), child: CyberPanel(child: Column(children: [
      const Icon(Icons.speed_rounded, size: 78, color: red),
      const SizedBox(height: 14),
      const Text('SADEE X DIMA', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: text)),
      const Text('OPTIMIZER', style: TextStyle(fontSize: 18, color: red, fontWeight: FontWeight.w900, letterSpacing: 4)),
      const SizedBox(height: 28),
      TextField(controller: keyController, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'LICENSE KEY', prefixIcon: Icon(Icons.key_rounded))),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, height: 56, child: FilledButton(onPressed: loading ? null : login, style: FilledButton.styleFrom(backgroundColor: pink, foregroundColor: const Color(0xFF3B1F22)), child: Text(loading ? 'CHECKING LICENSE...' : 'ENTER OPTIMIZER'))),
      if (message.isNotEmpty) ...[const SizedBox(height: 14), Text(message, style: const TextStyle(color: red, fontWeight: FontWeight.w800))],
      const SizedBox(height: 30),
      const Align(alignment: Alignment.centerLeft, child: Text('LICENSE PLANS', style: TextStyle(color: red, fontWeight: FontWeight.w900, letterSpacing: 1.2))),
      const SizedBox(height: 10),
      PlanTile(title: '7 DAYS', price: 'LKR 500', onTap: () => order('7 DAYS', '500')),
      PlanTile(title: '1 MONTH', price: 'LKR 1,000', onTap: () => order('1 MONTH', '1000')),
      PlanTile(title: 'LIFETIME', price: 'LKR 2,200', onTap: () => order('LIFETIME', '2200')),
      const SizedBox(height: 12),
      const Text('Order via WhatsApp: +94 76 847 2404', style: TextStyle(color: muted)),
    ]))))),
  );
}

class PlanTile extends StatelessWidget {
  final String title, price; final VoidCallback onTap;
  const PlanTile({super.key, required this.title, required this.price, required this.onTap});
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 10), decoration: BoxDecoration(color: const Color(0xFF0B0B0C), borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFF3A171F))), child: ListTile(onTap: onTap, leading: const Icon(Icons.verified_rounded, color: red), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), trailing: Text(price, style: const TextStyle(color: pink, fontWeight: FontWeight.w900))));
}

class DashboardPage extends StatefulWidget {
  final String licenseKey, plan; final DateTime? expiresAt;
  const DashboardPage({super.key, required this.licenseKey, required this.plan, required this.expiresAt});
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Timer? timer; Duration remaining = Duration.zero;
  @override void initState() { super.initState(); _tick(); timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick()); }
  void _tick() { if (widget.expiresAt == null) return; final d = widget.expiresAt!.toUtc().difference(DateTime.now().toUtc()); if (mounted) setState(() => remaining = d.isNegative ? Duration.zero : d); }
  @override void dispose() { timer?.cancel(); super.dispose(); }
  String countdown() { if (widget.expiresAt == null) return 'LIFETIME / NO EXPIRY'; final d=remaining; return '${d.inDays}D ${d.inHours.remainder(24).toString().padLeft(2,'0')}:${d.inMinutes.remainder(60).toString().padLeft(2,'0')}:${d.inSeconds.remainder(60).toString().padLeft(2,'0')}'; }
  Future<void> launchGame(String package) async { final uri = Uri.parse('intent://#Intent;package=$package;end'); try { await launchUrl(uri, mode: LaunchMode.externalApplication); } catch (_) {} }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SADEE X DIMA OPTIMIZER', style: TextStyle(fontWeight: FontWeight.w800)), actions: [IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.logout_rounded))]),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      CyberPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('LICENSE STATUS', style: TextStyle(color: red, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Text(widget.plan, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        SelectableText(widget.licenseKey, style: const TextStyle(color: muted)),
        const SizedBox(height: 12),
        Text(countdown(), style: const TextStyle(color: pink, fontSize: 22, fontWeight: FontWeight.w900)),
      ])),
      const SizedBox(height: 16),
      const SectionTitle('OPTIMIZER CORE'),
      const ToolCard(icon: Icons.cleaning_services_rounded, title: 'SMART CLEAN', subtitle: 'Prepare accessible junk and temporary storage for cleanup.'),
      const ToolCard(icon: Icons.storage_rounded, title: 'STORAGE ANALYZER', subtitle: 'Inspect storage usage available to the app.'),
      const ToolCard(icon: Icons.battery_charging_full_rounded, title: 'BATTERY MONITOR', subtitle: 'Open Android battery information and monitoring tools.'),
      const ToolCard(icon: Icons.thermostat_rounded, title: 'THERMAL MONITOR', subtitle: 'Use device thermal/system information where Android exposes it.'),
      const ToolCard(icon: Icons.network_check_rounded, title: 'NETWORK MONITOR', subtitle: 'Show connection state and open network settings.'),
      const ToolCard(icon: Icons.memory_rounded, title: 'PERFORMANCE', subtitle: 'Live device performance features depend on Android APIs available to the app.'),
      const SizedBox(height: 14),
      const SectionTitle('GAME LAUNCHER'),
      GameButton(title: 'FREE FIRE', packageName: 'com.dts.freefireth', onTap: launchGame),
      GameButton(title: 'FREE FIRE MAX', packageName: 'com.dts.freefiremax', onTap: launchGame),
      const SizedBox(height: 12),
      const Text('Launcher opens the installed game normally. It does not modify game files or bypass security.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 12)),
    ]),
  );
}

class ToolCard extends StatelessWidget { final IconData icon; final String title, subtitle; const ToolCard({super.key, required this.icon, required this.title, required this.subtitle}); @override Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF2E171D))), child: Row(children: [Icon(icon, color: pink, size: 28), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: muted, fontSize: 12))]))])); }
class GameButton extends StatelessWidget { final String title, packageName; final Future<void> Function(String) onTap; const GameButton({super.key, required this.title, required this.packageName, required this.onTap}); @override Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 10), child: FilledButton.icon(onPressed: () => onTap(packageName), icon: const Icon(Icons.play_arrow_rounded), label: Padding(padding: const EdgeInsets.all(13), child: Text('LAUNCH $title')), style: FilledButton.styleFrom(backgroundColor: const Color(0xFF1A1012), foregroundColor: text, side: const BorderSide(color: red)))); }
class SectionTitle extends StatelessWidget { final String title; const SectionTitle(this.title,{super.key}); @override Widget build(BuildContext context)=>Padding(padding: const EdgeInsets.only(bottom:10), child: Text(title, style: const TextStyle(color:red,fontWeight:FontWeight.w900,letterSpacing:1.2))); }
class CyberPanel extends StatelessWidget { final Widget child; const CyberPanel({super.key,required this.child}); @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(22),border:Border.all(color:const Color(0xFF3A171F)),boxShadow:const[BoxShadow(color:Color(0x33000000),blurRadius:20)]),child:child); }
