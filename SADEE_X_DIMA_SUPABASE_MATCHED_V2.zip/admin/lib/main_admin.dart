import 'dart:math';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://cpmzjplfqggmgeotmtcd.supabase.co';
const supabaseKey = String.fromEnvironment('SUPABASE_ANON_KEY');
const tableName = 'SADEE DIMA LICENSE';

const bg = Color(0xFF080808);
const panel = Color(0xFF111113);
const red = Color(0xFFFF3158);
const pink = Color(0xFFFFB0B4);
const text = Color(0xFFF4EEF0);
const muted = Color(0xFFAAA2A6);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, publishableKey: supabaseKey);
  }
  runApp(const AdminApp());
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'SADEE X DIMA ADMIN',
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(primary: pink, surface: panel),
          useMaterial3: true,
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: const Color(0xFF0D0D0F),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFF51494C)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: pink, width: 2),
            ),
          ),
        ),
        home: const AdminLoginPage(),
      );
}

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});
  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  String error = '';

  Future<void> login() async {
    if (supabaseKey.isEmpty) {
      setState(() => error = 'Supabase key is not configured.');
      return;
    }
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      setState(() => error = 'Admin email and password required.');
      return;
    }
    setState(() { loading = true; error = ''; });
    try {
      final auth = Supabase.instance.client.auth;
      await auth.signInWithPassword(
        email: email.text.trim(),
        password: password.text,
      );
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminHomePage()));
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (e) {
      setState(() => error = 'LOGIN FAILED');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 620),
                child: CyberPanel(
                  child: Column(
                    children: [
                      const Icon(Icons.admin_panel_settings_rounded, size: 72, color: red),
                      const SizedBox(height: 14),
                      const Text('SADEE X DIMA ADMIN', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: text)),
                      const SizedBox(height: 6),
                      const Text('COMMAND CENTER / SUPABASE', style: TextStyle(color: muted, letterSpacing: 2)),
                      const SizedBox(height: 30),
                      TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'ADMIN EMAIL')),
                      const SizedBox(height: 14),
                      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'ADMIN PASSWORD')),
                      const SizedBox(height: 20),
                      SizedBox(width: double.infinity, height: 58, child: FilledButton(
                        onPressed: loading ? null : login,
                        style: FilledButton.styleFrom(backgroundColor: pink, foregroundColor: const Color(0xFF3B1F22)),
                        child: Text(loading ? 'AUTHENTICATING...' : 'ENTER ADMIN COMMAND CENTER', style: const TextStyle(fontWeight: FontWeight.w800)),
                      )),
                      if (error.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        Text(error, textAlign: TextAlign.center, style: const TextStyle(color: red, fontWeight: FontWeight.w700)),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}

class AdminHomePage extends StatefulWidget {
  const AdminHomePage({super.key});
  @override
  State<AdminHomePage> createState() => _AdminHomePageState();
}

class _AdminHomePageState extends State<AdminHomePage> {
  final random = Random.secure();
  List<Map<String, dynamic>> licenses = [];
  String plan = '7_DAYS';
  bool loading = false;
  String notice = '';

  SupabaseClient get client => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    loadLicenses();
  }

  String makeKey(String prefix) {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    String part() => List.generate(8, (_) => chars[random.nextInt(chars.length)]).join();
    return '$prefix-${part()}-${part()}';
  }

  Future<void> loadLicenses() async {
    if (supabaseKey.isEmpty) return;
    setState(() => loading = true);
    try {
      final result = await client.from(tableName).select().order('created_at', ascending: false);
      licenses = List<Map<String, dynamic>>.from(result);
      notice = '';
    } catch (e) {
      notice = 'LOAD FAILED: $e';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String _prefix() => switch (plan) {
        '7_DAYS' => 'SDX7',
        '1_MONTH' => 'SDX30',
        _ => 'SDXLIFE',
      };

  DateTime? _expiry() {
    final now = DateTime.now().toUtc();
    if (plan == '7_DAYS') return now.add(const Duration(days: 7));
    if (plan == '1_MONTH') return DateTime.utc(now.year, now.month + 1, now.day, now.hour, now.minute, now.second);
    return null;
  }

  int _price(String p) => p == '7_DAYS' ? 500 : p == '1_MONTH' ? 1000 : 2200;

  Future<void> createLicense() async {
    if (supabaseKey.isEmpty) return;
    setState(() { loading = true; notice = ''; });
    final key = makeKey(_prefix());
    final expiry = _expiry();
    try {
      await client.from(tableName).insert({
        'license_key': key,
        'plan': plan,
        'expires_at': expiry?.toIso8601String(),
        'status': 'active',
      });
      await loadLicenses();
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (_) => AlertDialog(
        title: const Text('LICENSE CREATED'),
        content: SelectableText('$key\n\nPlan: $plan\nPrice: LKR ${_price(plan)}'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CLOSE'))],
      ));
    } catch (e) {
      if (mounted) setState(() => notice = 'LICENSE CREATE FAILED: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> setStatus(dynamic id, String status) async {
    try {
      await client.from(tableName).update({'status': status}).eq('id', id);
      await loadLicenses();
    } catch (e) {
      if (mounted) setState(() => notice = 'UPDATE FAILED: $e');
    }
  }

  Future<void> deleteLicense(dynamic id) async {
    try {
      await client.from(tableName).delete().eq('id', id);
      await loadLicenses();
    } catch (e) {
      if (mounted) setState(() => notice = 'DELETE FAILED: $e');
    }
  }

  int get activeCount => licenses.where((x) => (x['status'] ?? '').toString().toLowerCase() == 'active').length;
  int get revenue => licenses.fold(0, (sum, x) => sum + _price((x['plan'] ?? '').toString()));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SADEE X DIMA ADMIN', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(onPressed: loadLicenses, icon: const Icon(Icons.refresh_rounded)),
          IconButton(onPressed: () async { await client.auth.signOut(); if (context.mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminLoginPage())); }, icon: const Icon(Icons.logout_rounded)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: loadLicenses,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 40),
          children: [
            const Text('COMMAND CENTER', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            if (notice.isNotEmpty) Text(notice, style: const TextStyle(color: red)),
            const SizedBox(height: 18),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              childAspectRatio: 1.55,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              children: [
                StatCard(title: 'TOTAL LICENSES', value: '${licenses.length}', icon: Icons.bar_chart_rounded),
                StatCard(title: 'ACTIVE LICENSES', value: '$activeCount', icon: Icons.verified_rounded),
                StatCard(title: 'ORDERS', value: '${licenses.length}', icon: Icons.receipt_long_rounded),
                StatCard(title: 'REVENUE', value: 'LKR $revenue', icon: Icons.payments_rounded),
              ],
            ),
            const SizedBox(height: 18),
            CyberPanel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('LICENSE CONTROL', style: TextStyle(color: red, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                const SizedBox(height: 14),
                DropdownButtonFormField<String>(
                  initialValue: plan,
                  decoration: const InputDecoration(labelText: 'PLAN'),
                  items: const [
                    DropdownMenuItem(value: '7_DAYS', child: Text('7 DAYS • LKR 500')),
                    DropdownMenuItem(value: '1_MONTH', child: Text('1 MONTH • LKR 1,000')),
                    DropdownMenuItem(value: 'LIFETIME', child: Text('LIFETIME • LKR 2,200')),
                  ],
                  onChanged: (v) => setState(() => plan = v ?? '7_DAYS'),
                ),
                const SizedBox(height: 14),
                SizedBox(width: double.infinity, height: 56, child: FilledButton.icon(
                  onPressed: loading ? null : createLicense,
                  icon: const Icon(Icons.add_circle_outline),
                  label: Text(loading ? 'CREATING...' : 'CREATE LICENSE'),
                  style: FilledButton.styleFrom(backgroundColor: pink, foregroundColor: const Color(0xFF3B1F22)),
                )),
              ]),
            ),
            const SizedBox(height: 18),
            CyberPanel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('LICENSE DATABASE', style: TextStyle(color: red, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                const SizedBox(height: 10),
                if (loading && licenses.isEmpty) const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()))
                else if (licenses.isEmpty) const Padding(padding: EdgeInsets.all(18), child: Text('No licenses yet.'))
                else ...licenses.map((row) => LicenseRow(
                  row: row,
                  onStatus: (s) => setStatus(row['id'], s),
                  onDelete: () => deleteLicense(row['id']),
                )),
              ]),
            ),
            const SizedBox(height: 18),
            CyberPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
              Text('ADMIN MODULES', style: TextStyle(color: red, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              SizedBox(height: 16),
              ModuleLine(icon: Icons.people_alt_outlined, title: 'User Management'),
              ModuleLine(icon: Icons.key_outlined, title: 'License Management'),
              ModuleLine(icon: Icons.receipt_long_outlined, title: 'Orders & Payments'),
              ModuleLine(icon: Icons.devices_outlined, title: 'Device Bindings'),
            ])),
          ],
        ),
      ),
    );
  }
}

class LicenseRow extends StatelessWidget {
  final Map<String, dynamic> row;
  final ValueChanged<String> onStatus;
  final VoidCallback onDelete;
  const LicenseRow({super.key, required this.row, required this.onStatus, required this.onDelete});
  @override
  Widget build(BuildContext context) {
    final key = row['license_key']?.toString() ?? '';
    final status = row['status']?.toString() ?? 'unknown';
    final expiry = row['expires_at']?.toString();
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: const Color(0xFF0B0B0C), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF2D2024))),
      child: Row(children: [
        const Icon(Icons.vpn_key_rounded, color: pink),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SelectableText(key, style: const TextStyle(fontWeight: FontWeight.w800, color: text)),
          const SizedBox(height: 4),
          Text('${row['plan'] ?? ''} • $status${expiry == null ? ' • NO EXPIRY' : ''}', style: const TextStyle(color: muted, fontSize: 12)),
        ])),
        PopupMenuButton<String>(
          onSelected: (v) => v == 'DELETE' ? onDelete() : onStatus(v),
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'active', child: Text('ACTIVE')),
            PopupMenuItem(value: 'paused', child: Text('PAUSED')),
            PopupMenuItem(value: 'expired', child: Text('EXPIRED')),
            PopupMenuItem(value: 'DELETE', child: Text('DELETE')),
          ],
        ),
      ]),
    );
  }
}

class StatCard extends StatelessWidget {
  final String title, value; final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => CyberPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: red), const Spacer(), Text(title, style: const TextStyle(color: muted, fontSize: 12)), const SizedBox(height: 5), Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: text)),
      ]));
}

class CyberPanel extends StatelessWidget {
  final Widget child; const CyberPanel({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFF3A171F)), boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 20)]),
        child: child,
      );
}

class ModuleLine extends StatelessWidget {
  final IconData icon; final String title;
  const ModuleLine({super.key, required this.icon, required this.title});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Row(children: [Icon(icon, color: const Color(0xFFE8DDE0), size: 28), const SizedBox(width: 20), Text(title, style: const TextStyle(fontSize: 17, color: text))]));
}
