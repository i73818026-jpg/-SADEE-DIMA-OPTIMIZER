-- SADEE X DIMA: run this once in Supabase SQL Editor.
-- The existing table name is: SADEE DIMA LICENSE

alter table public."SADEE DIMA LICENSE"
  add column if not exists license_key text,
  add column if not exists plan text,
  add column if not exists expires_at timestamptz,
  add column if not exists status text default 'active',
  add column if not exists device_id text,
  add column if not exists activated_at timestamptz;

create unique index if not exists sadee_dima_license_key_uq
on public."SADEE DIMA LICENSE" (license_key)
where license_key is not null;

alter table public."SADEE DIMA LICENSE" enable row level security;

-- User app: public license lookup only.
drop policy if exists "public can read active licenses" on public."SADEE DIMA LICENSE";
create policy "public can read active licenses"
on public."SADEE DIMA LICENSE"
for select
to anon
using (status = 'active');

-- Admin app: Supabase Auth users can manage licenses.
drop policy if exists "authenticated can read licenses" on public."SADEE DIMA LICENSE";
create policy "authenticated can read licenses"
on public."SADEE DIMA LICENSE"
for select
to authenticated
using (true);

drop policy if exists "authenticated can insert licenses" on public."SADEE DIMA LICENSE";
create policy "authenticated can insert licenses"
on public."SADEE DIMA LICENSE"
for insert
to authenticated
with check (true);

drop policy if exists "authenticated can update licenses" on public."SADEE DIMA LICENSE";
create policy "authenticated can update licenses"
on public."SADEE DIMA LICENSE"
for update
to authenticated
using (true)
with check (true);

drop policy if exists "authenticated can delete licenses" on public."SADEE DIMA LICENSE";
create policy "authenticated can delete licenses"
on public."SADEE DIMA LICENSE"
for delete
to authenticated
using (true);
