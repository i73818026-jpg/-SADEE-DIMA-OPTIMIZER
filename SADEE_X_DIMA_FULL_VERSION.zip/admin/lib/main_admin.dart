import 'dart:math';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://cpmzjplfqggmgeotmtcd.supabase.co';
const supabaseKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (supabaseKey.isNotEmpty) {
    await Supabase.initialize(
      url: supabaseUrl,
      publishableKey: supabaseKey,
    );
  }

  runApp(const SadeeDimaAdminApp());
}

class SadeeDimaAdminApp extends StatelessWidget {
  const SadeeDimaAdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SADEE X DIMA ADMIN',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.deepPurple,
        useMaterial3: true,
      ),
      home: const AdminLoginPage(),
    );
  }
}

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});

  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final controller = TextEditingController();
  String message = '';

  void login() {
    if (controller.text == 'ADMIN2026') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const AdminHomePage()),
      );
    } else {
      setState(() => message = 'Invalid admin password.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.admin_panel_settings, size: 72),
                const SizedBox(height: 18),
                const Text(
                  'SADEE X DIMA ADMIN',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: controller,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Admin Password',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: login,
                    child: const Padding(
                      padding: EdgeInsets.all(14),
                      child: Text('LOGIN'),
                    ),
                  ),
                ),
                if (message.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(message),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AdminHomePage extends StatefulWidget {
  const AdminHomePage({super.key});

  @override
  State<AdminHomePage> createState() => _AdminHomePageState();
}

class _AdminHomePageState extends State<AdminHomePage> {
  final random = Random.secure();
  List<Map<String, dynamic>> keys = [];
  int duration = 7;
  bool loading = false;

  SupabaseClient get client => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    loadKeys();
  }

  String makeKey() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

    String part() {
      return List.generate(
        5,
        (_) => chars[random.nextInt(chars.length)],
      ).join();
    }

    return 'SADEE-${part()}-${part()}-${part()}';
  }

  Future<void> loadKeys() async {
    if (supabaseKey.isEmpty) return;

    setState(() => loading = true);
    try {
      final result = await client
          .from('license_keys')
          .select()
          .order('created_at', ascending: false);

      keys = List<Map<String, dynamic>>.from(result);
    } catch (_) {
      // Keep existing list if the request fails.
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> generateKey() async {
    if (supabaseKey.isEmpty) return;

    final key = makeKey();

    try {
      await client.from('license_keys').insert({
        'key_code': key,
        'duration_days': duration,
        'status': 'UNUSED',
      });

      await loadKeys();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Created: $key')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not create key.')),
        );
      }
    }
  }

  Future<void> setStatus(String id, String status) async {
    try {
      await client
          .from('license_keys')
          .update({'status': status})
          .eq('id', id);

      await loadKeys();
    } catch (_) {}
  }

  Future<void> deleteKey(String id) async {
    try {
      await client.from('license_keys').delete().eq('id', id);
      await loadKeys();
    } catch (_) {}
  }

  String durationLabel(int value) {
    if (value < 0) return 'Lifetime';
    return '$value days';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ADMIN PANEL'),
        actions: [
          IconButton(
            onPressed: loadKeys,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'GENERATE LICENSE',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<int>(
                    initialValue: duration,
                    decoration: const InputDecoration(
                      labelText: 'Duration',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: 1, child: Text('1 Day')),
                      DropdownMenuItem(value: 3, child: Text('3 Days')),
                      DropdownMenuItem(value: 7, child: Text('7 Days')),
                      DropdownMenuItem(value: 14, child: Text('14 Days')),
                      DropdownMenuItem(value: 30, child: Text('1 Month')),
                      DropdownMenuItem(value: -1, child: Text('Lifetime')),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => duration = value);
                      }
                    },
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: loading ? null : generateKey,
                      icon: const Icon(Icons.add),
                      label: const Text('GENERATE KEY'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'LICENSES (${keys.length})',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          if (loading)
            const Center(child: CircularProgressIndicator())
          else if (keys.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text('No license keys yet.'),
              ),
            )
          else
            ...keys.map(
              (row) => Card(
                child: ListTile(
                  title: Text(row['key_code']?.toString() ?? ''),
                  subtitle: Text(
                    '${row['status'] ?? 'UNKNOWN'} • '
                    '${durationLabel((row['duration_days'] as num?)?.toInt() ?? 0)}',
                  ),
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'DELETE') {
                        deleteKey(row['id'].toString());
                      } else {
                        setStatus(row['id'].toString(), value);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(
                        value: 'ACTIVE',
                        child: Text('Set ACTIVE'),
                      ),
                      PopupMenuItem(
                        value: 'PAUSED',
                        child: Text('Set PAUSED'),
                      ),
                      PopupMenuItem(
                        value: 'EXPIRED',
                        child: Text('Set EXPIRED'),
                      ),
                      PopupMenuItem(
                        value: 'DELETE',
                        child: Text('Delete'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
