SADEE X DIMA - FULL VERSION
================================

Supabase URL:
https://cpmzjplfqggmgeotmtcd.supabase.co

GitHub Actions Secret:
Name: SUPABASE_ANON_KEY
Value: Use your Supabase Publishable key in GitHub Secrets.

IMPORTANT:
- Do not put a Supabase service-role/secret key into the app or repository.
- The workflow expects the source folders user/ and admin/ in the repository.
- The generated APKs are uploaded as GitHub Actions artifacts.
- User password in this demo: SADEE2026
- Admin password in this demo: ADMIN2026
- User pricing: 7 Days Rs. 500, 1 Month Rs. 1000, Lifetime Rs. 2200
- WhatsApp ordering number: +94 76 847 2404
- The launch button only opens the installed game normally; it does not modify game files or bypass security.

For production, replace hardcoded passwords with proper authentication and secure Supabase RLS policies.
