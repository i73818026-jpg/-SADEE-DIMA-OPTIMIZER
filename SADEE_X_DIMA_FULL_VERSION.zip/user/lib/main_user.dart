import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

const supabaseUrl = 'https://cpmzjplfqggmgeotmtcd.supabase.co';
const supabaseKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (supabaseKey.isNotEmpty) {
    await Supabase.initialize(
      url: supabaseUrl,
      publishableKey: supabaseKey,
    );
  }

  runApp(const SadeeDimaUserApp());
}

class SadeeDimaUserApp extends StatelessWidget {
  const SadeeDimaUserApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SADEE X DIMA',
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.blue,
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final keyController = TextEditingController();
  final passwordController = TextEditingController();
  bool loading = false;
  String message = '';

  Future<void> login() async {
    final keyCode = keyController.text.trim();
    final password = passwordController.text;

    if (keyCode.isEmpty || password.isEmpty) {
      setState(() => message = 'License Key and Password required.');
      return;
    }

    if (password != 'SADEE2026') {
      setState(() => message = 'Invalid password.');
      return;
    }

    if (supabaseKey.isEmpty) {
      setState(() => message = 'Supabase key is not configured.');
      return;
    }

    setState(() {
      loading = true;
      message = '';
    });

    try {
      final client = Supabase.instance.client;
      final row = await client
          .from('license_keys')
          .select()
          .eq('key_code', keyCode)
          .maybeSingle();

      if (row == null) {
        setState(() => message = 'License key not found.');
        return;
      }

      final status = (row['status'] ?? 'UNUSED').toString().toUpperCase();
      if (status == 'PAUSED') {
        setState(() => message = 'This license is paused.');
        return;
      }

      DateTime? expiresAt;
      final rawExpires = row['expires_at'];
      if (rawExpires != null) {
        expiresAt = DateTime.tryParse(rawExpires.toString());
      }

      if (expiresAt != null && expiresAt.isBefore(DateTime.now().toUtc())) {
        setState(() => message = 'This license has expired.');
        return;
      }

      if (status == 'UNUSED') {
        final days = (row['duration_days'] as num?)?.toInt() ?? 0;
        final now = DateTime.now().toUtc();
        final expiry = days < 0
            ? null
            : now.add(Duration(days: days));

        await client.from('license_keys').update({
          'status': 'ACTIVE',
          'activated_at': now.toIso8601String(),
          'expires_at': expiry?.toIso8601String(),
        }).eq('id', row['id']);

        expiresAt = expiry;
      }

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => DashboardPage(
            licenseKey: keyCode,
            expiresAt: expiresAt,
          ),
        ),
      );
    } catch (e) {
      setState(() => message = 'Connection error. Check Supabase settings.');
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  Future<void> openWhatsApp() async {
    final uri = Uri.parse(
      'https://wa.me/94768472404?text=${Uri.encodeComponent('Hello, I want to order SADEE X DIMA license.') }',
    );
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                children: [
                  const Icon(Icons.speed, size: 72),
                  const SizedBox(height: 16),
                  const Text(
                    'SADEE X DIMA',
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text('OPTIMIZER • USER PANEL'),
                  const SizedBox(height: 30),
                  TextField(
                    controller: keyController,
                    decoration: const InputDecoration(
                      labelText: 'License Key',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.key),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.lock),
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: loading ? null : login,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Text(loading ? 'Checking...' : 'LOGIN'),
                      ),
                    ),
                  ),
                  if (message.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text(message, textAlign: TextAlign.center),
                  ],
                  const SizedBox(height: 30),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'LICENSE PLANS',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const PlanTile(title: '7 Days', price: 'Rs. 500'),
                  const PlanTile(title: '1 Month', price: 'Rs. 1000'),
                  const PlanTile(title: 'Lifetime', price: 'Rs. 2200'),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: openWhatsApp,
                    icon: const Icon(Icons.chat),
                    label: const Text('ORDER VIA WHATSAPP'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class PlanTile extends StatelessWidget {
  final String title;
  final String price;

  const PlanTile({
    super.key,
    required this.title,
    required this.price,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.verified),
        title: Text(title),
        trailing: Text(
          price,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  final String licenseKey;
  final DateTime? expiresAt;

  const DashboardPage({
    super.key,
    required this.licenseKey,
    required this.expiresAt,
  });

  Future<void> launchGame(BuildContext context) async {
    final uri = Uri.parse('intent://#Intent;package=com.dts.freefireth;end');
    try {
      final opened = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
      if (!opened && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Game app could not be opened.')),
        );
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Game app not available.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final expiryText = expiresAt == null
        ? 'Lifetime'
        : expiresAt!.toLocal().toString().split('.').first;

    return Scaffold(
      appBar: AppBar(title: const Text('SADEE X DIMA')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.verified_user),
              title: const Text('License Active'),
              subtitle: Text(licenseKey),
              trailing: Text(expiryText),
            ),
          ),
          const SizedBox(height: 14),
          const FeatureCard(
            icon: Icons.memory,
            title: 'RAM / Performance',
            subtitle: 'Performance dashboard and device status.',
          ),
          const FeatureCard(
            icon: Icons.touch_app,
            title: 'Touch & Display',
            subtitle: 'Touch and display settings shortcuts.',
          ),
          const FeatureCard(
            icon: Icons.sports_esports,
            title: 'Gaming Mode',
            subtitle: 'Gaming-focused dashboard controls.',
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () => launchGame(context),
            icon: const Icon(Icons.play_arrow),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('SADEE X DIMA LAUNCH'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'This button opens the installed game normally. '
            'It does not modify game files or bypass security.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const FeatureCard({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(subtitle),
      ),
    );
  }
}
