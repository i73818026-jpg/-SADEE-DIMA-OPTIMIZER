const String supabaseUrl = 'https://cpmzjplfqggmgeotmtcd.supabase.co';
const String supabaseAnonKey = 'sb_publishable_z0kmWe85ybkmBg7bzEtyKA_kMH6WGXW';
const String orderWhatsApp = '94768472404';
