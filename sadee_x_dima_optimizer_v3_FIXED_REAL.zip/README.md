# SADEE X DIMA Optimizer v3

Contains separate User and Admin Flutter apps plus a GitHub Actions workflow.

Artifacts:
- sadee-x-dima-user-apk
- sadee-x-dima-admin-apk

Supabase URL and publishable key are in both apps' lib/config.dart.
