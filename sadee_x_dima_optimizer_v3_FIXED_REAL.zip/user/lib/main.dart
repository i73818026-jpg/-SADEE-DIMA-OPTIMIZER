import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'config.dart';

const bg = Color(0xFF070A10);
const card = Color(0xFF111722);
const accent = Color(0xFF00E5FF);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, publishableKey: supabaseAnonKey);
  runApp(const SadeeUserApp());
}

class SadeeUserApp extends StatelessWidget {
  const SadeeUserApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SADEE X DIMA Optimizer',
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: bg, colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark), useMaterial3: true),
    home: const LoginPage(),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final keyCtrl = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    final code = keyCtrl.text.trim().toUpperCase();
    if (code.isEmpty) {
      _msg('Enter your license key.');
      return;
    }
    setState(() => loading = true);
    try {
      final row = await Supabase.instance.client.from('license_keys').select().eq('key_code', code).maybeSingle();
      if (row == null) {
        _msg('License key not found.');
      } else {
        final status = (row['status'] ?? 'UNUSED').toString().toUpperCase();
        final expires = row['expires_at'] == null ? null : DateTime.tryParse(row['expires_at'].toString());
        final expired = expires != null && expires.isBefore(DateTime.now().toUtc());
        if (status == 'PAUSED') {
          _msg('This license is paused.');
        } else if (status == 'EXPIRED' || expired) {
          _msg('This license has expired.');
        } else {
          if (status == 'UNUSED') {
            await Supabase.instance.client.from('license_keys').update({
              'status': 'ACTIVE',
              'activated_at': DateTime.now().toUtc().toIso8601String(),
              'expires_at': row['duration_days'] == -1
                  ? null
                  : DateTime.now().toUtc().add(Duration(days: (row['duration_days'] as num).toInt())).toIso8601String(),
            }).eq('key_code', code);
          }
          if (!mounted) { return; }
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DashboardPage(keyCode: code)));
        }
      }
    } catch (e) {
      _msg('Connection error. Check internet and Supabase settings.');
    } finally {
      if (mounted) { setState(() => loading = false); }
    }
  }

  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  Future<void> buy(String plan, String price) async {
    final m = Uri.encodeComponent('Hello SADEE X DIMA, I want to order a $plan license ($price). Please send me the payment/order details.');
    final u = Uri.parse('https://wa.me/$orderWhatsApp?text=$m');
    if (await canLaunchUrl(u)) { await launchUrl(u, mode: LaunchMode.externalApplication); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      const SizedBox(height: 30),
      const Icon(Icons.bolt_rounded, size: 70, color: accent),
      const SizedBox(height: 10),
      const Text('𝕤𝕒𝕕𝕖𝕖 𝕏 𝕕𝕚𝕞𝕒', textAlign: TextAlign.center, style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
      const Text('OPTIMIZER', textAlign: TextAlign.center, style: TextStyle(color: accent, letterSpacing: 5, fontWeight: FontWeight.bold)),
      const SizedBox(height: 35),
      TextField(controller: keyCtrl, textCapitalization: TextCapitalization.characters, decoration: InputDecoration(prefixIcon: const Icon(Icons.key, color: accent), hintText: 'License / Access Key', filled: true, fillColor: card, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
      const SizedBox(height: 12),
      SizedBox(height: 52, child: FilledButton(onPressed: loading ? null : login, style: FilledButton.styleFrom(backgroundColor: accent, foregroundColor: Colors.black), child: loading ? const CircularProgressIndicator() : const Text('LOGIN', style: TextStyle(fontWeight: FontWeight.w900)))),
      const SizedBox(height: 25),
      const Text('KEY PRICES', style: TextStyle(color: accent, fontWeight: FontWeight.w900, letterSpacing: 2)),
      const SizedBox(height: 8),
      _price('7 DAYS', 'Rs. 500', '7 Day License'),
      _price('1 MONTH', 'Rs. 1,000', '30 Day License'),
      _price('LIFETIME', 'Rs. 2,200', 'Lifetime License'),
    ])),
  );

  Widget _price(String title, String price, String sub) => Card(
    color: card, child: ListTile(
      leading: const CircleAvatar(backgroundColor: Color(0x2200E5FF), child: Icon(Icons.vpn_key, color: accent)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(sub),
      trailing: TextButton(onPressed: () => buy(title, price), child: Text('BUY\n$price', textAlign: TextAlign.center)),
    ),
  );
}

class DashboardPage extends StatefulWidget {
  final String keyCode;
  const DashboardPage({super.key, required this.keyCode});
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int tab = 0;
  final pages = const ['Home', 'Optimize', 'Gaming', 'Performance', 'Settings'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('SADEE X DIMA • ${pages[tab]}')),
      body: _body(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), backgroundColor: card,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.bolt_outlined), selectedIcon: Icon(Icons.bolt), label: 'Optimize'),
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'Gaming'),
          NavigationDestination(icon: Icon(Icons.speed_outlined), selectedIcon: Icon(Icons.speed), label: 'Performance'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }

  Widget _body() {
    switch (tab) {
      case 1:
        return const ToolPage(
          title: 'OPTIMIZER',
          icon: Icons.bolt,
          items: ['One-Tap Optimize', 'Memory Check', 'Storage Check'],
        );
      case 2:
        return const ToolPage(
          title: 'GAMING',
          icon: Icons.sports_esports,
          items: ['Game Mode', 'SADEE X DIMA LAUNCH', 'Gaming Tips'],
        );
      case 3:
        return const ToolPage(
          title: 'PERFORMANCE',
          icon: Icons.speed,
          items: ['CPU Status', 'RAM Status', 'Battery Status', 'Storage Status'],
        );
      case 4:
        return const ToolPage(
          title: 'SETTINGS',
          icon: Icons.settings,
          items: ['License Status', 'App Version', 'About SADEE X DIMA'],
        );
      default:
        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              _hero(),
              const SizedBox(height: 15),
              Row(
                children: [
                  Expanded(child: _stat('LICENSE', 'ACTIVE')),
                  const SizedBox(width: 10),
                  Expanded(child: _stat('MODE', 'READY')),
                ],
              ),
              const SizedBox(height: 14),
              _launchButton(),
            ],
          ),
        );
    }
  }

  Widget _hero() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0x4400E5FF)),
        gradient: const LinearGradient(
          colors: [Color(0xFF10232B), card],
        ),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'WELCOME BACK',
            style: TextStyle(
              color: accent,
              letterSpacing: 2,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 7),
          Text(
            'SADEE X DIMA',
            style: TextStyle(
              fontSize: 27,
              fontWeight: FontWeight.w900,
            ),
          ),
          SizedBox(height: 6),
          Text(
            'Gaming performance dashboard',
            style: TextStyle(color: Colors.white54),
          ),
        ],
      ),
    );
  }

  Widget _stat(String title, String value) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }

  Widget _launchButton() {
    return SizedBox(
      height: 58,
      child: FilledButton.icon(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Select your game from the launcher page in the next build.',
              ),
            ),
          );
        },
        icon: const Icon(Icons.rocket_launch),
        label: const Text(
          'SADEE X DIMA LAUNCH',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
    );
  }
}

class ToolPage extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<String> items;

  const ToolPage({
    super.key,
    required this.title,
    required this.icon,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Row(
            children: [
              Icon(icon, color: accent, size: 30),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'SADEE X DIMA Optimizer',
            style: TextStyle(color: Colors.white54),
          ),
          const SizedBox(height: 18),
          ...items.map(
            (item) => Card(
              color: card,
              child: ListTile(
                leading: const Icon(
                  Icons.check_circle_outline,
                  color: accent,
                ),
                title: Text(
                  item,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        '$item is ready for the device-specific implementation.',
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
