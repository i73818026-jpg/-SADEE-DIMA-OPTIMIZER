-- Existing tables are expected:
-- public.license_keys
-- public.app_updates
--
-- The following makes the current public policies match the demo/admin client.
-- For a production deployment, replace these broad policies with Supabase Auth
-- and role-based RLS / Edge Functions.

ALTER TABLE public.license_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_updates ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public License Keys Policy" ON public.license_keys;
DROP POLICY IF EXISTS "Public App Updates Policy" ON public.app_updates;

CREATE POLICY "Public License Keys Policy"
ON public.license_keys FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Public App Updates Policy"
ON public.app_updates FOR ALL USING (true) WITH CHECK (true);
