package com.sadeedima.optimizer

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.StatFs
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channel = "sadee_x_dima/system"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getSystemMetrics" -> result.success(getSystemMetrics())
                    "isNetworkOnline" -> result.success(isNetworkOnline())
                    else -> result.notImplemented()
                }
            }
    }

    private fun getSystemMetrics(): Map<String, Any> {
        val memoryInfo = ActivityManager.MemoryInfo()
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(memoryInfo)

        val stat = StatFs(filesDir.absolutePath)
        val totalBytes = stat.totalBytes
        val freeBytes = stat.availableBytes

        val batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val battery = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        return mapOf(
            "ramTotalMb" to (memoryInfo.totalMem / 1048576L).toInt(),
            "ramAvailableMb" to (memoryInfo.availMem / 1048576L).toInt(),
            "storageTotalGb" to (totalBytes.toDouble() / 1073741824.0),
            "storageFreeGb" to (freeBytes.toDouble() / 1073741824.0),
            "battery" to battery,
            "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
            "android" to Build.VERSION.RELEASE,
            "sdk" to Build.VERSION.SDK_INT
        )
    }

    private fun isNetworkOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
