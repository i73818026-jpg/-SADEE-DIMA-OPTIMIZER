# SADEE X DIMA OPTIMIZER — REAL USER + ADMIN

This is a fresh Flutter project built around the supplied SADEE X DIMA logo.

## Included apps
- USER: `lib/main_user.dart`
- ADMIN: `lib/main_admin.dart`

## User features
- Cyber gaming dashboard
- 7 DAYS — LKR 500
- 1 MONTH — LKR 1,000
- LIFETIME — LKR 2,200
- WhatsApp order to +94 76 847 2404
- Supabase license activation
- Live expiry countdown
- Real Android RAM / battery / storage / CPU-core / network metrics where Android exposes them
- Device monitor
- Gaming launcher
- All tool cards from the supplied HTML reference

Tool cards that Android cannot safely perform on other apps are presented as demo/control actions rather than fake performance claims.

## Admin
- Supabase Auth login
- License counts
- Active licenses
- Orders
- Revenue
- License creation
- Admin modules for users, licenses, orders, devices, announcements and activity logs

## Supabase
1. Open Supabase SQL Editor.
2. Run `DATABASE_SETUP.sql`.
3. Create an admin user in Supabase Auth.
4. Insert the admin user's UUID into `public.profiles` with `role = 'admin'`.
5. Create real license keys in `public.license_keys`.

## Build
```bash
flutter pub get
flutter analyze --no-fatal-infos --no-fatal-warnings
flutter build apk --release --flavor user -t lib/main_user.dart
flutter build apk --release --flavor admin -t lib/main_admin.dart
```

Never put a Supabase service-role/secret key in the APK.
