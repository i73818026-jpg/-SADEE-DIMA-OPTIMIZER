class AppConfig {
  static const supabaseUrl = 'https://cpmzjplfqggmgeotmtcd.supabase.co';
  static const supabasePublishableKey =
      'sb_publishable_z0kmWe85ybkmBg7bzEtyKA_kMH6WGXW';

  static const whatsappNumber = '94768472404';

  static const appName = 'SADEE X DIMA OPTIMIZER';
  static const adminName = 'SADEE X DIMA ADMIN';
}
