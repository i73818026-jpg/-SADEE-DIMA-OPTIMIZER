import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../widgets/cyber_card.dart';

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  final email = TextEditingController();
  final password = TextEditingController();
  final key = TextEditingController();

  bool loggedIn = false;
  String message = '';
  int activeLicenses = 0;
  int totalLicenses = 0;
  int orders = 0;
  double revenue = 0;

  SupabaseClient get db => Supabase.instance.client;

  Future<void> login() async {
    try {
      await db.auth.signInWithPassword(
        email: email.text.trim(),
        password: password.text,
      );
      setState(() {
        loggedIn = true;
        message = 'ADMIN SESSION ACTIVE';
      });
      await refresh();
    } catch (e) {
      setState(() => message = 'LOGIN FAILED');
    }
  }

  Future<void> refresh() async {
    try {
      final all = await db.from('license_keys').select('status');
      final active = await db
          .from('license_keys')
          .select('id')
          .eq('status', 'active');
      final sales = await db.from('orders').select('amount,status');

      double total = 0;
      for (final row in sales) {
        if ((row['status'] ?? '').toString() == 'paid') {
          total += double.tryParse(row['amount'].toString()) ?? 0;
        }
      }

      setState(() {
        totalLicenses = all.length;
        activeLicenses = active.length;
        orders = sales.length;
        revenue = total;
      });
    } catch (_) {}
  }

  Future<void> generateKey() async {
    if (!loggedIn) return;
    try {
      await db.from('license_keys').insert({
        'license_key': key.text.trim().toUpperCase(),
        'plan_name': 'CUSTOM',
        'status': 'active',
      });
      setState(() => message = 'LICENSE CREATED');
      await refresh();
    } catch (_) {
      setState(() => message = 'LICENSE CREATE FAILED');
    }
  }

  Future<void> logout() async {
    await db.auth.signOut();
    setState(() => loggedIn = false);
  }

  Widget loginView() {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: SizedBox(
            width: 440,
            child: CyberCard(
              child: Column(
                children: [
                  Image.asset('assets/sadee_logo.png', width: 170),
                  const SizedBox(height: 18),
                  const Text(
                    AppConfig.adminName,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 22),
                  TextField(
                    controller: email,
                    decoration: const InputDecoration(
                      labelText: 'ADMIN EMAIL',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: password,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'ADMIN PASSWORD',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 15),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: login,
                      child: const Text('ENTER ADMIN COMMAND CENTER'),
                    ),
                  ),
                  if (message.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text(message, style: const TextStyle(color: Color(0xFFFF314D))),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget dashboard() {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SADEE X DIMA ADMIN'),
        actions: [
          IconButton(onPressed: refresh, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: refresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'COMMAND CENTER',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 5),
            Text(
              message,
              style: const TextStyle(color: Color(0xFFFF314D), fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.45,
              children: [
                _stat('TOTAL LICENSES', '$totalLicenses'),
                _stat('ACTIVE LICENSES', '$activeLicenses'),
                _stat('ORDERS', '$orders'),
                _stat('REVENUE', 'LKR ${revenue.toStringAsFixed(0)}'),
              ],
            ),
            const SizedBox(height: 14),
            CyberCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('LICENSE CONTROL',
                      style: TextStyle(color: Color(0xFFFF314D), fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  TextField(
                    controller: key,
                    textCapitalization: TextCapitalization.characters,
                    decoration: const InputDecoration(
                      labelText: 'NEW LICENSE KEY',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: generateKey,
                      child: const Text('CREATE LICENSE'),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            CyberCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('ADMIN MODULES',
                      style: TextStyle(color: Color(0xFFFF314D), fontWeight: FontWeight.w900)),
                  SizedBox(height: 12),
                  ListTile(leading: Icon(Icons.people), title: Text('User Management')),
                  ListTile(leading: Icon(Icons.vpn_key), title: Text('License Management')),
                  ListTile(leading: Icon(Icons.receipt_long), title: Text('Orders & Payments')),
                  ListTile(leading: Icon(Icons.devices), title: Text('Device Bindings')),
                  ListTile(leading: Icon(Icons.campaign), title: Text('Announcements')),
                  ListTile(leading: Icon(Icons.history), title: Text('Activity Logs')),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String title, String value) => CyberCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.analytics, color: Color(0xFFFF314D)),
            const Spacer(),
            Text(title, style: const TextStyle(color: Color(0xFF8E8E95), fontSize: 10)),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    return loggedIn ? dashboard() : loginView();
  }
}
