import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../services/license_service.dart';
import '../services/system_metrics.dart';
import '../widgets/cyber_card.dart';

class Plan {
  final String name;
  final String price;
  final int? days;

  const Plan(this.name, this.price, this.days);
}

const plans = [
  Plan('7 DAYS', 'LKR 500', 7),
  Plan('1 MONTH', 'LKR 1,000', 30),
  Plan('LIFETIME', 'LKR 2,200', null),
];

const tools = [
  'RAM Cleaner',
  'RAM Booster',
  'Clear Cache',
  'Junk Cleaner',
  'CPU Booster',
  'CPU Monitor',
  'GPU Monitor',
  'FPS Booster',
  'Game Booster',
  'Network Booster',
  'Ping Optimizer',
  'DNS Optimizer',
  'Storage Cleaner',
  'Storage Monitor',
  'Battery Optimizer',
  'Battery Monitor',
  'Temperature Monitor',
  'Background Apps',
  'Memory Monitor',
  'Performance Scan',
  'System Scan',
  'Network Scan',
  'Gaming Mode',
  'Touch Optimizer',
  'Device Monitor',
  'Latency Reducer',
  'Frame Stabilizer',
  'Quick Optimize',
  'Game Launcher',
  'Ultimate Boost',
];

class UserHome extends StatefulWidget {
  const UserHome({super.key});

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  int tab = 0;
  String selectedPlan = '';
  String selectedPrice = '';
  String licenseKey = '';
  String licenseStatus = 'NOT ACTIVATED';
  String expiryText = 'NO ACTIVE LICENSE';
  DateTime? expiry;
  Timer? ticker;

  int ram = 0;
  int cores = 0;
  String battery = 'N/A';
  String storage = 'N/A';
  String network = 'ONLINE';
  String os = Platform.operatingSystem;
  String screen = 'Android';
  String deviceId = '';
  String deviceModel = 'Android device';

  @override
  void initState() {
    super.initState();
    _loadDevice();
    ticker = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  @override
  void dispose() {
    ticker?.cancel();
    super.dispose();
  }

  Future<void> _loadDevice() async {
    final metrics = await SystemMetrics.read();
    final online = await SystemMetrics.networkOnline();
    if (!mounted) return;
    setState(() {
      deviceId = (metrics['model'] ?? 'android-device').toString();
      cores = Platform.numberOfProcessors;
      ram = int.tryParse((metrics['ramTotalMb'] ?? 0).toString()) ?? 0;
      battery = '${metrics['battery'] ?? 'N/A'}%';
      final total = double.tryParse((metrics['storageTotalGb'] ?? 0).toString()) ?? 0;
      final free = double.tryParse((metrics['storageFreeGb'] ?? 0).toString()) ?? 0;
      storage = '${(total - free).toStringAsFixed(1)} / ${total.toStringAsFixed(1)} GB';
      network = online ? 'ONLINE' : 'OFFLINE';
      os = 'Android ${(metrics['android'] ?? '').toString()}';
      screen = 'Android';
      deviceModel = (metrics['model'] ?? 'Android device').toString();
    });
  }

  void _tick() {
    if (!mounted || expiry == null) return;
    final left = expiry!.difference(DateTime.now());
    if (left.isNegative) {
      setState(() {
        expiry = null;
        expiryText = 'EXPIRED';
        licenseStatus = 'EXPIRED';
      });
      return;
    }
    final d = left.inDays;
    final h = left.inHours % 24;
    final m = left.inMinutes % 60;
    final s = left.inSeconds % 60;
    setState(() {
      expiryText =
          'EXPIRES ${d}D ${h.toString().padLeft(2, '0')}H '
          '${m.toString().padLeft(2, '0')}M ${s.toString().padLeft(2, '0')}S';
    });
  }

  Future<void> _order(Plan plan) async {
    final text = Uri.encodeComponent(
      'SADEE X DIMA ORDER\n\n'
      'PLAN: ${plan.name}\n'
      'PRICE: ${plan.price}\n\n'
      'Please send payment confirmation and issue the license key.',
    );
    final uri = Uri.parse('https://wa.me/${AppConfig.whatsappNumber}?text=$text');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _activate() async {
    final result = await LicenseService().activate(
      key: licenseKey,
      deviceId: deviceId,
    );
    if (!mounted) return;

    if (result == null) {
      setState(() => licenseStatus = 'INVALID OR UNAVAILABLE KEY');
      return;
    }

    final status = (result['status'] ?? '').toString();
    final expiryRaw = result['expires_at']?.toString();
    DateTime? parsed;
    if (expiryRaw != null && expiryRaw != 'null') {
      parsed = DateTime.tryParse(expiryRaw)?.toLocal();
    }

    setState(() {
      licenseStatus = status.toUpperCase();
      expiry = parsed;
      selectedPlan = (result['plan_name'] ?? '').toString();
    });
    _tick();
  }

  void _runTool(String name) {
    final realActions = <String>{
      'CPU Monitor',
      'Storage Monitor',
      'Battery Monitor',
      'Memory Monitor',
      'Device Monitor',
      'Performance Scan',
      'System Scan',
      'Network Scan',
    };

    final text = realActions.contains(name)
        ? '$name • LIVE CHECK'
        : '$name • DEMO ACTION';

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _launchFreeFire() async {
    const uri = 'freefire://';
    final ok = await launchUrl(Uri.parse(uri), mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Free Fire is not available on this device.')),
      );
    }
  }

  Widget _header() {
    return SafeArea(
      bottom: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        decoration: const BoxDecoration(
          color: Color(0xE9050506),
          border: Border(bottom: BorderSide(color: Color(0xFF341017))),
        ),
        child: Row(
          children: [
            Image.asset('assets/sadee_logo.png', width: 46, height: 46),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                AppConfig.appName,
                style: TextStyle(
                  color: Color(0xFFFF314D),
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  selectedPlan.isEmpty ? 'NO LICENSE' : selectedPlan,
                  style: const TextStyle(
                    color: Color(0xFFFF314D),
                    fontWeight: FontWeight.w900,
                    fontSize: 11,
                  ),
                ),
                Text(
                  expiryText,
                  style: const TextStyle(
                    color: Color(0xFFB8C0C5),
                    fontSize: 9,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _dashboard() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'SYSTEM COMMAND CENTER',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w900,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'REAL DEVICE TELEMETRY + GAMING CONTROL',
          style: TextStyle(color: Color(0xFF8E8E95), fontSize: 11),
        ),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 1.55,
          children: [
            _metric('CPU CORES', '$cores', Icons.memory),
            _metric('RAM', ram == 0 ? 'N/A' : '$ram MB', Icons.storage),
            _metric('BATTERY', battery, Icons.battery_full),
            _metric('NETWORK', network, Icons.wifi),
          ],
        ),
        const SizedBox(height: 12),
        CyberCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'LICENSE STATUS',
                style: TextStyle(color: Color(0xFFFF314D), fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 10),
              Text(
                licenseStatus,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 5),
              Text(expiryText, style: const TextStyle(color: Color(0xFF9A9AA2))),
            ],
          ),
        ),
        const SizedBox(height: 12),
        CyberCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'GAMING LAUNCH',
                style: TextStyle(color: Color(0xFFFF314D), fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _launchFreeFire,
                  icon: const Icon(Icons.sports_esports),
                  label: const Text('LAUNCH FREE FIRE'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _metric(String title, String value, IconData icon) {
    return CyberCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFFFF314D)),
          const Spacer(),
          Text(title, style: const TextStyle(color: Color(0xFF8E8E95), fontSize: 10)),
          const SizedBox(height: 4),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }

  Widget _toolsPage() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: .92,
      ),
      itemCount: tools.length,
      itemBuilder: (_, i) {
        final name = tools[i];
        return CyberCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.bolt, color: Color(0xFFFF314D)),
              const SizedBox(height: 8),
              Expanded(
                child: Text(
                  name,
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13),
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => _runTool(name),
                  child: const Text('RUN'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _plansPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'ACCESS PLANS',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
        ),
        const Text(
          'SELECT A PLAN TO ORDER YOUR LICENSE',
          style: TextStyle(color: Color(0xFF8E8E95), fontSize: 11),
        ),
        const SizedBox(height: 18),
        ...plans.map(
          (p) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: CyberCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name, style: const TextStyle(color: Color(0xFFFF314D), fontWeight: FontWeight.w900)),
                  const SizedBox(height: 5),
                  Text(p.price, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 12),
                  const Text(
                    'Premium gaming dashboard access',
                    style: TextStyle(color: Color(0xFF8E8E95)),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () {
                        setState(() {
                          selectedPlan = p.name;
                          selectedPrice = p.price;
                        });
                        _order(p);
                      },
                      icon: const Icon(Icons.chat),
                      label: const Text('ORDER VIA WHATSAPP'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _licensePage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('LICENSE TERMINAL', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text('ENTER THE KEY ISSUED BY ADMIN', style: TextStyle(color: Color(0xFF8E8E95))),
        const SizedBox(height: 18),
        CyberCard(
          child: Column(
            children: [
              TextField(
                onChanged: (v) => licenseKey = v,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  labelText: 'LICENSE KEY',
                  prefixIcon: Icon(Icons.key),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _activate,
                  child: const Text('ACTIVATE LICENSE'),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                licenseStatus,
                style: const TextStyle(color: Color(0xFFFF314D), fontWeight: FontWeight.w900),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _devicePage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('DEVICE MONITOR', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 15),
        CyberCard(child: _row('OS', os)),
        CyberCard(child: _row('CPU CORES', '$cores')),
        CyberCard(child: _row('NETWORK', network)),
        CyberCard(child: _row('STORAGE', storage)),
        CyberCard(child: _row('BATTERY', battery)),
        CyberCard(child: _row('SCREEN', screen)),
        CyberCard(child: _row('DEVICE', deviceModel)),
        CyberCard(child: _row('DEVICE ID', deviceId.isEmpty ? 'INITIALIZING' : deviceId)),
      ],
    );
  }

  Widget _row(String a, String b) => Row(
        children: [
          Expanded(child: Text(a, style: const TextStyle(color: Color(0xFF8E8E95)))),
          Flexible(child: Text(b, textAlign: TextAlign.right)),
        ],
      );

  @override
  Widget build(BuildContext context) {
    final pages = [_dashboard(), _toolsPage(), _devicePage(), _plansPage(), _licensePage()];

    return Scaffold(
      body: Column(
        children: [
          _header(),
          Expanded(child: pages[tab]),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.bolt), label: 'Tools'),
          NavigationDestination(icon: Icon(Icons.phone_android), label: 'Device'),
          NavigationDestination(icon: Icon(Icons.workspace_premium), label: 'Plans'),
          NavigationDestination(icon: Icon(Icons.key), label: 'License'),
        ],
      ),
    );
  }
}
