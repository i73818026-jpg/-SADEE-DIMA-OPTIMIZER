import 'package:flutter/services.dart';

class SystemMetrics {
  static const MethodChannel _channel = MethodChannel('sadee_x_dima/system');

  static Future<Map<String, dynamic>> read() async {
    final value = await _channel.invokeMethod<dynamic>('getSystemMetrics');
    if (value is Map) {
      return Map<String, dynamic>.from(value);
    }
    return {};
  }

  static Future<bool> networkOnline() async {
    final value = await _channel.invokeMethod<dynamic>('isNetworkOnline');
    return value == true;
  }
}
