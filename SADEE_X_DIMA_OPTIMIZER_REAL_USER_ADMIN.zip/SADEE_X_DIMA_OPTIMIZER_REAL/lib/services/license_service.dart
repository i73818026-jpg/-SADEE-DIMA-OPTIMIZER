import 'package:supabase_flutter/supabase_flutter.dart';

class LicenseService {
  final SupabaseClient _db = Supabase.instance.client;

  Future<Map<String, dynamic>?> activate({
    required String key,
    required String deviceId,
  }) async {
    final result = await _db.rpc(
      'activate_license',
      params: {
        'p_key': key.trim().toUpperCase(),
        'p_device_id': deviceId,
      },
    );

    if (result == null) return null;
    if (result is Map<String, dynamic>) return result;
    if (result is List && result.isNotEmpty && result.first is Map) {
      return Map<String, dynamic>.from(result.first as Map);
    }
    return null;
  }

  Future<Map<String, dynamic>?> getLicense(String key) async {
    final result = await _db
        .from('license_keys')
        .select('plan_name,status,expires_at,device_id')
        .eq('license_key', key.toUpperCase())
        .maybeSingle();
    return result;
  }
}
