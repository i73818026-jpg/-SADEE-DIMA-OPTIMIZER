# SADEE X DIMA OPTIMIZER - Final Feature Build

## Included

### Performance
- RAM total / used / free monitoring
- App-owned RAM cleanup and Android memory hint
- CPU usage and CPU core count
- Battery level and battery health
- Charging status and battery temperature
- Storage used / free / total
- Performance health score
- Android thermal status
- Performance / Balanced / Cool Down modes

### Cleaner
- App cache cleanup
- Temporary / junk files
- Large files
- Old / unused files (180+ days)
- Duplicate files using SHA-256 verification
- Empty folders
- Download folder analysis
- File count and scan size
- Real scan progress
- Individual file selection
- Select all
- Cancel / Stop
- Safe deletion limited to shared-storage paths the app is permitted to access

### Gaming
- Free Fire detection
- Free Fire MAX detection
- Game launch center
- Pre-launch app-owned cleanup / memory hint
- Gaming session timer
- Battery / temperature / thermal monitoring
- Android display refresh-rate information where exposed
- Gaming session summary

### Device Center
- Manufacturer / model
- Android version / SDK
- RAM
- Storage
- Battery
- CPU / core count
- Network type
- Device uptime
- Display refresh rate
- Live refresh

### Safety / UX
- Cyber-style progress overlay
- Real scan progress
- Cancel / Stop
- Duplicate-operation protection
- Background thread for heavy storage scans
- Android operation notifications
- Operation history
- Before/after cleanup summaries
- No fake system-level RAM boost
- No modification of other apps' private data
- No game-file injection or modification

### VIP
- License gate before optimizer access
- 7 Days - LKR 500
- 1 Month - LKR 1,000
- Lifetime - LKR 2,200
- WhatsApp ordering to +94 76 847 2404
- Device binding
- Expiry validation
- Supabase license management

### Admin
- License generation
- 7 day / 30 day / lifetime plans
- Search and filter licenses
- Pause / activate / expire / delete
- Device binding visibility
- Supabase-backed license management

## Important Android limitation
A normal third-party Android application cannot silently clear another application's private cache/data, force CPU overclocking, or guarantee a system-wide RAM increase. This project only performs actions available through public Android APIs and app/shared-storage permissions.
