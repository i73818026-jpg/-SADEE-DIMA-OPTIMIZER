import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

const supabaseUrl = 'https://cpmzjplfqggmgeotmtcd.supabase.co';
const supabaseKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, publishableKey: supabaseKey);
  }
  runApp(const SadeeApp());
}

class SadeeApp extends StatelessWidget {
  const SadeeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SADEE X DIMA OPTIMIZER',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF0A0818),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF4F57)),
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final keyController = TextEditingController();
  final passwordController = TextEditingController();
  bool busy = false;

  Future<void> login() async {
    final key = keyController.text.trim().toUpperCase();
    final password = passwordController.text;
    if (key.isEmpty || password.isEmpty) {
      showMsg('Enter license key and password.');
      return;
    }
    if (supabaseKey.isEmpty) {
      showMsg('Supabase key is not configured in this build.');
      return;
    }
    setState(() => busy = true);
    try {
      final rows = await Supabase.instance.client
          .from('license_keys')
          .select()
          .eq('key_code', key)
          .limit(1);
      if (rows.isEmpty) {
        showMsg('Invalid license key.');
        return;
      }
      final data = Map<String, dynamic>.from(rows.first);
      final status = '${data['status'] ?? 'UNUSED'}';
      final expires = data['expires_at']?.toString();
      if (status == 'PAUSED' || status == 'EXPIRED') {
        showMsg('License is $status.');
        return;
      }
      if (expires != null &&
          DateTime.tryParse(expires)?.isBefore(DateTime.now().toUtc()) == true) {
        showMsg('License has expired.');
        return;
      }
      if (password != 'SADEE2026') {
        showMsg('Wrong password.');
        return;
      }
      if (status == 'UNUSED') {
        await Supabase.instance.client.from('license_keys').update({
          'status': 'ACTIVE',
          'activated_at': DateTime.now().toUtc().toIso8601String(),
          'expires_at': data['duration_days'] == -1
              ? null
              : DateTime.now()
                  .toUtc()
                  .add(Duration(days: (data['duration_days'] ?? 1) as int))
                  .toIso8601String(),
        }).eq('key_code', key);
      }
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const DashboardPage()),
      );
    } catch (e) {
      showMsg('Connection error: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void showMsg(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              color: const Color(0xFF1B1733),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  children: [
                    const Icon(Icons.bolt, size: 56, color: Color(0xFFFF5961)),
                    const SizedBox(height: 12),
                    const Text(
                      '𝕤𝕒𝕕𝕖𝕖 𝕏 𝕕𝕚𝕞𝕒 𝕠𝕡𝕥𝕚𝕞𝕚𝕫𝕖𝕣',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 6),
                    const Text('GAMING OPTIMIZER', style: TextStyle(color: Colors.white60)),
                    const SizedBox(height: 28),
                    TextField(
                      controller: keyController,
                      decoration: const InputDecoration(
                        labelText: 'License Key',
                        prefixIcon: Icon(Icons.key),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: passwordController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Password',
                        prefixIcon: Icon(Icons.lock),
                      ),
                    ),
                    const SizedBox(height: 18),
                    FilledButton.icon(
                      onPressed: busy ? null : login,
                      icon: const Icon(Icons.login),
                      label: Text(busy ? 'CHECKING...' : 'LOGIN'),
                    ),
                    const SizedBox(height: 20),
                    const Text('KEY PLANS', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    const Text('7 Days  •  Rs. 500\n1 Month  •  Rs. 1000\nLifetime  •  Rs. 2200',
                        textAlign: TextAlign.center),
                    const SizedBox(height: 14),
                    OutlinedButton.icon(
                      onPressed: () => openWhatsApp('Hello SADEE X DIMA, I want to order a license key.'),
                      icon: const Icon(Icons.chat),
                      label: const Text('ORDER ON WHATSAPP'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    keyController.dispose();
    passwordController.dispose();
    super.dispose();
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  Future<void> launchGame(BuildContext context) async {
    const packageName = 'com.dts.freefireth';
    final uri = Uri.parse('intent://#Intent;package=$packageName;end');
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Game app was not found.')),
        );
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open the game.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SADEE X DIMA OPTIMIZER'),
        actions: [
          IconButton(
            onPressed: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const LoginPage()),
            ),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _HeroCard(),
          const SizedBox(height: 14),
          _FeatureCard(
            icon: Icons.memory,
            title: 'RAM / Performance',
            text: 'Clean temporary app cache and reduce background load using normal Android app controls.',
          ),
          _FeatureCard(
            icon: Icons.touch_app,
            title: 'Touch & Display',
            text: 'Quick access to device display and touch settings. No game injection.',
          ),
          _FeatureCard(
            icon: Icons.speed,
            title: 'Gaming Mode',
            text: 'A lightweight dashboard for starting your game and keeping your setup ready.',
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () => launchGame(context),
            icon: const Icon(Icons.sports_esports),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('SADEE X DIMA LAUNCH'),
            ),
          ),
          const SizedBox(height: 18),
          const Center(
            child: Text('SADEE X DIMA • SAFE OPTIMIZER UI',
                style: TextStyle(color: Colors.white54)),
          ),
        ],
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  const _HeroCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(
          colors: [Color(0xFF30275A), Color(0xFF17122E)],
        ),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('DEVICE READY', style: TextStyle(color: Colors.white70)),
          SizedBox(height: 8),
          Text('Gaming Dashboard',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          SizedBox(height: 6),
          Text('Optimize • Prepare • Launch'),
        ],
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const _FeatureCard({required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF17132A),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFFFF5961)),
        title: Text(title),
        subtitle: Text(text),
      ),
    );
  }
}

Future<void> openWhatsApp(String message) async {
  final uri = Uri.parse(
    'https://wa.me/94768472404?text=${Uri.encodeComponent(message)}',
  );
  await launchUrl(uri, mode: LaunchMode.externalApplication);
}
