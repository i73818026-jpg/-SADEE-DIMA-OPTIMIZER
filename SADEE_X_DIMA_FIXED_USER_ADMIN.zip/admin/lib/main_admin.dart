import 'dart:math';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://cpmzjplfqggmgeotmtcd.supabase.co';
const supabaseKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, publishableKey: supabaseKey);
  }
  runApp(const AdminApp());
}

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SADEE ADMIN',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF0A0818),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF5961)),
      ),
      home: const AdminLogin(),
    );
  }
}

class AdminLogin extends StatefulWidget {
  const AdminLogin({super.key});
  @override
  State<AdminLogin> createState() => _AdminLoginState();
}

class _AdminLoginState extends State<AdminLogin> {
  final controller = TextEditingController();

  void login() {
    if (controller.text == 'ADMIN2026') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const AdminHome()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Wrong admin password.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(24),
          color: const Color(0xFF1B1733),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.admin_panel_settings, size: 64, color: Color(0xFFFF5961)),
                const SizedBox(height: 12),
                const Text('SADEE ADMIN CONTROL PANEL',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                TextField(
                  controller: controller,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Admin Password',
                    prefixIcon: Icon(Icons.lock),
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton(onPressed: login, child: const Text('LOGIN')),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
}

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  int days = 7;
  bool loading = true;
  List<Map<String, dynamic>> keys = [];

  SupabaseClient get db => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    if (supabaseKey.isEmpty) {
      setState(() => loading = false);
      return;
    }
    try {
      final result = await db.from('license_keys').select().order('created_at', ascending: false);
      keys = result.map<Map<String, dynamic>>((e) => Map<String, dynamic>.from(e)).toList();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Load failed: $e')));
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String makeKey() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random.secure();
    final parts = List.generate(3, (_) {
      return List.generate(5, (_) => chars[r.nextInt(chars.length)]).join();
    });
    return 'SADEE-${parts.join('-')}';
  }

  Future<void> generate() async {
    if (supabaseKey.isEmpty) return;
    final code = makeKey();
    try {
      await db.from('license_keys').insert({
        'key_code': code,
        'duration_days': days,
        'status': 'UNUSED',
      });
      await load();
      if (mounted) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('NEW LICENSE KEY'),
            content: SelectableText(code, style: const TextStyle(fontSize: 20)),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Generate failed: $e')));
      }
    }
  }

  Future<void> setStatus(String key, String status) async {
    await db.from('license_keys').update({'status': status}).eq('key_code', key);
    await load();
  }

  Future<void> deleteKey(String key) async {
    await db.from('license_keys').delete().eq('key_code', key);
    await load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sadee Admin Control Panel'),
        actions: [
          IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
          IconButton(
            onPressed: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const AdminLogin()),
            ),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Card(
              color: const Color(0xFF1B1733),
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Generate New License Key',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<int>(
                      value: days,
                      decoration: const InputDecoration(labelText: 'Select Duration'),
                      items: const [
                        DropdownMenuItem(value: 1, child: Text('1 Day')),
                        DropdownMenuItem(value: 3, child: Text('3 Days')),
                        DropdownMenuItem(value: 7, child: Text('7 Days')),
                        DropdownMenuItem(value: 14, child: Text('14 Days')),
                        DropdownMenuItem(value: 30, child: Text('1 Month')),
                        DropdownMenuItem(value: -1, child: Text('Lifetime')),
                      ],
                      onChanged: (v) => setState(() => days = v ?? 7),
                    ),
                    const SizedBox(height: 14),
                    FilledButton.icon(
                      onPressed: generate,
                      icon: const Icon(Icons.key),
                      label: const Padding(
                        padding: EdgeInsets.all(12),
                        child: Text('GENERATE KEY NOW'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text('All License Keys',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            if (supabaseKey.isEmpty)
              const Card(
                child: ListTile(
                  leading: Icon(Icons.info_outline),
                  title: Text('Supabase key not configured'),
                  subtitle: Text('Build with --dart-define=SUPABASE_ANON_KEY=...'),
                ),
              )
            else if (loading)
              const Center(child: Padding(
                padding: EdgeInsets.all(30),
                child: CircularProgressIndicator(),
              ))
            else if (keys.isEmpty)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Center(child: Text('No license keys yet.')),
              )
            else
              ...keys.map((k) => Card(
                    color: const Color(0xFF17132A),
                    child: ListTile(
                      title: Text('${k['key_code'] ?? ''}'),
                      subtitle: Text(
                        'Duration: ${k['duration_days'] ?? '-'} days\n'
                        'Status: ${k['status'] ?? '-'}\n'
                        'Device: ${k['device_id'] ?? 'Not Bound'}',
                      ),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) async {
                          if (value == 'delete') {
                            await deleteKey('${k['key_code']}');
                          } else {
                            await setStatus('${k['key_code']}', value);
                          }
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 'ACTIVE', child: Text('Resume / Activate')),
                          PopupMenuItem(value: 'PAUSED', child: Text('Pause')),
                          PopupMenuItem(value: 'EXPIRED', child: Text('Expire')),
                          PopupMenuItem(value: 'delete', child: Text('Delete')),
                        ],
                      ),
                    ),
                  )),
          ],
        ),
      ),
    );
  }
}
