-- Existing tables are assumed. If already created, do not rerun CREATE TABLE.
-- IMPORTANT: RLS policies that allow public writes are not recommended for production.
-- The current app expects license_keys to exist.

-- Optional: add an index for key lookup.
create index if not exists license_keys_key_code_idx on public.license_keys(key_code);
