import 'dart:math';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';

const bg = Color(0xFF070A10);
const card = Color(0xFF111722);
const accent = Color(0xFF00E5FF);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const SadeeAdminApp());
}

class SadeeAdminApp extends StatelessWidget {
  const SadeeAdminApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'SADEE X DIMA Admin',
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: bg, colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark), useMaterial3: true),
    home: const AdminLogin(),
  );
}

class AdminLogin extends StatefulWidget {
  const AdminLogin({super.key});
  @override State<AdminLogin> createState() => _AdminLoginState();
}
class _AdminLoginState extends State<AdminLogin> {
  final pin = TextEditingController();
  bool hide = true;
  // Change this before production use.
  static const adminPin = 'SADEE2026';

  void go() {
    if (pin.text == adminPin) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminShell()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invalid admin PIN.')));
    }
  }
  @override Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(25), child: Column(children: [
      const Icon(Icons.admin_panel_settings, color: accent, size: 80),
      const SizedBox(height: 15),
      const Text('𝕤𝕒𝕕𝕖𝕖 𝕏 𝕕𝕚𝕞𝕒', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
      const Text('ADMIN CONTROL PANEL', style: TextStyle(color: accent, letterSpacing: 3)),
      const SizedBox(height: 35),
      TextField(controller: pin, obscureText: hide, decoration: InputDecoration(labelText: 'Admin PIN', prefixIcon: const Icon(Icons.lock, color: accent), suffixIcon: IconButton(onPressed: () => setState(() => hide = !hide), icon: Icon(hide ? Icons.visibility : Icons.visibility_off)), filled: true, fillColor: card, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
      const SizedBox(height: 15),
      SizedBox(width: double.infinity, height: 54, child: FilledButton(onPressed: go, style: FilledButton.styleFrom(backgroundColor: accent, foregroundColor: Colors.black), child: const Text('ENTER ADMIN PANEL', style: TextStyle(fontWeight: FontWeight.w900)))),
    ])),
  );
}

class AdminShell extends StatefulWidget {
  const AdminShell({super.key});
  @override State<AdminShell> createState() => _AdminShellState();
}
class _AdminShellState extends State<AdminShell> {
  int tab = 0;
  final pages = const [OverviewPage(), KeysPage(), UpdatesPage(), AdminInfoPage()];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SADEE X DIMA ADMIN')),
    body: pages[tab],
    bottomNavigationBar: NavigationBar(
      selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), backgroundColor: card,
      destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
        NavigationDestination(icon: Icon(Icons.vpn_key_outlined), selectedIcon: Icon(Icons.vpn_key), label: 'Keys'),
        NavigationDestination(icon: Icon(Icons.system_update_outlined), selectedIcon: Icon(Icons.system_update), label: 'Updates'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'More'),
      ],
    ),
  );
}

class OverviewPage extends StatefulWidget {
  const OverviewPage({super.key});
  @override State<OverviewPage> createState() => _OverviewPageState();
}
class _OverviewPageState extends State<OverviewPage> {
  bool loading = true; int total = 0, active = 0, paused = 0, expired = 0;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      final rows = await Supabase.instance.client.from('license_keys').select('status');
      total = rows.length;
      active = rows.where((r) => r['status'] == 'ACTIVE').length;
      paused = rows.where((r) => r['status'] == 'PAUSED').length;
      expired = rows.where((r) => r['status'] == 'EXPIRED').length;
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }
  @override Widget build(BuildContext context) => RefreshIndicator(
    onRefresh: load,
    child: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('CONTROL CENTER', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
      const SizedBox(height: 5), const Text('Live Supabase license overview', style: TextStyle(color: Colors.white54)),
      const SizedBox(height: 18),
      if (loading) const LinearProgressIndicator(),
      Row(children: [Expanded(child: _c('TOTAL', total)), const SizedBox(width: 10), Expanded(child: _c('ACTIVE', active))]),
      const SizedBox(height: 10),
      Row(children: [Expanded(child: _c('PAUSED', paused)), const SizedBox(width: 10), Expanded(child: _c('EXPIRED', expired))]),
      const SizedBox(height: 18),
      Card(color: card, child: const ListTile(leading: Icon(Icons.bolt, color: accent), title: Text('SADEE X DIMA LICENSE SYSTEM', style: TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('Generate, activate, pause, resume, extend and revoke keys.'))),
    ]),
  );
  Widget _c(String t, int n) => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: const TextStyle(color: Colors.white54, fontSize: 12)), const SizedBox(height: 6), Text('$n', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: accent))]));
}

class KeysPage extends StatefulWidget {
  const KeysPage({super.key});
  @override State<KeysPage> createState() => _KeysPageState();
}
class _KeysPageState extends State<KeysPage> {
  bool loading = true; List<Map<String,dynamic>> rows = [];
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      final data = await Supabase.instance.client.from('license_keys').select().order('created_at', ascending: false);
      rows = List<Map<String,dynamic>>.from(data);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }
  String keyGen() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random();
    String part() => List.generate(5, (_) => chars[r.nextInt(chars.length)]).join();
    return 'SDX-${part()}-${part()}-${part()}';
  }
  Future<void> createKey(int days) async {
    final code = keyGen();
    try {
      await Supabase.instance.client.from('license_keys').insert({'key_code': code, 'duration_days': days, 'status': 'UNUSED'});
      await load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Created: $code')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Create failed: $e')));
    }
  }
  Future<void> setStatus(String code, String status) async {
    try {
      await Supabase.instance.client.from('license_keys').update({'status': status}).eq('key_code', code);
      await load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Update failed: $e')));
    }
  }
  Future<void> deleteKey(String code) async {
    try { await Supabase.instance.client.from('license_keys').delete().eq('key_code', code); await load(); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Delete failed: $e'))); }
  }
  @override Widget build(BuildContext context) => Stack(children: [
    RefreshIndicator(onRefresh: load, child: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(14), children: [
      const Text('LICENSE KEYS', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
      const SizedBox(height: 5), const Text('Generate and manage customer licenses', style: TextStyle(color: Colors.white54)),
      const SizedBox(height: 14),
      Wrap(spacing: 8, runSpacing: 8, children: [
        _btn('7 DAYS • 500', () => createKey(7)),
        _btn('30 DAYS • 1000', () => createKey(30)),
        _btn('LIFETIME • 2200', () => createKey(-1)),
      ]),
      const SizedBox(height: 15),
      ...rows.map((r) => _row(r)),
      const SizedBox(height: 80),
    ]),
    Positioned(right: 18, bottom: 18, child: FloatingActionButton.extended(onPressed: () => createKey(7), backgroundColor: accent, foregroundColor: Colors.black, icon: const Icon(Icons.add), label: const Text('NEW KEY'))),
  ]);
  Widget _btn(String t, VoidCallback f) => FilledButton.tonal(onPressed: f, child: Text(t));
  Widget _row(Map<String,dynamic> r) {
    final code = (r['key_code'] ?? '').toString(); final status = (r['status'] ?? 'UNUSED').toString(); final days = (r['duration_days'] ?? 0).toString();
    return Card(color: card, child: ExpansionTile(
      title: Text(code, style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
      subtitle: Text('$days days • $status'),
      childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
      children: [
        Wrap(spacing: 8, children: [
          if (status != 'ACTIVE') _small('ACTIVATE', () => setStatus(code, 'ACTIVE')),
          if (status == 'ACTIVE') _small('PAUSE', () => setStatus(code, 'PAUSED')),
          if (status == 'PAUSED') _small('RESUME', () => setStatus(code, 'ACTIVE')),
          if (status != 'EXPIRED') _small('EXPIRE', () => setStatus(code, 'EXPIRED')),
          _small('DELETE', () => deleteKey(code)),
        ]),
        const SizedBox(height: 8),
        Text('Device: ${r['device_id'] ?? 'Not bound'}'),
        Text('Activated: ${r['activated_at'] ?? 'Not activated'}'),
        Text('Expires: ${r['expires_at'] ?? 'Lifetime / not set'}'),
      ],
    ));
  }
  Widget _small(String t, VoidCallback f) => OutlinedButton(onPressed: f, child: Text(t));
}

class UpdatesPage extends StatelessWidget {
  const UpdatesPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('APP UPDATES', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    const Text('Manage version records stored in Supabase.', style: TextStyle(color: Colors.white54)),
    const SizedBox(height: 18),
    Card(color: card, child: const ListTile(leading: Icon(Icons.cloud_upload, color: accent), title: Text('Update Manager'), subtitle: Text('Use the app_updates table to publish version code, version name, download URL and force-update state.'))),
  ]);
}

class AdminInfoPage extends StatelessWidget {
  const AdminInfoPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('ADMIN TOOLS', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
    const SizedBox(height: 12),
    Card(color: card, child: const ListTile(leading: Icon(Icons.security, color: accent), title: Text('Security'), subtitle: Text('For production, move admin authentication and privileged database writes behind Supabase Auth/Edge Functions.'))),
    Card(color: card, child: const ListTile(leading: Icon(Icons.info_outline, color: accent), title: Text('Version'), subtitle: Text('SADEE X DIMA Admin v1.0.0'))),
  ]);
}
