# SADEE X DIMA Optimizer

A fresh Flutter Android starter for the SADEE X DIMA Optimizer concept.

Included:
- Login screen
- Dark gaming dashboard
- Optimize page
- Gaming page
- Performance page
- Settings page
- SADEE X DIMA LAUNCH page
- Native Android launcher list for installed launchable apps
- GitHub Actions APK build workflow

Note:
The launch page launches installed apps. It does not delete another app's private files or game data.
