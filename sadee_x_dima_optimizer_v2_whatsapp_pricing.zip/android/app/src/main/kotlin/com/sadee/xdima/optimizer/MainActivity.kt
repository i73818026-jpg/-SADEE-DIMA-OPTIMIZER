package com.sadee.xdima.optimizer

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "sadee.launcher"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getLaunchableApps" -> {
                        val pm = packageManager
                        val intent = Intent(Intent.ACTION_MAIN).apply {
                            addCategory(Intent.CATEGORY_LAUNCHER)
                        }
                        val resolves = pm.queryIntentActivities(intent, 0)
                        val apps = resolves
                            .mapNotNull { ri ->
                                val ai = ri.activityInfo?.applicationInfo ?: return@mapNotNull null
                                val pkg = ai.packageName
                                if (pkg == packageName) return@mapNotNull null
                                val label = pm.getApplicationLabel(ai).toString()
                                mapOf("label" to label, "packageName" to pkg)
                            }
                            .distinctBy { it["packageName"] }
                            .sortedBy { it["label"]?.lowercase() }
                        result.success(apps)
                    }
                    "launchApp" -> {
                        val pkg = call.argument<String>("packageName")
                        if (pkg.isNullOrBlank()) {
                            result.error("BAD_PACKAGE", "Package name is empty", null)
                        } else {
                            val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
                            if (launchIntent == null) {
                                result.error("NOT_FOUND", "App is not installed", null)
                            } else {
                                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                startActivity(launchIntent)
                                result.success(true)
                            }
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
