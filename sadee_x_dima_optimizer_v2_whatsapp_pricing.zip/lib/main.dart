import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

const bg = Color(0xFF080B12);
const card = Color(0xFF111722);
const accent = Color(0xFF00E5FF);

void main() {
  runApp(const SadeeApp());
}

class SadeeApp extends StatelessWidget {
  const SadeeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SADEE X DIMA Optimizer',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final keyController = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    setState(() => loading = true);
    await Future.delayed(const Duration(milliseconds: 700));
    if (!mounted) return;
    setState(() => loading = false);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const HomeShell()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Container(
                  width: 92, height: 92,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: accent, width: 2),
                    boxShadow: const [BoxShadow(color: Color(0x5500E5FF), blurRadius: 24)],
                  ),
                  child: const Icon(Icons.bolt_rounded, color: accent, size: 52),
                ),
                const SizedBox(height: 22),
                const Text(
                  '𝕤𝕒𝕕𝕖𝕖 𝕏 𝕕𝕚𝕞𝕒',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 1),
                ),
                const Text(
                  'OPTIMIZER',
                  style: TextStyle(color: accent, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 5),
                ),
                const SizedBox(height: 42),
                _field(keyController, 'License / Access Key', Icons.key_rounded),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: FilledButton(
                    onPressed: loading ? null : login,
                    style: FilledButton.styleFrom(
                      backgroundColor: accent,
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: loading
                        ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text('LOGIN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
                  ),
                ),
                const SizedBox(height: 24),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'KEY PRICES',
                    style: TextStyle(color: accent, fontWeight: FontWeight.w900, letterSpacing: 2),
                  ),
                ),
                const SizedBox(height: 10),
                _priceCard(context, '7 DAYS', 'Rs. 500', '7 Day License'),
                _priceCard(context, '1 MONTH', 'Rs. 1,000', '30 Day License'),
                _priceCard(context, 'LIFETIME', 'Rs. 2,200', 'Lifetime License'),
                const SizedBox(height: 8),
                const Text(
                  'Select a plan and tap BUY KEY to send your order on WhatsApp.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white54, fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _priceCard(BuildContext context, String title, String price, String duration) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0x3300E5FF)),
      ),
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: Color(0x2200E5FF),
          child: Icon(Icons.vpn_key_rounded, color: accent),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(duration),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(price, style: const TextStyle(color: accent, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            const Text('BUY KEY', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
          ],
        ),
        onTap: () => _orderOnWhatsApp(title, price),
      ),
    );
  }

  Future<void> _orderOnWhatsApp(String plan, String price) async {
    final message = Uri.encodeComponent(
      'Hello SADEE X DIMA, I want to order a $plan license ($price). Please send me the payment/order details.',
    );
    final uri = Uri.parse('https://wa.me/94768472404?text=$message');

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('WhatsApp could not be opened.')),
      );
    }
  }

  Widget _field(TextEditingController c, String hint, IconData icon) {
    return TextField(
      controller: c,
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: accent),
        hintText: hint,
        filled: true,
        fillColor: card,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      ),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  final pages = const [DashboardPage(), OptimizerPage(), GamingPage(), PerformancePage(), SettingsPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        backgroundColor: card,
        indicatorColor: const Color(0x3300E5FF),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.bolt_outlined), selectedIcon: Icon(Icons.bolt), label: 'Optimize'),
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'Gaming'),
          NavigationDestination(icon: Icon(Icons.speed_outlined), selectedIcon: Icon(Icons.speed), label: 'Performance'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
        children: [
          Row(
            children: [
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Welcome back', style: TextStyle(color: Colors.white54)),
                SizedBox(height: 4),
                Text('SADEE X DIMA', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
              ])),
              _circle(Icons.notifications_none),
            ],
          ),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF10232B), Color(0xFF101722)]),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: const Color(0x4400E5FF)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('DEVICE STATUS', style: TextStyle(color: accent, fontWeight: FontWeight.bold, letterSpacing: 2)),
              const SizedBox(height: 8),
              const Text('Android Device', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              Row(children: [
                _mini('RAM', 'Available', Icons.memory),
                const SizedBox(width: 10),
                _mini('Storage', 'Ready', Icons.storage),
                const SizedBox(width: 10),
                _mini('Battery', 'Healthy', Icons.battery_full),
              ]),
            ]),
          ),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: _stat('RAM', 'Ready', Icons.memory)),
            const SizedBox(width: 12),
            Expanded(child: _stat('Storage', 'Ready', Icons.storage)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _stat('Battery', 'Ready', Icons.battery_std)),
            const SizedBox(width: 12),
            Expanded(child: _stat('Performance', 'Good', Icons.speed)),
          ]),
          const SizedBox(height: 18),
          const Text('QUICK ACTIONS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          const SizedBox(height: 10),
          _action(context, 'One-Tap Optimize', 'Run safe local optimizations', Icons.bolt, const OptimizerPage()),
          _action(context, 'SADEE X DIMA LAUNCH', 'Choose and launch a game', Icons.rocket_launch, const LaunchPage()),
        ],
      ),
    );
  }

  Widget _circle(IconData icon) => Container(
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14)),
    child: Icon(icon),
  );

  Widget _mini(String a, String b, IconData icon) => Expanded(
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: accent, size: 18),
      const SizedBox(height: 6),
      Text(a, style: const TextStyle(fontWeight: FontWeight.bold)),
      Text(b, style: const TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );

  Widget _stat(String a, String b, IconData icon) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(18)),
    child: Row(children: [Icon(icon, color: accent), const SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(a, style: const TextStyle(color: Colors.white54, fontSize: 12)),
      Text(b, style: const TextStyle(fontWeight: FontWeight.bold)),
    ])]),
  );

  Widget _action(BuildContext context, String title, String sub, IconData icon, Widget page) => Card(
    color: card,
    child: ListTile(
      leading: CircleAvatar(backgroundColor: const Color(0x2200E5FF), child: Icon(icon, color: accent)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(sub),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
    ),
  );
}

class OptimizerPage extends StatefulWidget {
  const OptimizerPage({super.key});
  @override
  State<OptimizerPage> createState() => _OptimizerPageState();
}

class _OptimizerPageState extends State<OptimizerPage> {
  bool running = false;
  Future<void> run() async {
    setState(() => running = true);
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    setState(() => running = false);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Safe optimization completed.')));
  }

  @override
  Widget build(BuildContext context) => _page(
    'OPTIMIZER',
    'Safe local performance tools',
    [
      _tile('One-Tap Optimize', 'Run the app\'s safe optimization routine', Icons.bolt, running ? null : run),
      _tile('Memory Check', 'View current device memory information', Icons.memory, () {}),
      _tile('Storage Check', 'Review storage status', Icons.storage, () {}),
    ],
  );

  Widget _tile(String t, String s, IconData i, VoidCallback? onTap) => Card(
    color: card,
    child: ListTile(
      leading: Icon(i, color: accent),
      title: Text(t, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(s),
      trailing: onTap == null ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.chevron_right),
      onTap: onTap,
    ),
  );
}

class GamingPage extends StatelessWidget {
  const GamingPage({super.key});
  @override
  Widget build(BuildContext context) => _page(
    'GAMING',
    'Game-focused tools and launch shortcuts',
    [
      _tile(context, 'SADEE X DIMA LAUNCH', 'Select an installed game and launch it', Icons.rocket_launch, const LaunchPage()),
      _tile(context, 'Game Mode', 'Keep the gaming workflow simple and focused', Icons.sports_esports, null),
      _tile(context, 'Gaming Tips', 'Use the device controls and game settings safely', Icons.info_outline, null),
    ],
  );

  Widget _tile(BuildContext c, String t, String s, IconData i, Widget? page) => Card(
    color: card,
    child: ListTile(
      leading: Icon(i, color: accent),
      title: Text(t, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(s),
      trailing: const Icon(Icons.chevron_right),
      onTap: page == null ? null : () => Navigator.push(c, MaterialPageRoute(builder: (_) => page)),
    ),
  );
}

class PerformancePage extends StatelessWidget {
  const PerformancePage({super.key});
  @override
  Widget build(BuildContext context) => _page(
    'PERFORMANCE',
    'Device status overview',
    [
      _info('CPU', 'Android system will report current device state', Icons.developer_board),
      _info('RAM', 'Memory status available to the app', Icons.memory),
      _info('Battery', 'Battery state from Android', Icons.battery_full),
      _info('Storage', 'Storage state from Android', Icons.storage),
    ],
  );

  Widget _info(String a, String b, IconData i) => Card(
    color: card,
    child: ListTile(leading: Icon(i, color: accent), title: Text(a), subtitle: Text(b)),
  );
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) => _page(
    'SETTINGS',
    'SADEE X DIMA Optimizer',
    [
      Card(color: card, child: const ListTile(leading: Icon(Icons.info_outline, color: accent), title: Text('About'), subtitle: Text('SADEE X DIMA Optimizer v1.0.0'))),
      Card(color: card, child: ListTile(
        leading: const Icon(Icons.key, color: accent),
        title: const Text('License'),
        subtitle: const Text('Access key / license management'),
        onTap: () {},
      )),
      Card(color: card, child: ListTile(
        leading: const Icon(Icons.rocket_launch, color: accent),
        title: const Text('SADEE X DIMA LAUNCH'),
        subtitle: const Text('Select and launch an installed game'),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LaunchPage())),
      )),
    ],
  );
}

class LaunchPage extends StatefulWidget {
  const LaunchPage({super.key});
  @override
  State<LaunchPage> createState() => _LaunchPageState();
}

class _LaunchPageState extends State<LaunchPage> {
  static const channel = MethodChannel('sadee.launcher');
  List<Map<String, String>> apps = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadApps();
  }

  Future<void> loadApps() async {
    try {
      final result = await channel.invokeMethod<List<dynamic>>('getLaunchableApps');
      apps = (result ?? []).map((e) => Map<String, String>.from(e as Map)).toList();
    } catch (_) {
      apps = [];
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> launch(String packageName) async {
    await channel.invokeMethod('launchApp', {'packageName': packageName});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SADEE X DIMA LAUNCH')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : apps.isEmpty
              ? const Center(child: Text('No launchable apps found.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(14),
                  itemCount: apps.length,
                  itemBuilder: (_, i) {
                    final a = apps[i];
                    return Card(
                      color: card,
                      child: ListTile(
                        leading: const CircleAvatar(backgroundColor: Color(0x2200E5FF), child: Icon(Icons.sports_esports, color: accent)),
                        title: Text(a['label'] ?? 'App', style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text(a['packageName'] ?? ''),
                        trailing: const Icon(Icons.play_arrow, color: accent),
                        onTap: () => launch(a['packageName'] ?? ''),
                      ),
                    );
                  },
                ),
    );
  }
}

Widget _page(String title, String subtitle, List<Widget> children) => SafeArea(
  child: ListView(
    padding: const EdgeInsets.fromLTRB(18, 20, 18, 24),
    children: [
      Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 4),
      Text(subtitle, style: const TextStyle(color: Colors.white54)),
      const SizedBox(height: 20),
      ...children,
    ],
  ),
);
