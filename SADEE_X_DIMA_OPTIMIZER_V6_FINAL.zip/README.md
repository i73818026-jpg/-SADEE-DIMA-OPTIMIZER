# Sadee X Dima Optimizer

Flutter source for the **User app** and **Admin control panel**.

## Included
- Supabase configuration in `lib/config.dart`
- User entry point: `lib/main.dart` / `lib/main_user.dart`
- Admin entry point: `lib/main_admin.dart`
- License-key service and admin controls
- Device information display and optimizer simulation
- Rerunnable `DATABASE_SETUP.sql`

## Supabase
`lib/config.dart` is already configured for the Supabase project used by this source package.

Do **not** put a Supabase secret/service-role key in the Flutter app. The mobile client should use the publishable/anonymous client key only.

## Build
This ZIP contains the Dart source and package configuration, but it does **not** contain the generated Flutter `android/` project or a GitHub Actions workflow. Therefore this ZIP alone cannot produce an APK until it is placed in a Flutter project (or Android scaffolding/workflow is added).

For a normal Flutter project:
```bash
flutter pub get
flutter analyze
flutter build apk --release
```

User APK:
```bash
flutter build apk --release --target lib/main.dart
```

Admin APK:
```bash
flutter build apk --release --target lib/main_admin.dart
```

## Database
Run `DATABASE_SETUP.sql` in Supabase SQL Editor. The table creation and policy replacement are written so the script can be rerun without the original "relation already exists" / policy-exists errors.

> The public RLS policies in this demo allow client-side CRUD access. Before distributing the app publicly, review the database security rules and restrict admin operations appropriately.
