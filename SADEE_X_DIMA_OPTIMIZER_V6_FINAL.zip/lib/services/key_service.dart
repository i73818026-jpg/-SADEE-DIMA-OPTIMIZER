import 'dart:io';
import 'dart:math';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class KeyService {
  final supabase = Supabase.instance.client;
  Future<String> getDeviceId() async => (await DeviceInfoPlugin().androidInfo).id;
  Future<File> _keyFile() async => File('${(await getApplicationSupportDirectory()).path}/.sxd_license');
  Future<void> saveKey(String key) async { final f=await _keyFile(); await f.parent.create(recursive:true); await f.writeAsString(key.trim()); }
  Future<String?> loadSavedKey() async { try { final f=await _keyFile(); return f.existsSync() ? (await f.readAsString()).trim() : null; } catch (_) { return null; } }
  Future<void> clearSavedKey() async { try { final f=await _keyFile(); if (f.existsSync()) await f.delete(); } catch (_) {} }
  Future<Map<String,dynamic>> validateAndActivateKey(String keyInput) async {
    try {
      final key=keyInput.trim(); final device=await getDeviceId();
      final r=await supabase.from('license_keys').select().eq('key_code',key).maybeSingle();
      if (r==null) return {'success':false,'message':'Invalid license key'};
      final status=r['status']; final bound=r['device_id'];
      if (status=='PAUSED') return {'success':false,'message':'This key is paused by Admin.'};
      if (status=='EXPIRED') return {'success':false,'message':'This key has expired.'};
      if (status=='UNUSED') {
        final days=(r['duration_days'] as num).toInt(); final now=DateTime.now(); final exp=days==-1?null:now.add(Duration(days:days));
        await supabase.from('license_keys').update({'device_id':device,'status':'ACTIVE','activated_at':now.toIso8601String(),'expires_at':exp?.toIso8601String()}).eq('key_code',key);
        return {'success':true,'expiresAt':exp,'isLifetime':days==-1};
      }
      if (status=='ACTIVE') {
        if (bound!=device) return {'success':false,'message':'This key is already bound to another device.'};
        final raw=r['expires_at']; if (raw!=null) { final exp=DateTime.parse(raw); if (DateTime.now().isAfter(exp)) { await supabase.from('license_keys').update({'status':'EXPIRED'}).eq('key_code',key); return {'success':false,'message':'License expired.'}; } return {'success':true,'expiresAt':exp,'isLifetime':false}; }
        return {'success':true,'expiresAt':null,'isLifetime':true};
      }
      return {'success':false,'message':'Unknown license status.'};
    } catch(e) { return {'success':false,'message':'License error: $e'}; }
  }
  String generateRandomKey(){ const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; final r=Random(); final c=String.fromCharCodes(Iterable.generate(12,(_)=>chars.codeUnitAt(r.nextInt(chars.length)))); return 'SXD-${c.substring(0,4)}-${c.substring(4,8)}-${c.substring(8,12)}'; }
  Future<String> createLicenseKey(int durationDays) async { final k=generateRandomKey(); await supabase.from('license_keys').insert({'key_code':k,'duration_days':durationDays,'status':'UNUSED'}); return k; }
  Future<List<Map<String,dynamic>>> fetchAllKeys() async => List<Map<String,dynamic>>.from(await supabase.from('license_keys').select().order('created_at',ascending:false));
  Future<void> updateKeyStatus(String keyCode,String status) async { await supabase.from('license_keys').update({'status':status}).eq('key_code',keyCode); }
  Future<void> deleteKey(String keyCode) async { await supabase.from('license_keys').delete().eq('key_code',keyCode); }
}
