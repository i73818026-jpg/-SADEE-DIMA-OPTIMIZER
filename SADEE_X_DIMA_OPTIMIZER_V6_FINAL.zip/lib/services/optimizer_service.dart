import 'dart:async';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:system_info2/system_info2.dart';

class OptimizerService {
  static const MethodChannel _channel = MethodChannel('sadee_x_dima/system');
  static const EventChannel _events = EventChannel('sadee_x_dima/progress');
  Stream<Map<String, dynamic>> get progressStream => _events.receiveBroadcastStream().map((e) => Map<String, dynamic>.from(e as Map));

  Future<Map<String, String>> getDeviceInfo() async {
    try {
      final a = await DeviceInfoPlugin().androidInfo;
      final total = SysInfo.getTotalPhysicalMemory(); final free = SysInfo.getFreePhysicalMemory(); final used = total - free;
      return {'brand': a.manufacturer.toUpperCase(), 'model': a.model, 'device': a.device, 'androidVersion': a.version.release, 'sdkVersion': '${a.version.sdkInt}', 'totalRam': formatBytes(total), 'usedRam': formatBytes(used), 'freeRam': formatBytes(free), 'ramPercentage': '${total == 0 ? 0 : ((used / total) * 100).round()}%', 'cores': '${Platform.numberOfProcessors}'};
    } catch (_) { return {'brand':'ANDROID','model':'DEVICE','androidVersion':'Unknown','sdkVersion':'--','totalRam':'--','usedRam':'--','freeRam':'--','ramPercentage':'--','cores':'--'}; }
  }
  Future<Map<String, dynamic>> getSystemMetrics() async { try { return Map<String,dynamic>.from(await _channel.invokeMethod('getSystemMetrics')); } catch (_) { return {}; } }
  Future<void> trimMemory() async { try { await _channel.invokeMethod('trimOwnMemory'); } catch (_) {} }
  Future<bool> hasAllFilesAccess() async => await _channel.invokeMethod<bool>('hasAllFilesAccess') ?? false;
  Future<void> requestAllFilesAccess() async { await _channel.invokeMethod('requestAllFilesAccess'); }
  Future<void> clearOtherAppCaches() async { await _channel.invokeMethod('clearOtherAppCaches'); }
  Future<void> openBatterySettings() async { await _channel.invokeMethod('openBatterySettings'); }
  Future<void> openThermalSettings() async { await _channel.invokeMethod('openThermalSettings'); }
  Future<void> openGameSettings() async { await _channel.invokeMethod('openGameSettings'); }
  Future<void> openMemorySettings() async { await _channel.invokeMethod('openMemorySettings'); }
  Future<bool> openWhatsApp(String url) async => await _channel.invokeMethod<bool>('openWhatsApp', {'url': url}) ?? false;
  Future<bool> isGameInstalled(String package) async => await _channel.invokeMethod<bool>('isPackageInstalled', {'package': package}) ?? false;
  Future<bool> launchPackage(String package) async => await _channel.invokeMethod<bool>('launchPackage', {'package': package}) ?? false;
  Future<int> getAppCacheBytes() async { final d = await getTemporaryDirectory(); return _directorySize(d); }
  Future<int> clearAppCache() async { final d = await getTemporaryDirectory(); final before = await _directorySize(d); if (d.existsSync()) { for (final e in d.listSync(followLinks:false)) { try { await e.delete(recursive:true); } catch (_) {} } } return before; }
  Future<Map<String,dynamic>> scanFiles(String category) async { try { return Map<String,dynamic>.from(await _channel.invokeMethod('scanFiles', {'category':category})); } catch (_) { return {'files':<dynamic>[], 'totalBytes':0, 'scannedFiles':0}; } }
  Future<void> cancelScan() async { try { await _channel.invokeMethod('cancelScan'); } catch (_) {} }
  Future<Map<String,dynamic>> deleteFiles(List<String> paths) async { try { return Map<String,dynamic>.from(await _channel.invokeMethod('deleteFiles', {'paths':paths})); } catch (_) { return {'deleted':0,'bytes':0}; } }
  Future<int> _directorySize(Directory d) async { if (!d.existsSync()) return 0; var total=0; await for (final e in d.list(followLinks:false)) { try { if (e is File) total += await e.length(); else if (e is Directory) total += await _directorySize(e); } catch (_) {} } return total; }
  String formatBytes(num b) { if (b < 1024) return '${b.round()} B'; if (b < 1024*1024) return '${(b/1024).toStringAsFixed(1)} KB'; if (b < 1024*1024*1024) return '${(b/(1024*1024)).toStringAsFixed(1)} MB'; return '${(b/(1024*1024*1024)).toStringAsFixed(2)} GB'; }
}
