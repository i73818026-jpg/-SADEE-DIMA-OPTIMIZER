import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/key_service.dart';
import 'user_home.dart';

class LicenseGateScreen extends StatefulWidget {
  const LicenseGateScreen({super.key});
  @override State<LicenseGateScreen> createState() => _LicenseGateScreenState();
}

class _LicenseGateScreenState extends State<LicenseGateScreen> {
  static const _channel = MethodChannel('sadee_x_dima/system');
  static const bg = Color(0xFF050609), panel = Color(0xFF101318), green = Color(0xFF39FF88), cyan = Color(0xFF00E5FF), red = Color(0xFFFF315B);
  final key = TextEditingController();
  final service = KeyService();
  bool busy = false;
  String status = 'PREMIUM ACCESS LOCKED';
  final plans = const [
    ('7 DAYS', 500, 7), ('1 MONTH', 1000, 30), ('LIFETIME', 2200, -1),
  ];

  @override void initState() { super.initState(); _trySavedKey(); }

  Future<void> _trySavedKey() async {
    final saved = await service.loadSavedKey();
    if (saved == null || saved.isEmpty) return;
    key.text = saved;
    await _activate(auto: true);
  }

  Future<void> _activate({bool auto = false}) async {
    if (key.text.trim().isEmpty) { if (!auto) _msg('Enter your license key', red); return; }
    setState(() { busy = true; status = 'VERIFYING LICENSE...'; });
    final res = await service.validateAndActivateKey(key.text.trim());
    if (!mounted) return;
    if (res['success'] == true) {
      await service.saveKey(key.text.trim());
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const UserHomeScreen()));
    } else {
      setState(() { busy = false; status = 'PREMIUM ACCESS LOCKED'; });
      if (!auto) _msg(res['message'].toString(), red);
    }
  }

  Future<void> _buy(String plan, int price, int days) async {
    final text = Uri.encodeComponent('SADEE X DIMA OPTIMIZER License Order\nPlan: $plan\nPrice: LKR $price\nDevice: ${Platform.operatingSystem}\nPlease send payment details.');
    try { await _channel.invokeMethod('openWhatsApp', {'url': 'https://wa.me/94768472404?text=$text'}); }
    catch (_) { _msg('WhatsApp could not be opened', red); }
  }

  void _msg(String s, Color c) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s), backgroundColor: c));

  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: bg,
    body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(18), child: Column(children: [
      const SizedBox(height: 18),
      const Icon(Icons.shield_moon, color: green, size: 64),
      const SizedBox(height: 8),
      const Text('SADEE X DIMA', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 2)),
      const Text('OPTIMIZER', style: TextStyle(color: green, fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: 4)),
      const SizedBox(height: 18),
      _gateCard(), const SizedBox(height: 18),
      const Align(alignment: Alignment.centerLeft, child: Text('CHOOSE YOUR PLAN', style: TextStyle(color: cyan, fontWeight: FontWeight.w900, letterSpacing: 1.5))),
      const SizedBox(height: 10),
      ...plans.map((p) => _plan(p.$1, p.$2, p.$3)),
      const SizedBox(height: 12),
      const Text('1 LICENSE = 1 DEVICE • Device binding + expiry protection', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 11)),
      const SizedBox(height: 18),
    ]))),
  );

  Widget _gateCard() => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22), border: Border.all(color: green.withOpacity(.35))), child: Column(children: [
    Text(status, style: const TextStyle(color: green, fontWeight: FontWeight.w900)), const SizedBox(height: 14),
    TextField(controller: key, enabled: !busy, style: const TextStyle(color: Colors.white), textCapitalization: TextCapitalization.characters, decoration: InputDecoration(prefixIcon: const Icon(Icons.key, color: green), hintText: 'SXD-XXXX-XXXX-XXXX', hintStyle: const TextStyle(color: Colors.white30), filled: true, fillColor: Colors.black26, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
    const SizedBox(height: 12),
    SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(onPressed: busy ? null : () => _activate(), icon: busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.lock_open), label: Text(busy ? 'VERIFYING...' : 'ACTIVATE LICENSE'))),
    const SizedBox(height: 8), const Text('Paste a valid key to unlock the optimizer.', style: TextStyle(color: Colors.white38, fontSize: 12)),
  ]));

  Widget _plan(String name, int price, int days) => Card(color: panel, margin: const EdgeInsets.only(bottom: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: days == -1 ? green : Colors.white12)), child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7), leading: Icon(days == -1 ? Icons.all_inclusive : Icons.calendar_month, color: green), title: Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), subtitle: Text('Full Optimization • Performance • Gaming', style: const TextStyle(color: Colors.white45, fontSize: 11)), trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [Text('LKR $price', style: const TextStyle(color: green, fontWeight: FontWeight.w900, fontSize: 16)), TextButton(onPressed: () => _buy(name, price, days), child: const Text('BUY • WHATSAPP'))])));
}
