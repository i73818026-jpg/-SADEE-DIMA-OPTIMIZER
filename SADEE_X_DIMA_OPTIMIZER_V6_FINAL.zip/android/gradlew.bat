@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "DIST=%USERPROFILE%\.gradle\flutter-wrapper\gradle-%GRADLE_VERSION%"
if not exist "%DIST%\bin\gradle.bat" (
  echo Windows wrapper not configured for CI.
  exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
