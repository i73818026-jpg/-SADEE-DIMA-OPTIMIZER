package com.sadeedima.sadee_x_dima

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.TrafficStats
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

class MainActivity : FlutterActivity() {
    private val channel = "sadee_x_dima/system"
    private val eventChannel = "sadee_x_dima/progress"
    private val scanRoot: File get() = Environment.getExternalStorageDirectory()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val cancelScan = AtomicBoolean(false)
    private var progressSink: EventChannel.EventSink? = null

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        EventChannel(engine.dartExecutor.binaryMessenger, eventChannel).setStreamHandler(object: EventChannel.StreamHandler {
            override fun onListen(args: Any?, sink: EventChannel.EventSink?) { progressSink = sink }
            override fun onCancel(args: Any?) { progressSink = null }
        })
        MethodChannel(engine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            when (call.method) {
                "getSystemMetrics" -> result.success(getSystemMetrics())
                "hasAllFilesAccess" -> result.success(hasAllFilesAccess())
                "requestAllFilesAccess" -> { openAllFilesAccess(); result.success(true) }
                "clearOtherAppCaches" -> { openClearAllCaches(); result.success(true) }
                "openBatterySettings" -> { openIntent(Settings.ACTION_BATTERY_SAVER_SETTINGS); result.success(true) }
                "openThermalSettings" -> { openIntent(Settings.ACTION_SETTINGS); result.success(true) }
                "openGameSettings" -> { openIntent("android.settings.GAME_SETTINGS"); result.success(true) }
                "openMemorySettings" -> { openIntent(Settings.ACTION_SETTINGS); result.success(true) }
                "trimOwnMemory" -> { val am=getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager; am.getMemoryInfo(ActivityManager.MemoryInfo()); result.success(true) }
                "isPackageInstalled" -> result.success(isPackageInstalled(call.argument<String>("package")))
                "launchPackage" -> launchPackage(call.argument<String>("package"), result)
                "openWhatsApp" -> openUrl(call.argument<String>("url"), result)
                "cancelScan" -> { cancelScan.set(true); result.success(true) }
                "scanFiles" -> { startScan(call.argument<String>("category") ?: "junk", result) }
                "deleteFiles" -> result.success(deleteFiles(call.argument<List<String>>("paths") ?: emptyList()))
                else -> result.notImplemented()
            }
        }
        createNotificationChannel()
    }

    private fun getSystemMetrics(): Map<String, Any> {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val bi = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level=bi?.getIntExtra(BatteryManager.EXTRA_LEVEL,-1)?:-1; val scale=bi?.getIntExtra(BatteryManager.EXTRA_SCALE,100)?:100
        val temp=bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1)?:-1; val health=bi?.getIntExtra(BatteryManager.EXTRA_HEALTH,-1)?:-1; val status=bi?.getIntExtra(BatteryManager.EXTRA_STATUS,-1)?:-1
        val cap=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); val charging=status==BatteryManager.BATTERY_STATUS_CHARGING||status==BatteryManager.BATTERY_STATUS_FULL
        val st=StatFs(Environment.getDataDirectory().path); val total=st.totalBytes; val free=st.availableBytes; val cpu=readCpuUsage(); val rx=TrafficStats.getTotalRxBytes(); val tx=TrafficStats.getTotalTxBytes()
        val thermal=if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){(getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).currentThermalStatus}else 0
        val thermalName=when(thermal){0->"NONE";1->"LIGHT";2->"MODERATE";3->"SEVERE";4->"CRITICAL";5->"EMERGENCY";6->"SHUTDOWN";else->"UNKNOWN"}
        val refresh=try{(getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.refreshRate.toDouble()}catch(_:Exception){-1.0}
        val networkType=try{val cm=getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager; val n=cm.activeNetwork; val c=cm.getNetworkCapabilities(n); when{c?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)==true->"Wi-Fi";c?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR)==true->"Mobile";else->"Offline/Other"}}catch(_:Exception){"Unknown"}
        return mapOf("cpuUsage" to cpu,"cpuCores" to Runtime.getRuntime().availableProcessors(),"batteryLevel" to if(cap>=0)cap else if(level>=0)((level*100f)/scale).roundToInt() else -1,"batteryTempC" to if(temp>=0)temp/10.0 else -1.0,"batteryHealth" to batteryHealthName(health),"charging" to charging,"storageTotal" to total,"storageFree" to free,"storageUsed" to (total-free).coerceAtLeast(0),"networkRx" to rx,"networkTx" to tx,"networkType" to networkType,"thermalStatus" to thermal,"thermalName" to thermalName,"uptimeHours" to String.format(Locale.US,"%.1f",SystemClock.elapsedRealtime()/3600000.0),"refreshRateHz" to String.format(Locale.US,"%.0f",refresh))
    }
    private fun batteryHealthName(v:Int)=when(v){BatteryManager.BATTERY_HEALTH_GOOD->"GOOD";BatteryManager.BATTERY_HEALTH_OVERHEAT->"OVERHEAT";BatteryManager.BATTERY_HEALTH_DEAD->"DEAD";BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE->"OVER VOLTAGE";BatteryManager.BATTERY_HEALTH_COLD->"COLD";else->"UNKNOWN"}
    private fun readCpuUsage():Double=try{fun r():LongArray{val line=File("/proc/stat").useLines{it.firstOrNull{l->l.startsWith("cpu ")}}?:return longArrayOf(0,0);val p=line.trim().split(Regex("\\s+"));val user=p.getOrNull(1)?.toLongOrNull()?:0;val nice=p.getOrNull(2)?.toLongOrNull()?:0;val sys=p.getOrNull(3)?.toLongOrNull()?:0;val idle=p.getOrNull(4)?.toLongOrNull()?:0;val io=p.getOrNull(5)?.toLongOrNull()?:0;val irq=p.getOrNull(6)?.toLongOrNull()?:0;val sirq=p.getOrNull(7)?.toLongOrNull()?:0;val steal=p.getOrNull(8)?.toLongOrNull()?:0;val total=user+nice+sys+idle+io+irq+sirq+steal;longArrayOf(total,total-idle-io)};val a=r();Thread.sleep(120);val b=r();val t=b[0]-a[0];if(t<=0)0.0 else ((b[1]-a[1]).toDouble()/t*100).coerceIn(0.0,100.0)}catch(_:Exception){0.0}
    private fun hasAllFilesAccess()=Build.VERSION.SDK_INT<Build.VERSION_CODES.R||Environment.isExternalStorageManager()
    private fun openAllFilesAccess(){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.R)try{startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:$packageName")))}catch(_:Exception){startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))}}
    private fun openClearAllCaches(){try{startActivity(Intent("android.intent.action.CLEAR_APP_CACHE"))}catch(_:Exception){openIntent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)}}
    private fun openIntent(action:String){try{startActivity(Intent(action))}catch(_:Exception){startActivity(Intent(Settings.ACTION_SETTINGS))}}
    private fun isPackageInstalled(p:String?):Boolean=try{if(p.isNullOrBlank())false else {packageManager.getPackageInfo(p,0);true}}catch(_:Exception){false}
    private fun launchPackage(p:String?,r:MethodChannel.Result){if(p.isNullOrBlank()){r.success(false);return};try{val i=packageManager.getLaunchIntentForPackage(p);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);r.success(true)}else r.success(false)}catch(_:Exception){r.success(false)}}
    private fun openUrl(url:String?,r:MethodChannel.Result){try{if(url.isNullOrBlank()){r.success(false);return};startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)));r.success(true)}catch(_:Exception){r.success(false)}}

    private data class Candidate(val file:File,val size:Long)
    private fun startScan(category:String,result:MethodChannel.Result){
        if(!hasAllFilesAccess()){result.success(mapOf("permissionRequired" to true,"files" to emptyList<Map<String,Any>>(),"totalBytes" to 0L,"scannedFiles" to 0));return}
        cancelScan.set(false)
        Thread {
            val out=scanFilesWorker(category)
            mainHandler.post{result.success(out)}
        }.start()
    }
    private fun emitProgress(category:String,visited:Int,estimated:Int){val pct=if(estimated<=0)0 else ((visited.toDouble()/estimated)*100).coerceAtMost(99.0);mainHandler.post{progressSink?.success(mapOf("category" to category,"visited" to visited,"progress" to pct))}}
    private fun scanFilesWorker(category:String):Map<String,Any>{
        val candidates=ArrayList<Candidate>();val stack=ArrayDeque<File>();stack.add(scanRoot);var visited=0;var dirs=0;val maxFiles=60000
        while(stack.isNotEmpty()&&!cancelScan.get()&&visited<maxFiles){val dir=stack.removeLast();val children=try{dir.listFiles()?:emptyArray()}catch(_:Exception){emptyArray()};if(children.isEmpty()&&category=="empty"&&dir.absolutePath!=scanRoot.absolutePath){candidates.add(Candidate(dir,0));dirs++;continue};for(f in children){if(cancelScan.get())break;try{if(f.name=="Android")continue;if(f.isDirectory)stack.add(f) else if(f.isFile){visited++;if(matches(f,category))candidates.add(Candidate(f,f.length()))}}catch(_:Exception){};if(visited%200==0)emitProgress(category,visited,maxFiles)}}
        val finalList=if(category=="duplicates")duplicateCandidates(candidates)else candidates.sortedByDescending{it.size};val limited=finalList.take(400)
        notifyUser("$category scan", "Scanned $visited files • ${finalList.sumOf{it.size}} bytes")
        emitProgress(category,visited,maxFiles)
        return mapOf("permissionRequired" to false,"category" to category,"cancelled" to cancelScan.get(),"scannedFiles" to visited,"totalBytes" to finalList.sumOf{it.size},"files" to limited.map{mapOf("path" to it.file.absolutePath,"name" to it.file.name,"size" to it.size,"modified" to it.file.lastModified(),"isDirectory" to it.file.isDirectory)})
    }
    private fun matches(f:File,c:String):Boolean{val p=f.absolutePath.lowercase(Locale.US);val n=f.name.lowercase(Locale.US);val ext=n.substringAfterLast('.',"");val old=System.currentTimeMillis()-180L*24*60*60*1000;return when(c){"downloads"->p.contains("/download/")||p.contains("/downloads/");"large"->f.length()>=100L*1024*1024;"old"->f.lastModified()>0&&f.lastModified()<old;"junk"->ext in setOf("tmp","temp","log","bak","old","cache","crdownload","part","dmp")||n.endsWith(".nomedia.tmp");"duplicates"->f.length()>0;else->false}}
    private fun duplicateCandidates(input:List<Candidate>):List<Candidate>{val groups=input.groupBy{it.size}.filterValues{it.size>1};val out=ArrayList<Candidate>();for(g in groups.values){val hashes=HashMap<String,MutableList<Candidate>>();for(c in g){if(cancelScan.get())break;sha256(c.file)?.let{hashes.getOrPut(it){ArrayList()}.add(c)}};for(s in hashes.values)if(s.size>1)out.addAll(s.drop(1))};return out.sortedByDescending{it.size}}
    private fun sha256(f:File):String?=try{val d=MessageDigest.getInstance("SHA-256");FileInputStream(f).use{input->val b=ByteArray(128*1024);while(true){val n=input.read(b);if(n<=0)break;d.update(b,0,n)}};d.digest().joinToString(""){String.format("%02x",it)}}catch(_:Exception){null}
    private fun deleteFiles(paths:List<String>):Map<String,Any>{if(!hasAllFilesAccess())return mapOf("deleted" to 0,"bytes" to 0L,"permissionRequired" to true);var deleted=0;var bytes=0L;for(raw in paths){try{val f=File(raw);val root=scanRoot.canonicalPath+File.separator;val cp=f.canonicalPath;if(!cp.startsWith(root))continue;if(f.isFile){val s=f.length();if(f.delete()){deleted++;bytes+=s}}else if(f.isDirectory&&f.listFiles()?.isEmpty()!=false){if(f.delete())deleted++}}catch(_:Exception){}};notifyUser("CLEANER","Cleaned $deleted selected item(s) • $bytes bytes");return mapOf("deleted" to deleted,"bytes" to bytes,"permissionRequired" to false)}

    private fun createNotificationChannel(){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;nm.createNotificationChannel(NotificationChannel("sxd_ops","SADEE X DIMA Operations",NotificationManager.IMPORTANCE_LOW))}}
    private fun notifyUser(title:String,text:String){ mainHandler.post { try{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),77);return@post};val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;val n=if(Build.VERSION.SDK_INT>=26)android.app.Notification.Builder(this,"sxd_ops").setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true).build() else android.app.Notification.Builder(this).setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true).build();nm.notify((System.currentTimeMillis()%100000).toInt(),n)}catch(_:Exception){}} }
}
