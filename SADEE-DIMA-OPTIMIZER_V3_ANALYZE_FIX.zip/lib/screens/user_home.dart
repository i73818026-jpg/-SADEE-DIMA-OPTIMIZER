import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import '../services/key_service.dart';
import '../services/optimizer_service.dart';

class UserHomeScreen extends StatefulWidget {
  const UserHomeScreen({super.key});
  @override
  State<UserHomeScreen> createState() => _UserHomeScreenState();
}

class _UserHomeScreenState extends State<UserHomeScreen> {
  static const _bg = Color(0xFF090719);
  static const _panel = Color(0xFF191735);
  static const _cyan = Color(0xFF00F0FF);
  static const _green = Color(0xFF4DFFB0);
  static const _purple = Color(0xFF9C4DFF);
  static const _red = Color(0xFFFF4F5E);
  static const _channel = MethodChannel('sadee_x_dima/system');
  static const _scanCategories = ['downloads', 'screenshots', 'videos', 'large', 'junk', 'duplicates'];

  final KeyService _keyService = KeyService();
  final OptimizerService _optimizerService = OptimizerService();
  final TextEditingController _keyController = TextEditingController();

  int _tab = 0;
  bool _verified = false;
  bool _lifetime = false;
  bool _scanning = false;
  bool _launching = false;
  DateTime? _expiresAt;
  Duration _remaining = Duration.zero;
  Timer? _timer;
  Timer? _metricsTimer;
  Map<String, String> _device = {};
  Map<String, dynamic> _metrics = {};
  num _rxRate = 0;
  num _txRate = 0;
  num _lastRx = 0;
  num _lastTx = 0;
  DateTime? _lastMetricAt;
  final Map<String, Map<String, dynamic>> _scans = {};
  int _cacheBytes = 0;
  String _scanStatus = 'Ready for advanced scan';

  @override
  void initState() {
    super.initState();
    _load();
    _metricsTimer = Timer.periodic(const Duration(seconds: 3), (_) => _refreshMetrics());
  }

  Future<void> _load() async {
    final info = await _optimizerService.getDeviceInfo();
    final cache = await _optimizerService.getAppCacheBytes();
    final metrics = await _optimizerService.getSystemMetrics();
    final now = DateTime.now();
    _lastRx = (metrics['networkRx'] ?? 0) as num; _lastTx = (metrics['networkTx'] ?? 0) as num; _lastMetricAt = now;
    if (!mounted) return;
    setState(() { _device = info; _cacheBytes = cache; _metrics = metrics; });
  }

  Future<void> _refreshMetrics() async {
    final metrics = await _optimizerService.getSystemMetrics();
    final now = DateTime.now();
    final rx = (metrics['networkRx'] ?? 0) as num;
    final tx = (metrics['networkTx'] ?? 0) as num;
    final previous = _lastMetricAt;
    if (previous != null) {
      final seconds = now.difference(previous).inMilliseconds / 1000.0;
      if (seconds > 0.1) {
        _rxRate = ((rx - _lastRx) / seconds).clamp(0, double.infinity);
        _txRate = ((tx - _lastTx) / seconds).clamp(0, double.infinity);
      }
    }
    _lastRx = rx; _lastTx = tx; _lastMetricAt = now;
    if (!mounted) return;
    setState(() => _metrics = metrics);
  }

  Future<void> _activate() async {
    final key = _keyController.text.trim();
    if (key.isEmpty) return;
    setState(() => _scanning = true);
    final res = await _keyService.validateAndActivateKey(key);
    if (!mounted) return;
    setState(() => _scanning = false);
    if (res['success'] == true) {
      setState(() { _verified = true; _lifetime = res['isLifetime'] ?? false; _expiresAt = res['expiresAt']; });
      if (!_lifetime) _startTimer();
      _toast('VIP activated successfully', _green);
    } else _toast(res['message'].toString(), _red);
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_expiresAt == null) return;
      final left = _expiresAt!.difference(DateTime.now());
      if (!mounted) return;
      if (left.isNegative) { setState(() => _verified = false); _timer?.cancel(); }
      else setState(() => _remaining = left);
    });
  }

  Future<void> _smartOptimize() async {
    if (!_verified) { _toast('Activate a license first', Colors.orange); return; }
    setState(() { _scanning = true; _scanStatus = 'Running safe system optimization...'; });
    await _optimizerService.clearAppCache();
    await _optimizerService.clearOtherAppCaches();
    await Future.delayed(const Duration(milliseconds: 700));
    await _load();
    if (!mounted) return;
    setState(() { _scanning = false; _scanStatus = 'Optimization flow completed'; });
    _toast('Safe optimization completed. Android controls the final RAM/cache reclamation.', _green);
  }

  Future<void> _scanCategory(String category) async {
    if (!_verified) { _toast('Activate a license first', Colors.orange); return; }
    final access = await _optimizerService.hasAllFilesAccess();
    if (!access) {
      await _showStorageAccessDialog();
      return;
    }
    setState(() { _scanning = true; _scanStatus = 'Scanning ${_label(category)}...'; });
    final result = await _optimizerService.scanFiles(category);
    if (!mounted) return;
    setState(() { _scans[category] = result; _scanning = false; _scanStatus = '${_label(category)} scan complete'; });
    _toast('Found ${_optimizerService.formatBytes(result['totalBytes'] ?? 0)} in ${_label(category)}', _cyan);
  }

  Future<void> _scanAll() async {
    if (!_verified) { _toast('Activate a license first', Colors.orange); return; }
    if (!await _optimizerService.hasAllFilesAccess()) { await _showStorageAccessDialog(); return; }
    setState(() { _scanning = true; _scanStatus = 'Running full cleaner scan...'; });
    for (final category in _scanCategories) {
      final result = await _optimizerService.scanFiles(category);
      if (!mounted) return;
      _scans[category] = result;
      setState(() => _scanStatus = '${_label(category)} complete');
    }
    if (!mounted) return;
    setState(() => _scanning = false);
    final total = _scans.values.fold<num>(0, (sum, item) => sum + ((item['totalBytes'] ?? 0) as num));
    _toast('Full scan found ${_optimizerService.formatBytes(total)} of removable candidates', _green);
  }

  Future<void> _cleanCategory(String category) async {
    final scan = _scans[category];
    if (scan == null) { await _scanCategory(category); return; }
    final files = List<Map<String, dynamic>>.from((scan['files'] ?? []).map((e) => Map<String, dynamic>.from(e as Map)));
    if (files.isEmpty) { _toast('No files found', _green); return; }
    final ok = await _confirm('${_label(category)} clean', 'Delete ${files.length} scanned candidate files? This action cannot be undone.');
    if (!ok) return;
    final paths = files.map((e) => e['path'].toString()).toList();
    setState(() => _scanning = true);
    final result = await _optimizerService.deleteFiles(paths);
    if (!mounted) return;
    setState(() { _scanning = false; _scans.remove(category); });
    _toast('Deleted ${result['deleted'] ?? 0} files • ${_optimizerService.formatBytes(result['bytes'] ?? 0)}', _green);
  }

  Future<void> _cleanAppCache() async {
    if (!_verified) { _toast('Activate a license first', Colors.orange); return; }
    final cleared = await _optimizerService.clearAppCache();
    await _load();
    _toast('App cache cleaned: ${_optimizerService.formatBytes(cleared)}', _green);
  }

  Future<void> _launchGame({required bool max}) async {
    if (!_verified) { _toast('Activate a license first', Colors.orange); return; }
    setState(() => _launching = true);
    await _optimizerService.clearAppCache();
    await Future.delayed(const Duration(milliseconds: 500));
    final pkg = max ? 'com.dts.freefiremax' : 'com.dts.freefireth';
    final launched = await _channel.invokeMethod<bool>('launchPackage', {'package': pkg}) ?? false;
    if (!mounted) return;
    setState(() => _launching = false);
    if (!launched) _toast(max ? 'Free Fire MAX is not installed' : 'Free Fire is not installed', _red);
  }

  Future<void> _showStorageAccessDialog() async {
    final ok = await _confirm('Storage access required', 'Advanced file scanning needs Android “All files access”. It is used only for user-selected cleaner categories. Open the Android permission screen now?');
    if (ok) await _optimizerService.requestAllFilesAccess();
  }

  Future<bool> _confirm(String title, String text) async => await showDialog<bool>(context: context, builder: (_) => AlertDialog(backgroundColor: _panel, title: Text(title, style: const TextStyle(color: Colors.white)), content: Text(text, style: const TextStyle(color: Colors.white70)), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('CONTINUE'))])) ?? false;

  void _toast(String text, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), backgroundColor: color, behavior: SnackBarBehavior.floating));
  }

  String _timeLeft() => _lifetime ? '∞ LIFETIME' : '${_remaining.inDays}d ${_remaining.inHours % 24}h ${_remaining.inMinutes % 60}m';
  String _label(String key) => {'downloads':'Downloads','screenshots':'Screenshots','videos':'Videos','large':'Large Files','junk':'Junk Files','duplicates':'Duplicates'}[key] ?? key;
  String _bytes(dynamic v) => _optimizerService.formatBytes(v is num ? v : 0);

  @override
  void dispose() { _timer?.cancel(); _metricsTimer?.cancel(); _keyController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(backgroundColor: const Color(0xFF1D1A3D), elevation: 0, centerTitle: true, title: const Text('SADEE X DIMA OPTIMIZER', style: TextStyle(color: _cyan, fontWeight: FontWeight.w900, letterSpacing: 1.2))),
      body: SafeArea(child: IndexedStack(index: _tab, children: [_home(), _performance(), _gaming(), _cleaner(), _more()])),
      bottomNavigationBar: NavigationBar(backgroundColor: _panel, indicatorColor: _cyan.withValues(alpha: .16), selectedIndex: _tab, onDestinationSelected: (i) => setState(() => _tab = i), destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: _cyan), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.speed_outlined), selectedIcon: Icon(Icons.speed, color: _cyan), label: 'Performance'),
        NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports, color: _cyan), label: 'Gaming'),
        NavigationDestination(icon: Icon(Icons.cleaning_services_outlined), selectedIcon: Icon(Icons.cleaning_services, color: _cyan), label: 'Cleaner'),
        NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz, color: _cyan), label: 'More'),
      ]),
    );
  }

  Widget _home() => _page([
    _vipCard(), const SizedBox(height: 14), _healthCard(), const SizedBox(height: 14), _liveMetrics(), const SizedBox(height: 14), _deviceCard(), const SizedBox(height: 14),
    _actionButton('SMART SYSTEM OPTIMIZE', Icons.auto_awesome, _smartOptimize, _purple), const SizedBox(height: 10),
    _actionButton('FULL STORAGE SCAN', Icons.radar, _scanAll, _cyan),
  ]);

  Widget _performance() => _page([
    _sectionTitle('ADVANCED PERFORMANCE CENTER', 'Live CPU • RAM • battery • thermal • storage • network', Icons.speed),
    _liveMetrics(), const SizedBox(height: 12),
    _modeCard('SAFE SYSTEM OPTIMIZE', 'Clears this app cache and asks Android to perform its supported system-wide cache cleanup flow.', Icons.auto_awesome, _purple, _smartOptimize),
    _modeCard('MEMORY CENTER', 'Open Android memory management. Android decides which background processes can be reclaimed.', Icons.memory, _cyan, _optimizerService.openMemorySettings),
    _modeCard('THERMAL CENTER', 'Monitor temperature and thermal throttling state. Android does not allow a normal app to force-cool the CPU.', Icons.thermostat, _green, _optimizerService.openThermalSettings),
    _modeCard('BATTERY CENTER', 'Open battery saver controls and battery optimization settings.', Icons.battery_full, _green, () async { await _optimizerService.openBatterySettings(); }),
    _infoBox('REAL ANDROID LIMIT', 'A third-party app cannot safely force-free system RAM, change CPU voltage/frequency, or directly control another app’s private cache. This build uses Android-supported actions instead of fake “RAM boost” numbers.'),
  ]);

  Widget _gaming() => _page([
    _sectionTitle('GAMING CENTER', 'Free Fire launch + Android game/performance controls', Icons.sports_esports),
    _modeCard('ANDROID GAME CENTER', 'Open the device Game settings when the manufacturer exposes them. Any FPS, refresh-rate or game-mode change is applied by Android/OEM settings.', Icons.gamepad, _purple, _optimizerService.openGameSettings),
    const SizedBox(height: 12), _gameCard('FREE FIRE', 'com.dts.freefireth', false), const SizedBox(height: 12), _gameCard('FREE FIRE MAX', 'com.dts.freefiremax', true),
    const SizedBox(height: 12), _infoBox('THERMAL SAFE GAMING', 'The optimizer monitors CPU usage, battery temperature and Android thermal status before/while you use the Gaming Center. It reports throttling instead of pretending to control the hardware.'),
  ]);

  Widget _cleaner() => _page([
    _sectionTitle('ADVANCED CLEANER', 'Downloads • screenshots • videos • large files • junk • duplicates', Icons.cleaning_services),
    _scanCard(), const SizedBox(height: 12),
    _cleanOption('APP CACHE', 'Temporary files created by SADEE X DIMA', Icons.delete_sweep, _cacheBytes, _cleanAppCache),
    ..._scanCategories.map((c) => _scanOption(c)),
    const SizedBox(height: 8),
    _modeCard('SYSTEM APP-CACHE CLEANUP', 'Ask Android to show its supported system-wide app-cache cleanup flow. User/system confirmation may be required.', Icons.cleaning_services, _red, _optimizerService.clearOtherAppCaches),
    _infoBox('ADVANCED STORAGE ACCESS', 'File scanning uses Android’s special “All files access” permission so the cleaner can inspect shared storage. Android still blocks protected app-private directories such as other apps’ Android/data areas.'),
  ]);

  Widget _more() => _page([
    _sectionTitle('DEVICE CENTER', 'Hardware details, live monitoring and license', Icons.phone_android), _deviceCard(), const SizedBox(height: 12), _liveMetrics(), const SizedBox(height: 12),
    _infoBox('LICENSE', _verified ? (_lifetime ? 'Lifetime VIP active' : 'VIP active • ${_timeLeft()} remaining') : 'No active license'),
    const SizedBox(height: 12), _actionButton('REFRESH DEVICE DATA', Icons.refresh, _load, _cyan),
  ]);

  Widget _page(List<Widget> children) => RefreshIndicator(color: _cyan, onRefresh: _load, child: ListView(padding: const EdgeInsets.fromLTRB(16, 14, 16, 28), children: children));

  Widget _vipCard() {
    final children = <Widget>[
      Icon(_verified ? Icons.verified : Icons.lock, color: _green, size: 34),
      const SizedBox(width: 12),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _verified ? 'VIP ACTIVE' : 'VIP LOCKED',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 17,
              ),
            ),
            Text(
              _verified ? _timeLeft() : 'Activate your license',
              style: const TextStyle(
                color: _cyan,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    ];
    if (!_verified) {
      children.add(
        IconButton(
          onPressed: _licenseDialog,
          icon: const Icon(Icons.key, color: Colors.white),
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF9B1FCC), Color(0xFF6337C7)],
        ),
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [
          BoxShadow(color: Color(0x449B1FCC), blurRadius: 18),
        ],
      ),
      child: Row(children: children),
    );
  }

  Widget _healthCard() {
    final ram = int.tryParse((_device['ramPercentage'] ?? '0').replaceAll('%', '')) ?? 0;
    final cpu = ((_metrics['cpuUsage'] ?? 0) as num).toDouble();
    final thermal = (_metrics['thermalName'] ?? 'NORMAL').toString();
    final score = (100 - ((ram * .45) + (cpu * .35) + (thermal == 'SEVERE' || thermal == 'CRITICAL' ? 18 : 0))).round().clamp(5, 99);
    return _card(Column(children: [Row(children: [const Icon(Icons.favorite, color: _green), const SizedBox(width: 10), const Text('SYSTEM HEALTH', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), const Spacer(), Text('$score%', style: const TextStyle(color: _green, fontSize: 24, fontWeight: FontWeight.w900))]), const SizedBox(height: 12), LinearProgressIndicator(value: score / 100, minHeight: 9, borderRadius: BorderRadius.circular(8), backgroundColor: Colors.white10, color: _green)]));
  }

  Widget _liveMetrics() {
    final cpu = ((_metrics['cpuUsage'] ?? 0) as num).toDouble();
    final battery = _metrics['batteryLevel'] ?? -1;
    final temp = ((_metrics['batteryTempC'] ?? -1) as num).toDouble();
    final storage = _metrics['storageUsed'] ?? 0;
    final total = _metrics['storageTotal'] ?? 0;
    final rx = _metrics['networkRx'] ?? 0;
    final tx = _metrics['networkTx'] ?? 0;
    return _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Row(children: [Icon(Icons.monitor_heart, color: _cyan), SizedBox(width: 10), Text('LIVE PERFORMANCE MONITOR', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))]), const SizedBox(height: 14), Wrap(spacing: 8, runSpacing: 8, children: [
      _metric('CPU', '${cpu.toStringAsFixed(0)}%', Icons.memory, _cyan), _metric('RAM', _device['ramPercentage'] ?? '--', Icons.developer_board, _purple), _metric('BATTERY', '$battery%', Icons.battery_std, _green), _metric('TEMP', temp < 0 ? '--' : '${temp.toStringAsFixed(1)}°C', Icons.thermostat, _red),
      _metric('THERMAL', '${_metrics['thermalName'] ?? '--'}', Icons.whatshot, _red), _metric('STORAGE', '${_percent(storage, total)}%', Icons.storage, _cyan), _metric('RX', '${_bytes(rx)} total', Icons.download, _green), _metric('TX', '${_bytes(tx)} total', Icons.upload, _purple), _metric('RX RATE', '${_bytes(_rxRate)}/s', Icons.south, _green), _metric('TX RATE', '${_bytes(_txRate)}/s', Icons.north, _purple),
    ])]));
  }

  String _percent(dynamic used, dynamic total) { final u = used is num ? used.toDouble() : 0; final t = total is num ? total.toDouble() : 0; return t <= 0 ? '--' : ((u / t) * 100).round().toString(); }

  Widget _metric(String title, String value, IconData icon, Color color) => Container(width: 112, padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white10)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: color, size: 19), const SizedBox(height: 6), Text(title, style: const TextStyle(color: Colors.white54, fontSize: 10)), const SizedBox(height: 2), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13))]));

  Widget _deviceCard() => _card(Column(children: [Row(children: [const Icon(Icons.phone_android, color: _cyan), const SizedBox(width: 10), const Text('DEVICE STATUS & DETAILS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))]), const Divider(color: Colors.white24, height: 22), _row('Brand', _device['brand'] ?? 'Loading...'), _row('Model', _device['model'] ?? 'Loading...'), _row('Android', 'Android ${_device['androidVersion'] ?? '...'}'), _row('RAM', '${_device['usedRam'] ?? '...'} / ${_device['totalRam'] ?? '...'} (${_device['ramPercentage'] ?? '...'})'), _row('Storage', '${_bytes(_metrics['storageUsed'])} / ${_bytes(_metrics['storageTotal'])}'), _row('Battery', '${_metrics['batteryHealth'] ?? 'Unknown'} • ${_metrics['batteryLevel'] ?? '--'}%') ]));

  Widget _sectionTitle(String title, String sub, IconData icon) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Row(children: [Icon(icon, color: _cyan, size: 30), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)), Text(sub, style: const TextStyle(color: Colors.white54, fontSize: 12))]))]));

  Widget _modeCard(String title, String sub, IconData icon, Color color, Future<void> Function() action) => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: color), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)))]), const SizedBox(height: 8), Text(sub, style: const TextStyle(color: Colors.white60, height: 1.35)), const SizedBox(height: 12), OutlinedButton(onPressed: _scanning ? null : () => action(), child: const Text('RUN'))]));

  Widget _gameCard(String title, String pkg, bool max) => _card(Column(children: [Row(children: [const Icon(Icons.sports_esports, color: _green), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900))), Text(max ? 'MAX' : 'NORMAL', style: const TextStyle(color: _cyan, fontWeight: FontWeight.bold))]), const SizedBox(height: 8), Text(pkg, style: const TextStyle(color: Colors.white38, fontSize: 11)), const SizedBox(height: 12), SizedBox(width: double.infinity, height: 50, child: ElevatedButton.icon(onPressed: _launching ? null : () => _launchGame(max: max), icon: _launching ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.rocket_launch), label: const Text('SAFE PREP & LAUNCH')))]));

  Widget _scanCard() => _card(Column(children: [Row(children: [const Icon(Icons.radar, color: _cyan), const SizedBox(width: 10), const Text('FULL SCAN ENGINE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), const Spacer(), Text(_scanStatus, style: const TextStyle(color: Colors.white54, fontSize: 10))]), const SizedBox(height: 10), if (_scanning) const SpinKitThreeBounce(color: _cyan, size: 28) else Text('Categories: ${_scanCategories.map(_label).join(' • ')}', style: const TextStyle(color: Colors.white60, fontSize: 11)), const SizedBox(height: 10), SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: _scanning ? null : _scanAll, icon: const Icon(Icons.radar), label: const Text('SCAN EVERYTHING')))]));

  Widget _cleanOption(String title, String subtitle, IconData icon, dynamic bytes, Future<void> Function() action) {
    final size = bytes is num ? bytes : 0;
    return _card(
      Row(
        children: [
          Icon(icon, color: _cyan),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                Text('${_bytes(size)} • $subtitle', style: const TextStyle(color: Colors.white54, fontSize: 11)),
              ],
            ),
          ),
          IconButton(
            onPressed: _scanning ? null : action,
            icon: const Icon(Icons.delete_outline, color: _red),
          ),
        ],
      ),
    );
  }

  Widget _scanOption(String category) { final result = _scans[category]; final bytes = result?['totalBytes'] ?? 0; final count = (result?['files'] as List?)?.length ?? 0; return _card(Row(children: [Icon(_scanIcon(category), color: _cyan), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_label(category), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), Text(result == null ? 'Not scanned yet' : '$count candidates • ${_bytes(bytes)}', style: const TextStyle(color: Colors.white54, fontSize: 12))])), IconButton(onPressed: _scanning ? null : () => _scanCategory(category), icon: const Icon(Icons.radar, color: _cyan)), IconButton(onPressed: _scanning ? null : () => _cleanCategory(category), icon: const Icon(Icons.delete_outline, color: _red))])); }

  IconData _scanIcon(String c) => {'downloads':Icons.download, 'screenshots':Icons.photo_camera, 'videos':Icons.video_library, 'large':Icons.sd_storage, 'junk':Icons.delete_sweep, 'duplicates':Icons.copy}.containsKey(c) ? {'downloads':Icons.download, 'screenshots':Icons.photo_camera, 'videos':Icons.video_library, 'large':Icons.sd_storage, 'junk':Icons.delete_sweep, 'duplicates':Icons.copy}[c]! : Icons.folder;

  Widget _actionButton(String text, IconData icon, Future<void> Function() action, Color color) => SizedBox(width: double.infinity, height: 56, child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: color, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), onPressed: _scanning ? null : () => action(), icon: Icon(icon, color: Colors.white), label: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))));
  Widget _infoBox(String title, String text) => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: _cyan, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(text, style: const TextStyle(color: Colors.white60, height: 1.35))]));
  Widget _card(Widget child) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white10)), child: child);
  Widget _row(String a, String b) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [Text(a, style: const TextStyle(color: Colors.white54)), const Spacer(), Flexible(child: Text(b, textAlign: TextAlign.right, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)))]));

  Future<void> _licenseDialog() async => showDialog(context: context, builder: (_) => AlertDialog(backgroundColor: _panel, title: const Text('Activate VIP', style: TextStyle(color: Colors.white)), content: TextField(controller: _keyController, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(hintText: 'SXD-XXXX-XXXX-XXXX', hintStyle: TextStyle(color: Colors.white38))), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCEL')), FilledButton(onPressed: () { Navigator.pop(context); _activate(); }, child: const Text('ACTIVATE'))]));
}
