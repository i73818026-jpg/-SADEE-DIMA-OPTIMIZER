import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:system_info2/system_info2.dart';

class OptimizerService {
  static const MethodChannel _channel = MethodChannel('sadee_x_dima/system');

  Future<Map<String, String>> getDeviceInfo() async {
    try {
      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;
      final totalRamMB = SysInfo.getTotalPhysicalMemory() ~/ (1024 * 1024);
      final freeRamMB = SysInfo.getFreePhysicalMemory() ~/ (1024 * 1024);
      final usedRamMB = totalRamMB - freeRamMB;
      final percent = totalRamMB == 0 ? 0 : ((usedRamMB / totalRamMB) * 100).round();
      return {
        'brand': androidInfo.manufacturer.toUpperCase(),
        'model': androidInfo.model,
        'device': androidInfo.device,
        'androidVersion': androidInfo.version.release,
        'sdkVersion': androidInfo.version.sdkInt.toString(),
        'totalRam': '${(totalRamMB / 1024).toStringAsFixed(2)} GB',
        'usedRam': '${(usedRamMB / 1024).toStringAsFixed(2)} GB',
        'freeRam': '${(freeRamMB / 1024).toStringAsFixed(2)} GB',
        'ramPercentage': '$percent%',
      };
    } catch (_) {
      return {'brand': 'ANDROID DEVICE', 'model': 'Smart Phone', 'androidVersion': 'Unknown', 'totalRam': 'Unknown', 'usedRam': 'Unknown', 'freeRam': 'Unknown', 'ramPercentage': '0%'};
    }
  }

  Future<Map<String, dynamic>> getSystemMetrics() async {
    try {
      return Map<String, dynamic>.from(await _channel.invokeMethod('getSystemMetrics'));
    } catch (_) {
      return {};
    }
  }

  Future<bool> hasAllFilesAccess() async => await _channel.invokeMethod<bool>('hasAllFilesAccess') ?? false;
  Future<void> requestAllFilesAccess() => _channel.invokeMethod('requestAllFilesAccess');
  Future<void> clearOtherAppCaches() => _channel.invokeMethod('clearOtherAppCaches');
  Future<void> openBatterySettings() => _channel.invokeMethod('openBatterySettings');
  Future<void> openBatteryOptimizationSettings() => _channel.invokeMethod('openBatteryOptimizationSettings');
  Future<void> openThermalSettings() => _channel.invokeMethod('openThermalSettings');
  Future<void> openGameSettings() => _channel.invokeMethod('openGameSettings');
  Future<void> openMemorySettings() => _channel.invokeMethod('openMemorySettings');

  Future<int> getAppCacheBytes() async {
    try {
      final dir = await getTemporaryDirectory();
      return await _directorySize(dir);
    } catch (_) { return 0; }
  }

  Future<int> clearAppCache() async {
    try {
      final dir = await getTemporaryDirectory();
      final before = await _directorySize(dir);
      if (dir.existsSync()) {
        for (final entity in dir.listSync(followLinks: false)) {
          try { await entity.delete(recursive: true); } catch (_) {}
        }
      }
      return before;
    } catch (_) { return 0; }
  }

  Future<Map<String, dynamic>> scanFiles(String category) async {
    try { return Map<String, dynamic>.from(await _channel.invokeMethod('scanFiles', {'category': category})); }
    catch (_) { return {'permissionRequired': false, 'files': <dynamic>[], 'totalBytes': 0}; }
  }

  Future<Map<String, dynamic>> deleteFiles(List<String> paths) async {
    try { return Map<String, dynamic>.from(await _channel.invokeMethod('deleteFiles', {'paths': paths})); }
    catch (_) { return {'deleted': 0, 'bytes': 0}; }
  }

  Future<int> _directorySize(Directory dir) async {
    if (!dir.existsSync()) return 0;
    var total = 0;
    await for (final entity in dir.list(followLinks: false)) {
      try {
        if (entity is File) total += await entity.length();
        else if (entity is Directory) total += await _directorySize(entity);
      } catch (_) {}
    }
    return total;
  }

  String formatBytes(num bytes) {
    if (bytes < 1024) return '${bytes.round()} B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}
