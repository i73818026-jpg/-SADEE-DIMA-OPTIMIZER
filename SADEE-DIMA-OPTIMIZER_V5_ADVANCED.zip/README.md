# SADEE X DIMA OPTIMIZER V5

Advanced Flutter Android optimizer/cleaner with separate User/Admin flavors.

## User app additions
- Live CPU usage monitor from `/proc/stat`.
- RAM monitor using Android/system memory APIs already used by the project.
- Battery level, charging state, battery temperature, voltage and Android battery-health status.
- Storage total/used/free monitor.
- Network RX/TX totals plus sampled RX/TX rate.
- Thermal status monitor using Android PowerManager thermal status.
- Advanced Performance Center.
- Safe system optimization flow: app cache cleanup + Android-supported system cache cleanup request.
- Android Memory, Battery Saver, Battery Optimization and Game settings launchers.
- Free Fire / Free Fire MAX safe-prep launch flow.
- Advanced shared-storage scanner: Downloads, Screenshots, Videos, Large Files, Junk Files and Duplicate Files.
- User-confirmed file deletion for scanned shared-storage candidates.
- All-files-access permission flow for advanced scanning.

## Android limitations handled honestly
A normal third-party Android app cannot silently delete another app's private `Android/data` or private cache, force the kernel to free arbitrary system RAM, set CPU voltage/frequency, or directly control hardware temperature. V5 therefore uses supported Android system flows and reports real device state instead of displaying fake boost values.

The `MANAGE_EXTERNAL_STORAGE` permission is intended for direct APK/testing use where the cleaner's core function requires broad shared-storage access. Google Play has policy restrictions for this permission; review Play policy before publishing there.

## Build
The existing GitHub Actions workflow builds both flavors:
- `flutter build apk --release --flavor user -t lib/main_user.dart`
- `flutter build apk --release --flavor admin -t lib/main_admin.dart`

User package: `com.sadeedima.optimizer`
Admin package: `com.sadeedima.optimizer.admin`
