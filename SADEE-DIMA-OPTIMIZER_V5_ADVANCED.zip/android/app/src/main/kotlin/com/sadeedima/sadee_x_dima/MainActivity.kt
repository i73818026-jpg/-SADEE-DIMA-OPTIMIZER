package com.sadeedima.sadee_x_dima

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : FlutterActivity() {
    private val channel = "sadee_x_dima/system"
    private val scanRoot: File get() = Environment.getExternalStorageDirectory()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            when (call.method) {
                "launchPackage" -> launchPackage(call.argument<String>("package"), result)
                "getSystemMetrics" -> result.success(getSystemMetrics())
                "requestAllFilesAccess" -> { openAllFilesAccess(); result.success(true) }
                "hasAllFilesAccess" -> result.success(hasAllFilesAccess())
                "clearOtherAppCaches" -> { openClearAllCaches(); result.success(true) }
                "openBatterySettings" -> { openIntent(Settings.ACTION_BATTERY_SAVER_SETTINGS); result.success(true) }
                "openBatteryOptimizationSettings" -> { openIntent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS); result.success(true) }
                "openThermalSettings" -> { openIntent(Settings.ACTION_SETTINGS); result.success(true) }
                "openGameSettings" -> { openIntent("android.settings.GAME_SETTINGS"); result.success(true) }
                "openMemorySettings" -> { openIntent("android.settings.MEMORY_CARD_SETTINGS"); result.success(true) }
                "trimOwnMemory" -> {
                    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
                        am.getMemoryInfo(ActivityManager.MemoryInfo())
                    }
                    result.success(true)
                }
                "scanFiles" -> {
                    val category = call.argument<String>("category") ?: "junk"
                    result.success(scanFiles(category))
                }
                "deleteFiles" -> {
                    val paths = call.argument<List<String>>("paths") ?: emptyList()
                    result.success(deleteFiles(paths))
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun launchPackage(packageName: String?, result: MethodChannel.Result) {
        if (packageName.isNullOrBlank()) { result.success(false); return }
        try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                result.success(true)
            } else result.success(false)
        } catch (_: Exception) { result.success(false) }
    }

    private fun getSystemMetrics(): Map<String, Any> {
        val batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val batteryIntent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val health = batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val voltage = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val capacity = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val cpu = readCpuUsage()
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        val used = (total - free).coerceAtLeast(0)
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()

        var thermalStatus = 0
        var thermalName = "NORMAL"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            thermalStatus = pm.currentThermalStatus
            thermalName = when (thermalStatus) {
                android.os.PowerManager.THERMAL_STATUS_NONE -> "NONE"
                android.os.PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
                android.os.PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
                android.os.PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
                android.os.PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
                android.os.PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
                android.os.PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
                else -> "UNKNOWN"
            }
        }

        return mapOf(
            "cpuUsage" to cpu,
            "batteryLevel" to if (capacity >= 0) capacity else if (level >= 0) ((level * 100f) / scale).roundToInt() else -1,
            "batteryTempC" to if (tempTenths >= 0) tempTenths / 10.0 else -1.0,
            "batteryVoltageMv" to voltage,
            "batteryHealth" to batteryHealthName(health),
            "charging" to charging,
            "storageTotal" to total,
            "storageFree" to free,
            "storageUsed" to used,
            "networkRx" to rx,
            "networkTx" to tx,
            "thermalStatus" to thermalStatus,
            "thermalName" to thermalName,
            "allFilesAccess" to hasAllFilesAccess()
        )
    }

    private fun batteryHealthName(value: Int): String = when (value) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "GOOD"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "OVERHEAT"
        BatteryManager.BATTERY_HEALTH_DEAD -> "DEAD"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "OVER VOLTAGE"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "UNSPECIFIED"
        BatteryManager.BATTERY_HEALTH_COLD -> "COLD"
        else -> "UNKNOWN"
    }

    private fun readCpuUsage(): Double {
        return try {
            fun read(): LongArray {
                val line = File("/proc/stat").useLines { lines -> lines.firstOrNull { it.startsWith("cpu ") } }
                    ?: return longArrayOf(0, 0)
                val p = line.trim().split(Regex("\\s+"))
                val user = p.getOrNull(1)?.toLongOrNull() ?: 0
                val nice = p.getOrNull(2)?.toLongOrNull() ?: 0
                val system = p.getOrNull(3)?.toLongOrNull() ?: 0
                val idle = p.getOrNull(4)?.toLongOrNull() ?: 0
                val iowait = p.getOrNull(5)?.toLongOrNull() ?: 0
                val irq = p.getOrNull(6)?.toLongOrNull() ?: 0
                val softirq = p.getOrNull(7)?.toLongOrNull() ?: 0
                val steal = p.getOrNull(8)?.toLongOrNull() ?: 0
                val total = user + nice + system + idle + iowait + irq + softirq + steal
                val busy = total - idle - iowait
                return longArrayOf(total, busy)
            }
            val a = read(); Thread.sleep(180); val b = read()
            val total = b[0] - a[0]
            val busy = b[1] - a[1]
            if (total <= 0) 0.0 else ((busy.toDouble() / total.toDouble()) * 100.0).coerceIn(0.0, 100.0)
        } catch (_: Exception) { 0.0 }
    }

    private fun hasAllFilesAccess(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()

    private fun openAllFilesAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
        }
    }

    private fun openClearAllCaches() {
        try {
            startActivity(Intent("android.intent.action.CLEAR_APP_CACHE"))
        } catch (_: Exception) {
            openIntent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        }
    }

    private fun openIntent(action: String) {
        try { startActivity(Intent(action)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    private data class Candidate(val file: File, val size: Long)

    private fun scanFiles(category: String): Map<String, Any> {
        if (!hasAllFilesAccess()) return mapOf("permissionRequired" to true, "category" to category, "files" to emptyList<Map<String, Any>>(), "totalBytes" to 0L)
        val roots = listOf(scanRoot)
        val candidates = ArrayList<Candidate>()
        val maxFiles = 50000
        var visited = 0
        val stack = ArrayDeque<File>()
        roots.forEach { stack.add(it) }
        while (stack.isNotEmpty() && visited < maxFiles) {
            val dir = stack.removeLast()
            val children = try { dir.listFiles() ?: emptyArray() } catch (_: Exception) { emptyArray() }
            for (f in children) {
                if (visited >= maxFiles) break
                if (f.name == "Android") continue
                try {
                    if (f.isDirectory) stack.add(f)
                    else if (f.isFile) {
                        visited++
                        if (matchesCategory(f, category)) candidates.add(Candidate(f, f.length()))
                    }
                } catch (_: Exception) {}
            }
        }

        val finalCandidates = if (category == "duplicates") duplicateCandidates(candidates) else candidates.sortedByDescending { it.size }
        val limited = finalCandidates.take(250)
        return mapOf(
            "permissionRequired" to false,
            "category" to category,
            "scannedFiles" to visited,
            "totalBytes" to finalCandidates.sumOf { it.size },
            "files" to limited.map { mapOf("path" to it.file.absolutePath, "name" to it.file.name, "size" to it.size, "modified" to it.file.lastModified()) }
        )
    }

    private fun matchesCategory(file: File, category: String): Boolean {
        val path = file.absolutePath.lowercase(Locale.US)
        val name = file.name.lowercase(Locale.US)
        val ext = name.substringAfterLast('.', "")
        return when (category) {
            "downloads" -> path.contains("/download/") || path.contains("/downloads/")
            "screenshots" -> (path.contains("screenshot") || path.contains("screen_shot") || path.contains("screen-shot")) && ext in setOf("jpg","jpeg","png","webp","heic","gif")
            "videos" -> ext in setOf("mp4","mkv","mov","avi","3gp","webm","m4v") && (path.contains("/dcim/") || path.contains("/movies/") || path.contains("/pictures/") || path.contains("/download"))
            "large" -> file.length() >= 100L * 1024L * 1024L
            "junk" -> ext in setOf("tmp","temp","log","bak","old","cache","crdownload","part","dmp") || name.endsWith(".nomedia.tmp")
            "duplicates" -> file.length() > 0L
            else -> false
        }
    }

    private fun duplicateCandidates(input: List<Candidate>): List<Candidate> {
        val bySize = input.groupBy { it.size }.filterValues { it.size > 1 }
        val duplicateGroups = ArrayList<Candidate>()
        for ((_, group) in bySize) {
            val hashes = HashMap<String, MutableList<Candidate>>()
            for (c in group) {
                val hash = sha256(c.file) ?: continue
                hashes.getOrPut(hash) { ArrayList() }.add(c)
            }
            for ((_, same) in hashes) if (same.size > 1) duplicateGroups.addAll(same.drop(1))
        }
        return duplicateGroups.sortedByDescending { it.size }
    }

    private fun sha256(file: File): String? = try {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 128)
            while (true) { val n = input.read(buffer); if (n <= 0) break; digest.update(buffer, 0, n) }
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    } catch (_: Exception) { null }

    private fun deleteFiles(paths: List<String>): Map<String, Any> {
        if (!hasAllFilesAccess()) return mapOf("deleted" to 0, "bytes" to 0L, "permissionRequired" to true)
        var deleted = 0
        var bytes = 0L
        for (raw in paths) {
            try {
                val f = File(raw)
                if (!f.isFile) continue
                val canonicalRoot = scanRoot.canonicalPath + File.separator
                val canonicalFile = f.canonicalPath
                if (!canonicalFile.startsWith(canonicalRoot)) continue
                val size = f.length()
                if (f.delete()) { deleted++; bytes += size }
            } catch (_: Exception) {}
        }
        return mapOf("deleted" to deleted, "bytes" to bytes, "permissionRequired" to false)
    }
}
